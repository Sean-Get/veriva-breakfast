import type { Metadata } from "next";
import "./globals.css";
import "./experience.css";
import "./week6.css";
import "./product-cooking.css";
import "./quiet-brand.css";
import "./refinement.css";
import "./pastoral.css";
import "./community-motion.css";
import { StoreProvider } from "@/components/store";
import { MotionProvider } from "@/components/motion";
import { PastoralExperience } from "@/components/pastoral";
export const metadata: Metadata = {
  title: "VERIVA — A better kind of morning",
  description:
    "Thoughtful breakfast ideas, personalised to your taste. Discover simple recipes, a breakfast expert and your next morning ritual.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-scroll-behavior="smooth">
      <body>
        <MotionProvider>
          <PastoralExperience />
          <StoreProvider>{children}</StoreProvider>
        </MotionProvider>
      </body>
    </html>
  );
}
