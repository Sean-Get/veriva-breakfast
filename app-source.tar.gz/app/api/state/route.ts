import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { currentUser, createGuest } from "@/lib/auth";
import { database, getState, saveState, takeRate } from "@/lib/db";
import { recipes, products } from "@/lib/catalog";
import { cartTotal } from "@/lib/recommendation";
import { ApiError, fail, readBody } from "@/lib/http";
import { defaultHealth } from "@/lib/types";
import { safePersonalise } from "@/lib/personalise-server";
import { generalCommunityTopic } from "@/lib/community-examples";
import { saveRecipeToState } from "@/lib/chat-recipes";
import { validCommunityTopic } from "@/lib/community";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
const profileSchema = z.object({
  name: z.string().trim().min(1).max(40),
  goals: z
    .array(z.enum(["energy", "protein", "less-sugar"]))
    .min(1)
    .max(3),
  diet: z.array(z.enum(["dairy", "nuts", "gluten", "eggs", "vegan"])).max(5),
  minutes: z.union([z.literal(5), z.literal(10), z.literal(15)]),
  activity: z.enum(["light", "moderate", "active"]),
  onboarded: z.boolean(),
  health: z
    .object({
      age: z.number().int().min(16).max(110).nullable(),
      heightCm: z.number().min(80).max(250).nullable(),
      weightKg: z.number().min(20).max(350).nullable(),
      notes: z.string().trim().max(500),
      useForAI: z.boolean(),
    })
    .default(defaultHealth()),
});
export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return NextResponse.json({ user: null });
    const community = database()
      .prepare(
        "SELECT id,recipe_id AS recipeId,name,text,created_at AS createdAt FROM community ORDER BY created_at DESC LIMIT 50",
      )
      .all();
    return NextResponse.json(
      {
        user,
        state: getState(user.id),
        aiConfigured: !!process.env.DEEPSEEK_API_KEY,
        community,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return fail(e);
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const user = (await currentUser()) || (await createGuest());
    if (!takeRate("state:" + user.id, 120, 60000))
      throw new ApiError("Please slow down and try again.", 429);
    const s = getState(user.id);
    if (body.action === "profile") {
      const result = profileSchema.safeParse(body.profile);
      if (!result.success)
        throw new ApiError("Please check your profile choices.");
      const previous = JSON.stringify(s.profile.health || defaultHealth());
      const previousConsent = s.profile.health?.useForAI;
      s.profile = result.data;
      if (previous !== JSON.stringify(s.profile.health)) {
        s.healthHistory = [
          { record: s.profile.health!, recordedAt: new Date().toISOString() },
          ...(s.healthHistory || []),
        ].slice(0, 20);
      }
      s.aiPick = null;
      if (previousConsent && !s.profile.health?.useForAI) {
        s.messages = [];
        s.revisions = [];
      }
      database()
        .prepare("UPDATE users SET name=? WHERE id=?")
        .run(s.profile.name, user.id);
    } else if (body.action === "save-recipe") {
      if (
        typeof body.recipeId !== "string" ||
        !saveRecipeToState(s, body.recipeId)
      )
        throw new ApiError(
          "This recipe does not fit your current dietary preferences.",
        );
    } else if (body.action === "favorite") {
      if (!recipes.some((r) => r.id === body.recipeId))
        throw new ApiError("Recipe not found.");
      s.favorites = s.favorites.includes(body.recipeId)
        ? s.favorites.filter((x) => x !== body.recipeId)
        : [...s.favorites, body.recipeId];
    } else if (body.action === "feedback") {
      const f = z
        .object({
          recipeId: z.string(),
          rating: z.number().int().min(1).max(5),
          tags: z
            .array(
              z.enum([
                "Too sweet",
                "Too bland",
                "Too thin",
                "More protein",
                "Love the crunch",
                "Just right",
                "Too thick",
              ]),
            )
            .max(7),
          note: z.string().trim().max(500),
        })
        .safeParse(body);
      if (!f.success || !recipes.some((r) => r.id === f.data.recipeId))
        throw new ApiError("Please check your feedback.");
      s.feedback = [
        { ...f.data, id: randomUUID(), createdAt: new Date().toISOString() },
        ...s.feedback,
      ].slice(0, 100);
      s.aiPick = null;
    } else if (body.action === "cart") {
      const c = z
        .object({
          productId: z.string(),
          quantity: z.number().int().min(0).max(20),
        })
        .safeParse(body);
      if (!c.success || !products.some((p) => p.id === c.data.productId))
        throw new ApiError("Invalid cart item.");
      s.cart = s.cart.filter((i) => i.productId !== c.data.productId);
      if (c.data.quantity) s.cart.push(c.data);
    } else if (body.action === "order") {
      if (!s.cart.length) throw new ApiError("Your basket is empty.");
      s.orders = [
        {
          id: "VR-" + randomUUID().slice(0, 8).toUpperCase(),
          items: [...s.cart],
          total: cartTotal(s.cart),
          createdAt: new Date().toISOString(),
          status: "Demo order" as const,
        },
        ...s.orders,
      ].slice(0, 50);
      s.cart = [];
    } else if (body.action === "share") {
      if (user.guest)
        throw new ApiError(
          "Create an account to share with the community.",
          401,
        );
      const p = z
        .object({
          recipeId: z.string(),
          text: z.string().trim().min(3).max(300),
        })
        .safeParse(body);
      if (!p.success || !validCommunityTopic(p.data.recipeId))
        throw new ApiError("Write a note of 3–300 characters.");
      if (!takeRate("share:" + user.id, 5, 3600000))
        throw new ApiError("You can share five notes per hour.", 429);
      database()
        .prepare(
          "INSERT INTO community(id,user_id,recipe_id,name,text,created_at) VALUES(?,?,?,?,?,?)",
        )
        .run(
          randomUUID(),
          user.id,
          p.data.recipeId,
          s.profile.name,
          p.data.text,
          new Date().toISOString(),
        );
    } else if (body.action === "clear-chat") {
      s.messages = [];
    } else throw new ApiError("Unknown action.");
    saveState(user.id, s);
    if (body.action === "profile" || body.action === "feedback") {
      const state = await safePersonalise(
        user.id,
        body.action,
        body.action === "feedback" ? s.feedback[0].id : undefined,
      );
      return NextResponse.json({ state });
    }
    return NextResponse.json({ state: s });
  } catch (e) {
    return fail(e);
  }
}
