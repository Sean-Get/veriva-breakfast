import { NextResponse } from "next/server";
import { communityPage } from "@/lib/community";
import { fail } from "@/lib/http";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  try {
    return NextResponse.json(communityPage(new URL(request.url)), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (e) {
    return fail(e);
  }
}
