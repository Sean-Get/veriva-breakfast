import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
import { readBody, fail, ApiError } from "@/lib/http";
import { takeRate } from "@/lib/db";
import { recordVisit, trafficSummary } from "@/lib/traffic";

export const runtime = "nodejs";
const headers = { "Cache-Control": "no-store, private" };
export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const user = await currentUser();
    if (!user) throw new ApiError("Please open the app first.", 401);
    if (typeof body.requestId !== "string" || !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(body.requestId))
      throw new ApiError("Invalid visit ID.");
    if (!takeRate("app-visits:" + user.id, 120, 60000))
      throw new ApiError("Please try again shortly.", 429);
    const counted = recordVisit(body.requestId);
    return NextResponse.json({ ok: true, counted }, { headers });
  } catch (e) { return fail(e); }
}
export async function GET() {
  try {
    await requireAdmin();
    return NextResponse.json(trafficSummary(), { headers });
  } catch (e) {
    const response = fail(e);
    response.headers.set("Cache-Control", "no-store, private");
    return response;
  }
}
