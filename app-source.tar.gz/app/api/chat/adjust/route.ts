import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { getState, saveState, takeRate } from "@/lib/db";
import { ApiError, readBody, fail } from "@/lib/http";
import { rankRecipes } from "@/lib/recommendation";
import { tagsForChatAdjustment } from "@/lib/chat-adjustment";
import { safePersonalise } from "@/lib/personalise-server";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Enter the app or sign in first.", 401);
    const parsed = z
      .object({ recipeId: z.string(), note: z.string().trim().min(1).max(500) })
      .safeParse(body);
    if (!parsed.success)
      throw new ApiError("Choose a recipe and describe the taste adjustment.");
    const { recipeId, note } = parsed.data;
    const state = getState(user.id),
      tags = tagsForChatAdjustment(note);
    if (!tags.length)
      throw new ApiError(
        "You can save sweetness, flavour and texture adjustments here. Set dietary exclusions in your profile.",
      );
    if (tags.includes("Too thick") && tags.includes("Too thin"))
      throw new ApiError(
        "Choose either a thinner or a thicker texture, then try again.",
      );
    if (
      !rankRecipes(state.profile, state.feedback).some(
        (r) => r.recipe.id === recipeId,
      )
    )
      throw new ApiError(
        "This recipe does not fit your current dietary choices. Please choose a compatible recipe.",
      );
    if (!takeRate("chat-adjust:" + user.id, 20, 3600000))
      throw new ApiError(
        "Too many adjustment requests. Please try again later.",
        429,
      );
    // Persist one feedback event; retry uses the existing event instead of duplicating it.
    const retry =
      state.aiUpdate?.status !== "updated" &&
      state.aiUpdate?.trigger === "feedback" &&
      state.feedback[0]?.recipeId === recipeId &&
      state.feedback[0]?.note === note;
    const event = retry
      ? state.feedback[0]
      : {
          id: randomUUID(),
          recipeId,
          note,
          tags,
          rating: 3,
          createdAt: new Date().toISOString(),
        };
    if (!retry) {
      state.feedback = [event, ...state.feedback].slice(0, 100);
      state.aiPick = null;
      saveState(user.id, state);
    }
    const next = await safePersonalise(user.id, "feedback", event.id);
    return NextResponse.json({
      state: next,
      updated: next.aiUpdate?.status === "updated",
    });
  } catch (e) {
    return fail(e);
  }
}
