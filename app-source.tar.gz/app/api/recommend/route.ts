import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { getState } from "@/lib/db";
import { safePersonalise } from "@/lib/personalise-server";
import { ApiError, fail, readBody } from "@/lib/http";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Please enter the app first.", 401);
    const state = getState(user.id);
    const feedbackId =
      body.action === "retry-feedback" ? state.feedback[0]?.id : undefined;
    const next = await safePersonalise(
      user.id,
      feedbackId ? "feedback" : "manual",
      feedbackId,
    );
    if (next.aiUpdate?.status !== "updated")
      return NextResponse.json(
        { error: next.aiUpdate?.message || "AI update failed.", state: next },
        { status: 502 },
      );
    return NextResponse.json({
      ...next.aiPick,
      state: next,
      source: "DeepSeek",
    });
  } catch (e) {
    return fail(e);
  }
}
