import { NextResponse } from "next/server";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { takeRate } from "@/lib/db";
import { ApiError, fail, readBody } from "@/lib/http";
import { projectsOverview, projectAction } from "@/lib/creator-projects-server";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function GET() {
  try {
    const user = await currentUser();
    if (!user) throw new ApiError("Enter the app first.", 401);
    return NextResponse.json(projectsOverview(user.id), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (e) {
    return fail(e);
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Enter the app first.", 401);
    if (!takeRate("creator:" + user.id, 90, 60000))
      throw new ApiError("Please slow down.", 429);
    if (
      body.action === "suggest" &&
      !takeRate("creator-ai:" + user.id, 6, 60000)
    )
      throw new ApiError("Please wait before asking AI again.", 429);
    return NextResponse.json(await projectAction(user.id, body));
  } catch (e) {
    if (e instanceof z.ZodError)
      return fail(
        new ApiError("Please check the project fields and text lengths."),
      );
    return fail(e);
  }
}
