import { NextResponse } from "next/server";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { getState, takeRate } from "@/lib/db";
import { ApiError, fail, readBody } from "@/lib/http";
import { growthState } from "@/lib/growth";
import {
  publicShare,
  publicFamily,
  saveCreatorKit,
  saveTrialList,
  aiCookingRescue,
  growthOverview,
  personaliseGrowth,
  applyGrowth,
  creatorKit,
  publishGrowth,
  cookingAction,
  trialOrder,
  recordGrowthEvent,
} from "@/lib/growth-server";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function GET(request: Request) {
  try {
    const family = new URL(request.url).searchParams.get("family");
    if (family) {
      if (family.length > 100) throw new ApiError("Invalid family.");
      return NextResponse.json(
        { shares: publicFamily(family) },
        { headers: { "Cache-Control": "no-store" } },
      );
    }
    const share = new URL(request.url).searchParams.get("share");
    if (share) {
      if (share.length > 100) throw new ApiError("Invalid share.");
      return NextResponse.json(publicShare(share), {
        headers: { "Cache-Control": "no-store" },
      });
    }
    const user = await currentUser();
    if (!user) throw new ApiError("Enter the app first.", 401);
    return NextResponse.json(
      {
        growth: growthState(getState(user.id)),
        campaign: growthOverview(user.id),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    if (!(e instanceof ApiError))
      console.error(e instanceof Error ? e.stack : "Growth request failed");
    return fail(e);
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Enter the app first.", 401);
    if (!takeRate("growth:" + user.id, 150, 60000))
      throw new ApiError("Please slow down.", 429);
    if (body.action === "personalise")
      return NextResponse.json(await personaliseGrowth(user.id, body));
    if (body.action === "apply") {
      const id = z.string().min(1).max(100).safeParse(body.id);
      if (!id.success) throw new ApiError("Choose a proposal.");
      return NextResponse.json(applyGrowth(user.id, id.data));
    }
    if (body.action === "kit-save")
      return NextResponse.json(saveCreatorKit(user.id, body));
    if (body.action === "kit")
      return NextResponse.json(await creatorKit(user.id, body));
    if (body.action === "publish")
      return NextResponse.json({ share: publishGrowth(user.id, body) });
    if (body.action === "trial-shopping") {
      if (typeof body.bundle !== "string")
        throw new ApiError("Choose a trial journey.");
      return NextResponse.json(saveTrialList(user.id, body.bundle));
    }
    if (body.action === "rescue-ai")
      return NextResponse.json(await aiCookingRescue(user.id, body));
    if (body.action === "trial-order")
      return NextResponse.json(trialOrder(user.id, body));
    if (
      typeof body.action === "string" &&
      (body.action.startsWith("cook-") || body.action.startsWith("rescue"))
    )
      return NextResponse.json(cookingAction(user.id, body));
    if (body.action === "event") {
      const p = z
        .object({
          kind: z.enum(["visit", "buy-click"]),
          subject: z.string().min(1).max(100),
          shareId: z.string().max(100).optional(),
        })
        .safeParse(body);
      if (!p.success) throw new ApiError("Invalid action.");
      if (p.data.shareId) publicShare(p.data.shareId);
      recordGrowthEvent(user.id, p.data.kind, p.data.subject, p.data.shareId);
      return NextResponse.json({ ok: true });
    }
    throw new ApiError("Unknown growth action.");
  } catch (e) {
    if (!(e instanceof ApiError))
      console.error(e instanceof Error ? e.stack : "Growth request failed");
    return fail(e);
  }
}
