import { NextResponse } from "next/server";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { takeRate } from "@/lib/db";
import { ApiError, readBody, fail } from "@/lib/http";
import { normalisePlaces } from "@/lib/buying";
export const runtime = "nodejs";
export const maxDuration = 35;
const cache = new Map<string, { expires: number; value: unknown }>();
let nextProviderRequest = 0;
const schema = z.discriminatedUnion("mode", [
  z.object({ mode: z.literal("area"), area: z.string().trim().min(2).max(80) }),
  z.object({
    mode: z.literal("nearby"),
    lat: z.number().min(-85).max(85),
    lon: z.number().min(-180).max(180),
    radius: z.union([z.literal(2000), z.literal(5000)]).default(2000),
    category: z.enum(["groceries", "organic", "fruit"]).default("groceries"),
  }),
]);
const headers = {
  "User-Agent": "VERIVA-course-prototype/1.0 (interactive food-store lookup)",
  Accept: "application/json",
};
async function provider(url: string, init?: RequestInit) {
  const now = Date.now();
  if (now < nextProviderRequest)
    throw new ApiError("Please wait a moment before searching again.", 429);
  nextProviderRequest = now + 1100;
  let response: Response;
  try {
    response = await fetch(url, {
      ...init,
      headers: { ...headers, ...init?.headers },
      signal: AbortSignal.timeout(18000),
    });
  } catch {
    throw new ApiError(
      "Map search could not connect. Try again or continue in Amap.",
      503,
    );
  }
  if (!response.ok) {
    await response.body?.cancel();
    throw new ApiError(
      "The public map service is busy. Try again or continue in Amap.",
      503,
    );
  }
  try {
    return await response.json();
  } catch {
    throw new ApiError(
      "The map service returned an unreadable result. Please try again.",
      502,
    );
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Enter the app before searching.", 401);
    const result = schema.safeParse(body);
    if (!result.success)
      throw new ApiError("Choose a city, public area or valid coordinates.");
    if (!takeRate("places:" + user.id, 30, 3600000))
      throw new ApiError(
        "Map search limit reached. You can continue in Amap.",
        429,
      );
    const input = result.data;
    const key =
      input.mode === "area"
        ? "area:" + input.area.toLowerCase()
        : `near:${input.lat.toFixed(3)}:${input.lon.toFixed(3)}:${input.radius}:${input.category}`;
    const saved = cache.get(key);
    if (saved && saved.expires > Date.now())
      return NextResponse.json(saved.value, {
        headers: { "Cache-Control": "no-store" },
      });
    let payload: unknown;
    if (input.mode === "area") {
      const url = new URL("https://nominatim.openstreetmap.org/search");
      url.searchParams.set("q", input.area);
      url.searchParams.set("format", "jsonv2");
      url.searchParams.set("limit", "4");
      url.searchParams.set("addressdetails", "0");
      const raw = await provider(url.toString());
      if (!Array.isArray(raw))
        throw new ApiError(
          "The map service returned an invalid area result.",
          502,
        );
      payload = {
        candidates: raw
          .map((item: Record<string, unknown>) => ({
            label: String(item.display_name || "").slice(0, 250),
            lat: Number(item.lat),
            lon: Number(item.lon),
          }))
          .filter(
            (item) =>
              Number.isFinite(item.lat) &&
              Number.isFinite(item.lon) &&
              Math.abs(item.lat) <= 85 &&
              Math.abs(item.lon) <= 180,
          ),
        source: "OpenStreetMap Nominatim",
      };
    } else {
      const lat = Number(input.lat.toFixed(3)),
        lon = Number(input.lon.toFixed(3));
      const selection =
        input.category === "fruit"
          ? '["shop"="greengrocer"]'
          : input.category === "organic"
            ? '["shop"~"^(supermarket|health_food|farm)$"]["organic"~"^(yes|only)$"]'
            : '["shop"~"^(supermarket|grocery|convenience|health_food|greengrocer|farm)$"]';
      const query = `[out:json][timeout:15];nwr(around:${input.radius},${lat},${lon})${selection};out center 120;`;
      const raw = await provider("https://overpass-api.de/api/interpreter", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ data: query }),
      });
      payload = {
        centre: { lat, lon },
        places: normalisePlaces(raw, { lat, lon }, input.radius),
        radius: input.radius,
        category: input.category,
        source: "OpenStreetMap / Overpass",
        checkedAt: new Date().toISOString(),
        inventoryVerified: false,
      };
    }
    if (cache.size >= 100) cache.delete(cache.keys().next().value!);
    cache.set(key, {
      expires: Date.now() + (input.mode === "area" ? 86400000 : 300000),
      value: payload,
    });
    return NextResponse.json(payload, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    return fail(error);
  }
}
