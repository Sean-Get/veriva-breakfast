import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
import { readBody, fail, ApiError } from "@/lib/http";
import { takeRate } from "@/lib/db";
import {
  validProduct,
  listProductReviews,
  productReviewPage,
  addProductReview,
  moderateProductReview,
} from "@/lib/product-reviews";
export const runtime = "nodejs";
const headers = { "Cache-Control": "no-store, private" };
export async function GET(request: Request) {
  try {
    const url = new URL(request.url),
      admin = url.searchParams.get("admin") === "1",
      id = url.searchParams.get("product") || undefined;
    if (admin) await requireAdmin();
    if ((!admin && !id) || (id && !validProduct(id)))
      throw new ApiError("Product not found.", 404);
    return NextResponse.json(
      admin
        ? { reviews: listProductReviews(id, true) }
        : productReviewPage(
            id!,
            url.searchParams.get("filter") || "All",
            Number(url.searchParams.get("page") || 1),
          ),
      { headers },
    );
  } catch (e) {
    return fail(e);
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    if (body.action === "moderate") {
      await requireAdmin();
      if (typeof body.id !== "string" || typeof body.hidden !== "boolean")
        throw new ApiError("Invalid review action.");
      moderateProductReview(body.id, body.hidden);
    } else {
      const user = await currentUser();
      if (!user) throw new ApiError("Please open the app first.", 401);
      if (!takeRate("product-review:" + user.id, 10, 3600000))
        throw new ApiError("Please try again later.", 429);
      addProductReview(user.id, body);
    }
    return NextResponse.json({ ok: true }, { headers });
  } catch (e) {
    return fail(e);
  }
}
