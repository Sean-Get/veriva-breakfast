import { NextResponse } from "next/server";
import { requireAdmin, loginAdmin, logoutAdmin, adminUsers } from "@/lib/admin";
import { readBody, fail, ApiError } from "@/lib/http";
import { takeRate } from "@/lib/db";
export const runtime = "nodejs";
const headers = { "Cache-Control": "no-store, private" };
export async function GET(request: Request) {
  try {
    await requireAdmin();
    return NextResponse.json(adminUsers(new URL(request.url)), { headers });
  } catch (e) {
    const response = fail(e);
    response.headers.set("Cache-Control", "no-store, private");
    return response;
  }
}
export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    if (body.action === "logout") {
      await logoutAdmin();
      return NextResponse.json({ ok: true }, { headers });
    }
    if (
      body.action !== "login" ||
      typeof body.password !== "string" ||
      body.password.length > 200
    )
      throw new ApiError("请输入管理口令。");
    const address =
      request.headers.get("x-forwarded-for")?.split(",")[0] || "local";
    if (!takeRate("admin-login:" + address, 10, 15 * 60000))
      throw new ApiError("尝试次数过多，请 15 分钟后重试。", 429);
    await loginAdmin(body.password);
    return NextResponse.json({ ok: true }, { headers });
  } catch (e) {
    return fail(e);
  }
}
