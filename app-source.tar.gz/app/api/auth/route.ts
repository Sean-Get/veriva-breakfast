import { NextResponse } from "next/server";
import { z } from "zod";
import { randomUUID } from "node:crypto";
import { database, getState, saveState, takeRate } from "@/lib/db";
import {
  currentUser,
  createGuest,
  endSession,
  passwordHash,
  passwordMatches,
  sessionFor,
} from "@/lib/auth";
import { ApiError, fail, readBody } from "@/lib/http";
import { defaultState } from "@/lib/types";
export const runtime = "nodejs";
const credentials = z.object({
  action: z.enum(["register", "login"]),
  email: z.string().trim().email().max(254),
  password: z.string().min(8).max(128),
  name: z.string().trim().min(1).max(40).optional(),
});
export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    if (body.action === "logout") {
      await endSession();
      return NextResponse.json({ ok: true });
    }
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "local";
    if (!takeRate("auth:" + ip, 30, 15 * 60000))
      throw new ApiError(
        "Too many attempts. Please try again in 15 minutes.",
        429,
      );
    if (body.action === "guest") {
      const u = (await currentUser()) || (await createGuest());
      return NextResponse.json({ user: u });
    }
    const parsed = credentials.safeParse(body);
    if (!parsed.success)
      throw new ApiError(
        "Use a valid email and a password of 8–128 characters.",
      );
    const { action, password } = parsed.data,
      email = parsed.data.email.toLowerCase();
    const existing = database()
      .prepare("SELECT id,password FROM users WHERE email=?")
      .get(email) as { id: string; password: string } | undefined;
    if (action === "login") {
      if (!existing?.password || !passwordMatches(password, existing.password))
        throw new ApiError("The email or password is incorrect.", 401);
      await sessionFor(existing.id);
      return NextResponse.json({ ok: true });
    }
    if (existing)
      throw new ApiError(
        "An account with this email already exists. Please sign in.",
        409,
      );
    const guest = await currentUser(),
      id = guest?.guest ? guest.id : randomUUID(),
      name = parsed.data.name || email.split("@")[0];
    if (guest?.guest) {
      database()
        .prepare(
          "UPDATE users SET email=?,name=?,password=?,guest=0 WHERE id=?",
        )
        .run(email, name, passwordHash(password), id);
      const s = getState(id);
      s.profile.name = name;
      saveState(id, s);
    } else {
      database()
        .prepare(
          "INSERT INTO users(id,email,name,password,guest,created_at) VALUES(?,?,?,?,0,?)",
        )
        .run(id, email, name, passwordHash(password), Date.now());
      const s = defaultState();
      s.profile.name = name;
      saveState(id, s);
    }
    await sessionFor(id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
