import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { readBody,fail,ApiError } from "@/lib/http";
import { dailyRecommendation,generateDailyRecommendation } from "@/lib/daily-expert";
export const runtime="nodejs";
export const maxDuration=60;
const headers={"Cache-Control":"no-store, private"};
export async function GET(){try{const user=await currentUser();if(!user)throw new ApiError("Please open the app first.",401);return NextResponse.json(dailyRecommendation(user.id),{headers});}catch(e){return fail(e);}}
export async function POST(request:Request){try{await readBody(request);const user=await currentUser();if(!user)throw new ApiError("Please open the app first.",401);return NextResponse.json(await generateDailyRecommendation(user.id),{headers});}catch(e){return fail(e);}}
