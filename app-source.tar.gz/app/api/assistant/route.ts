import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { getState, saveState, takeRate } from "@/lib/db";
import { ApiError, fail, readBody } from "@/lib/http";
import {
  proposeAssistant,
  executeProposal,
  undoAssistant,
} from "@/lib/assistant-server";
import { workspace, snapshot, recordUndo } from "@/lib/breakfast";
export const runtime = "nodejs";
export const maxDuration = 60;
export async function POST(request: Request) {
  try {
    const body = await readBody(request),
      user = await currentUser();
    if (!user) throw new ApiError("Enter the app first.", 401);
    if (!takeRate("workspace:" + user.id, 100, 60000))
      throw new ApiError("Please slow down.", 429);
    if (body.action === "propose")
      return NextResponse.json({
        proposal: await proposeAssistant(user.id, body),
      });
    if (body.action === "execute") {
      if (typeof body.id !== "string") throw new ApiError("Choose a proposal.");
      return NextResponse.json({
        state: executeProposal(user.id, body.id),
        message: "Applied and saved to your account.",
      });
    }
    if (body.action === "undo")
      return NextResponse.json({
        state: undoAssistant(user.id),
        message: "Last assistant action undone.",
      });
    const state = getState(user.id),
      w = workspace(state),
      before = snapshot(w);
    if (body.action === "dismiss") {
      if (typeof body.id !== "string") throw new ApiError("Choose a proposal.");
      w.proposals = w.proposals.filter((p) => p.id !== body.id);
      state.breakfast = w;
      saveState(user.id, state);
      return NextResponse.json({ state, message: "Proposal dismissed." });
    }
    if (body.action === "pantry") {
      const parsed = z
        .array(
          z.object({
            id: z.string().min(1).max(80),
            name: z.string().trim().min(1).max(70),
            quantity: z.string().max(70),
          }),
        )
        .max(40)
        .safeParse(body.items);
      if (!parsed.success)
        throw new ApiError("Add up to 40 named pantry items.");
      w.pantry = parsed.data;
    } else if (body.action === "memory-edit") {
      const parsed = z
        .object({
          id: z.string().max(80).optional(),
          text: z.string().trim().min(3).max(180),
        })
        .safeParse(body);
      if (!parsed.success)
        throw new ApiError("Use 3–180 characters for a breakfast preference.");
      if (parsed.data.id) {
        const memory = w.memories.find((m) => m.id === parsed.data.id);
        if (!memory) throw new ApiError("Memory not found.");
        memory.text = parsed.data.text;
      } else {
        if (w.memories.length >= 30)
          throw new ApiError("Please remove an old memory first.");
        w.memories.push({
          id: randomUUID(),
          text: parsed.data.text,
          source: "user",
          createdAt: new Date().toISOString(),
        });
      }
      state.aiPick = null;
    } else if (body.action === "memory-delete") {
      if (typeof body.id !== "string") throw new ApiError("Choose a memory.");
      w.memories = w.memories.filter((m) => m.id !== body.id);
      state.aiPick = null;
    } else if (body.action === "shopping-toggle") {
      const item = w.shopping.find((i) => i.id === body.id);
      if (!item) throw new ApiError("Shopping item not found.");
      item.checked = !item.checked;
    } else if (body.action === "recipe-delete") {
      if (typeof body.id !== "string") throw new ApiError("Choose a recipe.");
      if (w.plan?.days.some((d) => d.recipeId === body.id))
        throw new ApiError(
          "Replace planned uses of this recipe before removing it.",
        );
      w.recipes = w.recipes.filter((r) => r.id !== body.id);
    } else throw new ApiError("Unknown workspace action.");
    recordUndo(w, before, randomUUID(), "Workspace edit");
    state.breakfast = w;
    saveState(user.id, state);
    return NextResponse.json({ state, message: "Saved." });
  } catch (error) {
    return fail(error);
  }
}
