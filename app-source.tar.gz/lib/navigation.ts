import { products } from "./catalog";
export function isProductPage(path: string) {
  return path === "/shop" || products.some((p) => path === `/products/${p.id}`);
}
