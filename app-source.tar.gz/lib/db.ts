import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { defaultState, defaultHealth, type UserState } from "./types";
let db: DatabaseSync | undefined;
export function database() {
  if (db) return db;
  const folder =
    process.env.VERIVA_DATA_DIR || path.join(process.cwd(), "data");
  mkdirSync(folder, { recursive: true });
  db = new DatabaseSync(path.join(folder, "veriva.sqlite"));
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
 CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY,email TEXT UNIQUE,name TEXT NOT NULL,password TEXT,guest INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS user_state (user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,json TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS community (id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),recipe_id TEXT NOT NULL,name TEXT NOT NULL,text TEXT NOT NULL,created_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY,count INTEGER NOT NULL,reset_at INTEGER NOT NULL);`);
  return db;
}
export function getState(userId: string): UserState {
  const row = database()
    .prepare("SELECT json FROM user_state WHERE user_id=?")
    .get(userId) as { json: string } | undefined;
  const state: UserState = row ? JSON.parse(row.json) : defaultState();
  state.profile = {
    ...defaultState().profile,
    ...state.profile,
    health: { ...defaultHealth(), ...state.profile.health },
  };
  state.healthHistory ||= [];
  state.revisions ||= [];
  return state;
}
export function saveState(userId: string, state: UserState) {
  database()
    .prepare(
      "INSERT INTO user_state(user_id,json) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET json=excluded.json",
    )
    .run(userId, JSON.stringify(state));
}
export function takeRate(key: string, limit: number, windowMs: number) {
  const d = database(),
    now = Date.now();
  const row = d
    .prepare("SELECT count,reset_at FROM rate_limits WHERE key=?")
    .get(key) as { count: number; reset_at: number } | undefined;
  if (!row || row.reset_at <= now) {
    d.prepare(
      "INSERT INTO rate_limits(key,count,reset_at) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=1,reset_at=excluded.reset_at",
    ).run(key, now + windowMs);
    return true;
  }
  if (row.count >= limit) return false;
  d.prepare("UPDATE rate_limits SET count=count+1 WHERE key=?").run(key);
  return true;
}
