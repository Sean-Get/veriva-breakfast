import { NextResponse } from "next/server";
export class ApiError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}
export async function readBody(request: Request) {
  const origin = request.headers.get("origin");
  // Next.js may normalise request.url to localhost behind its local proxy.
  // The browser-visible Host header remains the correct origin boundary.
  if (origin) {
    let source: URL;
    try {
      source = new URL(origin);
    } catch {
      throw new ApiError("This request is not allowed.", 403);
    }
    if (
      !["http:", "https:"].includes(source.protocol) ||
      source.host !== request.headers.get("host")
    )
      throw new ApiError("This request is not allowed.", 403);
  }
  const text = await request.text();
  if (Buffer.byteLength(text) > 16000)
    throw new ApiError("Please send a shorter request.", 413);
  try {
    const data = JSON.parse(text);
    if (!data || typeof data !== "object" || Array.isArray(data))
      throw new Error();
    return data;
  } catch {
    throw new ApiError("Invalid request.");
  }
}
export function fail(error: unknown) {
  if (error instanceof ApiError)
    return NextResponse.json(
      { error: error.message },
      { status: error.status },
    );
  return NextResponse.json(
    { error: "Something went wrong. Please try again." },
    { status: 500 },
  );
}
