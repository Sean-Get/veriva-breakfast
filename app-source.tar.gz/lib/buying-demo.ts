import { distanceMetres, type Place, type Point } from "./buying";

// Local illustration coordinates. These fixtures are never real store results.
export const demoArea = { lat: 0, lon: 0, label: "Morning campus (fictional)" };
const stores = [
  {
    id: "demo-market",
    name: "Morning Market",
    lat: 0.002,
    lon: 0.003,
    category: "supermarket",
    address: "12 Orchard Walk · Fictional campus",
    items: "Oats · yogurt · milk · fresh berries",
  },
  {
    id: "demo-pantry",
    name: "Green Pantry",
    lat: 0.005,
    lon: -0.004,
    category: "health_food",
    address: "8 Garden Lane · Fictional campus",
    items: "Organic oats · chia seeds · plant drinks",
  },
  {
    id: "demo-fruit",
    name: "Fresh Basket",
    lat: -0.004,
    lon: 0.007,
    category: "greengrocer",
    address: "24 Riverside Walk · Fictional campus",
    items: "Bananas · apples · berries · seasonal fruit",
  },
  {
    id: "demo-corner",
    name: "Campus Corner",
    lat: -0.008,
    lon: -0.006,
    category: "convenience",
    address: "3 Library Square · Fictional campus",
    items: "Milk · yogurt · breakfast essentials",
  },
  {
    id: "demo-grove",
    name: "The Grove Food Hall",
    lat: 0.018,
    lon: 0.016,
    category: "supermarket",
    address: "60 Grove Avenue · Fictional campus",
    items: "Oats · nuts · seeds · fruit · dairy",
  },
  {
    id: "demo-garden",
    name: "Garden Organics",
    lat: -0.016,
    lon: -0.018,
    category: "health_food",
    address: "42 Meadow Road · Fictional campus",
    items: "Organic pantry ingredients · plant drinks",
  },
] as const;
export function demoPlaces(radius: number, category: string): Place[] {
  return stores
    .map((s) => ({
      ...s,
      distance: distanceMetres(demoArea, s),
      phone: "",
      openingHours: "08:00–21:00 (sample)",
      stock: "unknown" as const,
    }))
    .filter(
      (s) =>
        s.distance <= radius &&
        (category === "groceries" ||
          (category === "organic"
            ? s.category === "health_food"
            : s.category === "greengrocer")),
    )
    .sort((a, b) => a.distance - b.distance);
}
export function demoItems(id: string) {
  return stores.find((s) => s.id === id)?.items || "Breakfast ingredients";
}
export function demoMapPoint(point: Point): [number, number] {
  return [450 + point.lon * 16000, 310 - point.lat * 13000];
}
export function demoRoute(place: Point): [number, number][] {
  const from = demoMapPoint(demoArea),
    to = demoMapPoint(place);
  return [from, [to[0], from[1]], to];
}
