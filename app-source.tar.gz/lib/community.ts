import { database } from "./db";
import { recipes } from "./catalog";
import { ApiError } from "./http";
import type { CommunityPost } from "./types";
import { generalCommunityTopic } from "./community-examples";
import { conceptRecipes } from "./growth";
import { publicShare } from "./growth-server";
export function validCommunityTopic(id: string) {
  if (
    id === generalCommunityTopic ||
    recipes.some((r) => r.id === id) ||
    conceptRecipes.some((r) => r.id === id)
  )
    return true;
  if (id.startsWith("share:") && id.length <= 110) {
    try {
      publicShare(id.slice(6));
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

export function communityPage(url: URL) {
  const recipeId = url.searchParams.get("recipe") || "";
  if (recipeId && !validCommunityTopic(recipeId))
    throw new ApiError("Recipe not found.", 404);
  const raw = url.searchParams.get("page") || "1";
  if (!/^\d{1,6}$/.test(raw) || Number(raw) < 1)
    throw new ApiError("Invalid page.");
  const db = database();
  const stats = db
    .prepare(
      "SELECT recipe_id AS recipeId,COUNT(*) AS notes,COUNT(DISTINCT user_id) AS people FROM community GROUP BY recipe_id",
    )
    .all() as { recipeId: string; notes: number; people: number }[];
  const total = stats
    .filter((s) => !recipeId || s.recipeId === recipeId)
    .reduce((n, s) => n + s.notes, 0);
  const pageSize = 12;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const page = Math.min(Number(raw), pages);
  const posts = db
    .prepare(
      `SELECT id,recipe_id AS recipeId,name,text,created_at AS createdAt FROM community
     ${recipeId ? "WHERE recipe_id=?" : ""} ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?`,
    )
    .all(
      ...(recipeId ? [recipeId] : []),
      pageSize,
      (page - 1) * pageSize,
    ) as CommunityPost[];
  return { posts, stats, total, page, pages };
}
