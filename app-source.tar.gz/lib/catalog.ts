export type Ingredient = { name: string; amount: string; honey?: boolean };
export type Recipe = {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  minutes: number;
  calories: number;
  protein: number;
  fiber: number;
  sugar: number;
  image: string;
  color: string;
  tags: string[];
  allergens: string[];
  ingredients: Ingredient[];
  steps: string[];
  products: string[];
};
export const recipes: Recipe[] = [
  {
    id: "berry-oats",
    name: "Berry good mornings",
    subtitle: "Creamy oats, fresh berries & a little crunch.",
    category: "Warm bowls",
    minutes: 5,
    calories: 325,
    protein: 12,
    fiber: 8,
    sugar: 13,
    image: "/images/breakfast-hero.webp",
    color: "#e7eee4",
    tags: ["High fibre", "5-minute breakfast"],
    allergens: ["gluten", "dairy"],
    ingredients: [
      { name: "Rolled oats", amount: "50 g" },
      { name: "Milk or oat drink", amount: "180 ml" },
      { name: "Mixed berries", amount: "60 g" },
      { name: "Pumpkin seeds", amount: "10 g" },
      { name: "Honey (optional)", amount: "5 g", honey: true },
    ],
    steps: [
      "Warm the oats and milk in a small saucepan for 3 minutes, stirring until creamy.",
      "Pour into your favourite bowl. Add berries and pumpkin seeds.",
      "Taste first, then add a little honey if you like. Enjoy while warm.",
    ],
    products: ["oats", "muesli"],
  },
  {
    id: "overnight-bircher",
    name: "The overnight reset",
    subtitle: "Apple, cinnamon and oats. Ready when you are.",
    category: "Overnight oats",
    minutes: 5,
    calories: 295,
    protein: 9,
    fiber: 7,
    sugar: 10,
    image: "/images/overnight.webp",
    color: "#eee9dc",
    tags: ["Prep ahead", "Plant-based"],
    allergens: ["gluten"],
    ingredients: [
      { name: "Rolled oats", amount: "45 g" },
      { name: "Unsweetened oat drink", amount: "150 ml" },
      { name: "Grated apple", amount: "60 g" },
      { name: "Chia seeds", amount: "8 g" },
      { name: "Cinnamon", amount: "A pinch" },
    ],
    steps: [
      "Mix oats, oat drink, grated apple and chia in a jar.",
      "Cover and refrigerate overnight, or for at least 4 hours.",
      "Stir, add cinnamon and a splash of oat drink. Your morning is ready.",
    ],
    products: ["oats", "chia"],
  },
  {
    id: "yogurt-crunch",
    name: "A little golden crunch",
    subtitle: "Cool yogurt meets toasted muesli and fruit.",
    category: "No-cook",
    minutes: 3,
    calories: 310,
    protein: 20,
    fiber: 5,
    sugar: 14,
    image: "/images/yogurt.webp",
    color: "#f2e7d9",
    tags: ["Protein-rich", "No cooking"],
    allergens: ["dairy", "nuts", "gluten"],
    ingredients: [
      { name: "Plain Greek yogurt", amount: "170 g" },
      { name: "Berry muesli", amount: "35 g" },
      { name: "Fresh strawberries", amount: "70 g" },
      { name: "Chopped almonds", amount: "8 g" },
    ],
    steps: [
      "Spoon plain yogurt into a shallow bowl.",
      "Scatter the muesli over one side to keep it crunchy.",
      "Finish with sliced strawberries and almonds. Serve straight away.",
    ],
    products: ["muesli"],
  },
  {
    id: "banana-protein",
    name: "Your morning fuel",
    subtitle: "Banana, cocoa and a satisfying protein boost.",
    category: "Warm bowls",
    minutes: 7,
    calories: 385,
    protein: 25,
    fiber: 9,
    sugar: 11,
    image: "/images/banana.webp",
    color: "#eee4d4",
    tags: ["Protein-rich", "After your workout"],
    allergens: ["gluten", "nuts"],
    ingredients: [
      { name: "Rolled oats", amount: "50 g" },
      { name: "Unsweetened soy drink", amount: "180 ml" },
      { name: "Plant protein powder", amount: "15 g" },
      { name: "Banana", amount: "50 g" },
      { name: "Almond butter", amount: "10 g" },
      { name: "Cocoa", amount: "5 g" },
    ],
    steps: [
      "Simmer oats and soy drink for 4 minutes.",
      "Remove from heat and stir in protein powder and cocoa.",
      "Top with sliced banana and almond butter. Add water if needed.",
    ],
    products: ["oats"],
  },
  {
    id: "chia-cloud",
    name: "A softer start",
    subtitle: "Chia pudding with bright berries and coconut.",
    category: "No-cook",
    minutes: 4,
    calories: 270,
    protein: 10,
    fiber: 11,
    sugar: 7,
    image: "/images/chia.webp",
    color: "#e7e8ef",
    tags: ["Plant-based", "No added sugar"],
    allergens: [],
    ingredients: [
      { name: "Chia seeds", amount: "25 g" },
      { name: "Unsweetened soy drink", amount: "170 ml" },
      { name: "Blueberries", amount: "60 g" },
      { name: "Coconut flakes", amount: "5 g" },
    ],
    steps: [
      "Whisk chia seeds and soy drink together. Rest for 5 minutes, then whisk again.",
      "Cover and chill for at least 2 hours or overnight.",
      "Top with blueberries and coconut. Active preparation takes 4 minutes.",
    ],
    products: ["chia"],
  },
  {
    id: "savory-oats",
    name: "Something savoury",
    subtitle: "Warm oats, spinach and a soft-cooked egg.",
    category: "Warm bowls",
    minutes: 10,
    calories: 340,
    protein: 18,
    fiber: 6,
    sugar: 2,
    image: "/images/savory.webp",
    color: "#e3e9dc",
    tags: ["No added sugar", "Savoury"],
    allergens: ["gluten", "eggs"],
    ingredients: [
      { name: "Rolled oats", amount: "45 g" },
      { name: "Water", amount: "200 ml" },
      { name: "Spinach", amount: "50 g" },
      { name: "Egg", amount: "1" },
      { name: "Sesame oil", amount: "½ tsp" },
    ],
    steps: [
      "Simmer oats in water for 5 minutes. Stir in spinach until wilted.",
      "In a second pan, cook the egg to your preference.",
      "Spoon the oats into a bowl, add the egg and finish with sesame oil.",
    ],
    products: ["oats"],
  },
];
export const products = [
  {
    id: "blueberry-apple-porridge",
    name: "Blueberry–apple porridge",
    type: "Blueberry & apple · Breakfast concept",
    weight: "Illustrative pack",
    price: 49,
    image: "/images/product-pack-blueberry-apple-porridge-v1.webp",
    category: "Porridge",
    description:
      "Blueberry and apple flavours inspire a warm, comforting breakfast. Explore a simple berry bowl for a fresh preparation idea.",
  },
  {
    id: "bircher-porridge",
    name: "Bircher porridge",
    type: "Bircher-inspired · Breakfast concept",
    weight: "Illustrative pack",
    price: 45,
    image: "/images/product-pack-bircher-porridge-v1.webp",
    category: "Porridge",
    description:
      "An apple-inspired Bircher breakfast concept for a gentle start. Explore an overnight oat recipe with apple and cinnamon, prepared at your own pace.",
  },
  {
    id: "oats",
    name: "Organic rolled oats",
    type: "The everyday essential",
    weight: "500 g",
    price: 39,
    image: "/images/product-pack-oats-v1.webp",
    category: "Oats",
    description: "A simple starting point for warm bowls and overnight oats.",
  },
  {
    id: "muesli",
    name: "Berry breakfast muesli",
    type: "A little extra crunch",
    weight: "375 g",
    price: 59,
    image: "/images/product-pack-muesli-v1.webp",
    category: "Muesli",
    description:
      "A berry and grain combination for yogurt bowls and easy mornings.",
  },
  {
    id: "chia",
    name: "Organic chia seeds",
    type: "Small seeds, more possibilities",
    weight: "200 g",
    price: 35,
    image: "/images/product-pack-chia-v1.webp",
    category: "Pantry",
    description: "Stir into overnight oats or make a simple chia pudding.",
  },
  {
    id: "cocoa-hazelnut",
    name: "Cocoa & hazelnut porridge",
    type: "A cosy cocoa moment",
    weight: "400 g",
    price: 55,
    image: "/images/product-pack-cocoa-hazelnut-v1.webp",
    category: "Porridge",
    description:
      "A cocoa-inspired oat blend with a nutty finish. Enjoy warm with sliced banana; check the actual pack for nuts and other allergens.",
  },
  {
    id: "apple-cinnamon",
    name: "Apple & cinnamon oats",
    type: "An orchard-inspired morning",
    weight: "400 g",
    price: 46,
    image: "/images/product-pack-apple-cinnamon-v1.webp",
    category: "Oats",
    description:
      "An apple-and-spice concept blend for warm bowls or overnight oats. Add your own fruit and choose your preferred milk or plant drink.",
  },
  {
    id: "coconut-almond",
    name: "Coconut & almond granola",
    type: "Golden, crisp & gently tropical",
    weight: "350 g",
    price: 62,
    image: "/images/product-pack-coconut-almond-v1.webp",
    category: "Muesli",
    description:
      "A toasted granola concept with coconut and almonds. Sprinkle over plain yogurt just before serving to keep the crunch.",
  },
  {
    id: "raspberry-crunch",
    name: "Raspberry crunch muesli",
    type: "Bright berries, little moments",
    weight: "375 g",
    price: 58,
    image: "/images/product-pack-raspberry-crunch-v1.webp",
    category: "Muesli",
    description:
      "A raspberry-inspired grain blend for quick breakfast bowls. Pair with yogurt and fresh fruit, or let it soften in milk.",
  },
  {
    id: "pumpkin-seeds",
    name: "Pumpkin seeds",
    type: "A finishing touch from the pantry",
    weight: "200 g",
    price: 29,
    image: "/images/product-pack-pumpkin-seeds-v1.webp",
    category: "Pantry",
    description:
      "A versatile seed topping for oats, yogurt or savoury breakfasts. Store sealed in a cool, dry place and follow the actual pack guidance.",
  },
];
export const goalNames: Record<string, string> = {
  energy: "Steady energy",
  protein: "More protein",
  "less-sugar": "Less added sugar",
};
export const dietNames: Record<string, string> = {
  dairy: "Dairy-free",
  nuts: "Nut-free",
  gluten: "Avoid gluten",
  eggs: "Egg-free",
  vegan: "Plant-based",
};
