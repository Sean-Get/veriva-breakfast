import { database } from "./db";

function trafficDatabase() {
  const db = database();
  db.exec(`CREATE TABLE IF NOT EXISTS app_visits (
    request_id TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL
  ); CREATE INDEX IF NOT EXISTS app_visits_date ON app_visits(created_at);`);
  return db;
}

// Each document opening has its own ID. Retrying a request never adds a visit.
export function recordVisit(requestId: string, now = Date.now()) {
  return trafficDatabase().prepare(
    "INSERT OR IGNORE INTO app_visits(request_id,created_at) VALUES(?,?)",
  ).run(requestId, now).changes === 1;
}

export function trafficSummary(now = Date.now()) {
  const offset = 8 * 3600000;
  const start = Math.floor((now + offset) / 86400000) * 86400000 - offset;
  const db = trafficDatabase();
  const { total } = db.prepare("SELECT COUNT(*) total FROM app_visits").get() as { total: number };
  const { today } = db.prepare(
    "SELECT COUNT(*) today FROM app_visits WHERE created_at>=? AND created_at<?",
  ).get(start, start + 86400000) as { today: number };
  return { total, today, timeZone: "Asia/Shanghai", updatedAt: new Date(now).toISOString() };
}
