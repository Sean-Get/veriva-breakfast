export type CookingMethod = {
  name: string;
  nameZh: string;
  equipment: string;
  waiting: string;
  steps: string[];
  tips: string[];
  serving: string;
};
export const recipeMethods: Record<string, CookingMethod> = {
  "berry-oats": {
    name: "Berry good mornings",
    nameZh: "莓果奶香燕麦碗",
    equipment: "Small saucepan, spoon and kitchen scales",
    waiting: "About 5 minutes of active preparation; no soaking needed",
    steps: [
      "Measure the oats, milk or oat drink, berries, pumpkin seeds and optional honey using your current ingredient list. Wash and drain the berries; cut larger fruit into small pieces.",
      "Combine the oats and milk in a small saucepan. Heat gently until small bubbles appear at the edge, then lower the heat.",
      "Simmer gently for about 3 minutes, stirring along the base and sides. The flakes should soften and the liquid become creamy. Follow the oat packet if it needs longer.",
      "Remove from the heat and spoon into a bowl. Taste before adding the optional honey. Follow your saved quantities if sweetness has already been adjusted.",
      "Arrange the berries and pumpkin seeds on top. For a more even fruit flavour, gently crush a little of the existing fruit and stir it through.",
      "Let it cool to a comfortable temperature. Aim for a soft, spoonable texture. Leave feedback if you would prefer tomorrow's bowl sweeter, thicker or thinner.",
    ],
    tips: [
      "A gentle heat and regular stirring help prevent milk catching on the pan.",
      "Different oat flakes absorb liquid differently; follow the preparation guidance on your pack.",
    ],
    serving: "Serve warm, with the berries and seeds added just before eating.",
  },
  "overnight-bircher": {
    name: "The overnight reset",
    nameZh: "苹果肉桂隔夜燕麦",
    equipment: "Lidded jar, grater and spoon",
    waiting:
      "5 minutes of active preparation, plus at least 4 hours in the fridge",
    steps: [
      "Use a clean lidded jar. Measure the oats and unsweetened oat drink using your current ingredient list. The chilling time is additional to active preparation.",
      "Wash and core the apple, then grate the measured portion. Add it to the jar with the chia seeds and stir until all the oats are moistened.",
      "Scrape the bottom and sides with your spoon to break up any clumps of chia. Add the cinnamon and stir again.",
      "Cover and refrigerate for at least 4 hours, or overnight. Do not leave the jar on the counter overnight.",
      "In the morning, stir from the bottom until evenly combined. Check for dry pockets and follow any saved texture adjustment and current quantities.",
      "Spoon into a bowl or enjoy from the jar. For a little crispness, reserve some of the recipe's apple to grate in just before serving, without increasing the total portion.",
    ],
    tips: [
      "Mix the chia thoroughly before chilling for a more even texture.",
      "Five minutes describes active preparation; this breakfast also needs time in the fridge.",
    ],
    serving:
      "A make-ahead breakfast. Keep refrigerated and follow the storage guidance on your ingredients.",
  },
  "yogurt-crunch": {
    name: "A little golden crunch",
    nameZh: "酸奶莓果脆麦碗",
    equipment: "Shallow bowl, spoon and small knife",
    waiting: "About 3 minutes of active preparation; no cooking",
    steps: [
      "Measure the plain yogurt, berry muesli, strawberries and almonds using your current ingredient list. Check the actual ingredient and allergen labels.",
      "Wash the strawberries, drain well, then remove the tops and slice. Washing before slicing helps keep excess water out of the bowl.",
      "Spoon the yogurt into a shallow bowl and smooth it with the back of a spoon. Stir any separated whey back in for an even base.",
      "Scatter the muesli over one side rather than mixing it all through. Leave the other side smooth for a contrast of textures.",
      "Add the sliced strawberries and chopped almonds in the quantities shown above. Keep to the recipe rather than adding extra syrups.",
      "Combine each spoonful as you eat. Assemble shortly before serving so the muesli keeps its crunch.",
    ],
    tips: [
      "Keeping the yogurt and muesli separate until eating preserves texture.",
      "For dairy or nut exclusions, update your preferences and choose a compatible recipe.",
    ],
    serving: "A quick, no-cook bowl, best assembled just before eating.",
  },
  "banana-protein": {
    name: "Your morning fuel",
    nameZh: "香蕉可可蛋白燕麦",
    equipment: "Small saucepan, bowl and spoon",
    waiting: "About 7 minutes of active preparation",
    steps: [
      "Measure the oats, soy drink, plant protein powder, banana, almond butter and cocoa using your current list. Slice the banana and combine the dry powders.",
      "Bring the oats and soy drink to a gentle simmer. Cook on low for about 4 minutes, stirring the base. Follow the packet's cooking guidance.",
      "Take the pan off the heat. Spoon a little of the hot liquid into a small bowl and gradually stir in the protein powder and cocoa to make a smooth paste.",
      "Stir the paste back into the oats off the heat. This helps avoid dry lumps; do not tip a whole spoonful of powder into a rapidly boiling pan.",
      "Spoon into a bowl, arrange the banana slices and finish with the measured almond butter. Use your current quantities.",
      "Let cool briefly and check for a smooth texture. If it feels too thick, use the feedback control to save a suitable liquid adjustment.",
    ],
    tips: [
      "Mixing the powder with a little of the original liquid first makes it easier to combine.",
      "Protein powders and plant drinks vary. Check the actual pack for ingredients, allergens and nutrition.",
    ],
    serving:
      "Enjoy as a single bowl; the estimated protein value is not a personal nutrition target.",
  },
  "chia-cloud": {
    name: "A softer start",
    nameZh: "蓝莓椰香奇亚布丁",
    equipment: "Lidded container and fork or whisk",
    waiting:
      "About 4 minutes active preparation, plus a short rest and at least 2 hours chilling",
    steps: [
      "Measure the soy drink into a clean container, then add the chia seeds. Stir thoroughly with a fork or small whisk to disperse them evenly.",
      "Let stand for about 5 minutes, then stir again from the bottom to break up clumps as the seeds start absorbing liquid.",
      "Cover and refrigerate for at least 2 hours, or overnight. The active preparation estimate does not include setting time.",
      "Stir before serving and check for dry clumps. The pudding should be spoonable. Use saved feedback if you prefer a looser or firmer texture.",
      "Wash and drain the blueberries. Arrange the measured portion on top, or gently crush some of the existing berries for a more even fruit flavour.",
      "Finish with the coconut flakes and enjoy. Check the actual soy drink and coconut labels for ingredients and allergens.",
    ],
    tips: [
      "A second stir after the short rest helps prevent clumps and separation.",
      "Allow time for hydration and chilling; four minutes of preparation does not mean instant pudding.",
    ],
    serving:
      "A chilled breakfast you can prepare ahead. Follow the storage instructions on your ingredients.",
  },
  "savory-oats": {
    name: "Something savoury",
    nameZh: "菠菜鸡蛋咸味燕麦",
    equipment: "Small saucepan, non-stick pan and spoon",
    waiting: "About 10 minutes of active preparation",
    steps: [
      "Measure the oats, water, spinach, egg and sesame oil using your current list. Wash and drain the spinach, cutting larger leaves into smaller pieces.",
      "Bring the oats and water to a gentle simmer. Cook on low for about 5 minutes, stirring occasionally. Follow the oat pack if it needs a different cooking time.",
      "Stir in the spinach until completely wilted and evenly mixed through the oats. Turn off the heat and spoon into a bowl.",
      "In a separate non-stick pan, cook the egg thoroughly, or prepare a fully cooked boiled egg. Clean hands and utensils after handling raw egg.",
      "Place the cooked egg on the oats and finish with the recipe's sesame oil. Keep to the existing ingredients rather than adding extra seasoning.",
      "Let cool to a comfortable temperature and enjoy the egg, spinach and oats together. If it tastes bland, leave feedback to adjust how the existing ingredients are prepared.",
    ],
    tips: [
      "Soften the oats before adding spinach for an even texture.",
      "This recipe contains egg and oats; also check sesame and other pack labels against your needs.",
    ],
    serving:
      "A warm option for savoury breakfast lovers, best prepared in a single serving and enjoyed promptly.",
  },
};
