import { recipes } from "./catalog";
import { recipeMethods } from "./recipe-methods";
import { rankRecipes } from "./recommendation";
import type { UserState } from "./types";

const normalise = (text: string) => text.toLowerCase().replace(/[’‘]/g, "'").replace(/\s+/g, " ").trim();

export function recipeIdsInText(text: string): string[] {
  const value = normalise(text);
  return recipes.filter((r) => [r.name, recipeMethods[r.id].name, recipeMethods[r.id].nameZh, r.id]
    .some((name) => value.includes(normalise(name)))).map((r) => r.id);
}

// A comparison is a UI selection made by the user, not an extraction task
// delegated to the model. A renamed/extra recipe in model prose must not
// change what the subsequent "save it" request is asking to choose between.
export function comparisonRecipeCards(text: string): string[] | undefined {
  const named = recipeIdsInText(text);
  return named.length > 1 && /\b(compare|comparison|versus|vs|between)\b|比较|对比|区别/i.test(text)
    ? named
    : undefined;
}

export function wantsToSaveRecipe(text: string): boolean {
  const value = normalise(text);
  if (/\b(don't|do not|never|not now|how|why|can i|could i|if)\b|不要|别收藏|不想|怎么|如何|如果/.test(value)) return false;
  if (/\b(cart|basket|checkout|order)\b|购物车|下单|付款/.test(value)) return false;
  if (/\bsave\s+(?:money|time|\d)/.test(value)) return false;
  const saveObject = /\b(it|this|that|recipe|recipes|breakfast|bowl)\b/.test(value) || recipeIdsInText(value).length > 0 || /^(?:save|bookmark|favou?rite)$/.test(value);
  return (/^(?:(?:please|can you|could you|would you)\s+)*(?:save|bookmark|favou?rite)\b/.test(value) && saveObject)
    || /^(?:(?:please|can you|could you|would you)\s+)*add\b.*\b(?:my recipes?|my saved|favou?rites?|saved list)\b/.test(value)
    || /^(?:请|帮我|麻烦|把|将|这个|这道|这份|它)*(?:收藏|保存|加入|添加到|存到)/.test(value);
}

export function chatSaveTarget(state: UserState, text: string, requested?: string) {
  const named = recipeIdsInText(text);
  const last = [...state.messages].reverse().find((m) => m.role === "assistant");
  const lastChoices = last ? (last.recipeCards?.length ? last.recipeCards : recipeIdsInText(last.content)) : [];
  const candidates = named.length ? named
    : lastChoices.length > 1 ? lastChoices
    : requested && recipes.some((r) => r.id === requested) ? [requested]
    : lastChoices;
  const unique = [...new Set(candidates)].filter((id) => recipes.some((r) => r.id === id));
  const eligible = new Set(rankRecipes(state.profile, state.feedback).map((r) => r.recipe.id));
  return {
    recipeId: unique.length === 1 && eligible.has(unique[0]) ? unique[0] : undefined,
    choices: unique.filter((id) => eligible.has(id)),
    excluded: unique.length === 1 && !eligible.has(unique[0]),
  };
}

export function saveRecipeToState(state: UserState, recipeId: string) {
  if (!rankRecipes(state.profile, state.feedback).some((r) => r.recipe.id === recipeId)) return false;
  if (!state.favorites.includes(recipeId)) state.favorites.push(recipeId);
  return true;
}
