import { recipeDraftSchema, type RecipeDraft } from "./breakfast";
export class RecipeReviewError extends Error {}
export async function reviewedRecipe(
  generate: (correction?: string) => Promise<string>,
  review: (r: RecipeDraft) => string | undefined,
): Promise<RecipeDraft> {
  const started = Date.now();
  let correction: string | undefined;
  for (let attempt = 0; attempt < 2; attempt++) {
    const content = await generate(correction);
    let json: unknown;
    try {
      json = JSON.parse(content);
    } catch {
      json = null;
    }
    const parsed = recipeDraftSchema.safeParse(
      (json as { recipe?: unknown } | null)?.recipe,
    );
    correction = parsed.success
      ? review(parsed.data)
      : "Return the declared JSON recipe schema, with numeric measured ingredients and valid units.";
    if (parsed.success && !correction) return parsed.data;
    if (Date.now() - started > 40000) break;
  }
  throw new RecipeReviewError(
    "AI could not satisfy the selected constraints after review.",
  );
}
