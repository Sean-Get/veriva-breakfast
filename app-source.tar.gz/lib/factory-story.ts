export const factoryScenes = [
  {
    id: "workshop",
    label: "The workshop",
    image: "/images/factory-workshop-v1.webp",
    title: "A little craft. In every spoonful.",
    alt: "AI illustration of a bright oat workshop with stainless steel equipment, wooden beams and alpine views",
    description:
      "Step into an imagined breakfast workshop: light-filled spaces, familiar grains and the people bringing them together. Explore the small moments between a raw ingredient and a ready-to-open pack.",
  },
  {
    id: "ingredients",
    label: "Choose & check",
    image: "/images/factory-grain-check-v1.webp",
    title: "Start with the grain.",
    alt: "AI illustration of gloved hands examining rolled oats beside ingredient samples",
    description:
      "Before thinking about a finished bowl, look closely at the ingredients. Flake size, the texture of the grain and the choice of fruit or seeds all help explain why breakfast blends feel different.",
    details: [
      "Explore the shape and texture of oat flakes.",
      "Notice the different seeds and grains in a blend.",
      "Use the real pack to check ingredients and allergens.",
    ],
    sourceNote:
      "Verival describes selecting organically grown raw ingredients and working with long-term partners.",
    source: "https://www.verival.at/en/pages/zutaten",
  },
  {
    id: "mixing",
    label: "Blend the recipe",
    image: "/images/factory-blending-v1.webp",
    title: "Bring the little things together.",
    alt: "AI illustration of oats, dried berries and pumpkin seeds being blended in a steel basin",
    description:
      "A breakfast blend is a meeting of textures: soft flakes, fruit pieces and a little crunch. This scene makes that combination visible, before milk, yogurt or your own toppings enter the story.",
    details: [
      "See the dry ingredients before preparation.",
      "Compare the grain base with the fruit and seeds.",
      "Different products use different recipes and proportions.",
    ],
    sourceNote:
      "The brand says its breakfast products are mixed and filled by hand in Tyrol.",
    source: "https://www.verival.at/en/pages/ueber-uns",
  },
  {
    id: "packing",
    label: "Fill & pack",
    image: "/images/factory-packing-v1.webp",
    title: "Ready for your cupboard.",
    alt: "AI illustration of a gloved worker placing an unbranded sealed breakfast pouch on a weighing station",
    description:
      "The loose blend becomes a pantry product. A clear pack gives you the information needed for your own kitchen: what is inside, how much to use and how to keep it after opening.",
    details: [
      "Check the actual pack size and preparation guide.",
      "Read the allergen statement before choosing a product.",
      "Follow the storage and best-before information on the pack.",
    ],
    sourceNote:
      "Verival's FAQ explains the role of packaging in protecting breakfast products from environmental influences.",
    source: "https://www.verival.at/en/pages/faqs",
  },
  {
    id: "dispatch",
    label: "Send it on its way",
    image: "/images/factory-dispatch-v1.webp",
    title: "The last stop before your first spoonful.",
    alt: "AI illustration of a worker arranging plain shipping boxes beside breakfast pouches in a tidy dispatch area",
    description:
      "Packing an order connects the workshop with someone's everyday morning. From there, the breakfast story continues with the way you prepare, serve and share it.",
    details: [
      "Explore the packing and dispatch part of the story.",
      "Use the Shop page for buying links and nearby places.",
      "Check delivery coverage and availability with the actual seller.",
    ],
    sourceNote:
      "Verival describes packing and dispatching breakfast products from its Langkampfen production facility.",
    source: "https://www.verival.at/en/pages/ueber-uns",
  },
] as const;
