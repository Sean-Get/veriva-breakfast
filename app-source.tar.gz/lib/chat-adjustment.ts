import { recipes } from "./catalog";
import { rankRecipes } from "./recommendation";
import { feedbackIntent } from "./personalisation";
import { recipeMethods } from "./recipe-methods";
import type { UserState, Message, Feedback } from "./types";
export function conversationRecipeId(
  state: UserState,
  message: string,
  requested?: string,
) {
  const mentioned = recipes.find(
    (r) =>
      message.toLowerCase().includes(r.name.toLowerCase()) ||
      message.includes(recipeMethods[r.id].nameZh),
  );
  const history = [...state.messages]
    .reverse()
    .find((m) => m.recipeId || m.proposal?.recipeId);
  const candidate =
    mentioned?.id ||
    (requested !== undefined
      ? requested
      : history?.recipeId || history?.proposal?.recipeId);
  return candidate && recipes.some((r) => r.id === candidate)
    ? candidate
    : undefined;
}
export function chatAdjustmentProposal(
  state: UserState,
  message: string,
  recipeId?: string,
): Message["proposal"] {
  const intent = feedbackIntent({
    tags: [],
    note: message,
  } as unknown as Feedback);
  if (
    !Object.values(intent).some(Boolean) ||
    /不要修改|不用改|不想改|do not change|don't change/i.test(message)
  )
    return undefined;
  const eligible = rankRecipes(state.profile, state.feedback);
  const mentioned = recipes.find(
    (r) =>
      message.toLowerCase().includes(r.name.toLowerCase()) ||
      message.includes(recipeMethods[r.id].nameZh),
  );
  const target =
    mentioned?.id ||
    conversationRecipeId(state, message, recipeId) ||
    state.aiPick?.recipeId ||
    eligible[0]?.recipe.id;
  if (!target || !eligible.some((r) => r.recipe.id === target))
    return undefined;
  return { recipeId: target, note: message.slice(0, 500) };
}
export function tagsForChatAdjustment(note: string) {
  const intent = feedbackIntent({ tags: [], note } as unknown as Feedback);
  return [
    intent.sweet ? "Too sweet" : null,
    intent.bland ? "Too bland" : null,
    intent.thick ? "Too thick" : null,
    intent.thin ? "Too thin" : null,
  ].filter((v): v is string => !!v);
}
