const people = [
  "Nora",
  "Luca",
  "Maya",
  "Theo",
  "Amira",
  "Jules",
  "Harper",
  "Elena",
  "Owen",
  "Sam",
  "Isla",
  "Alex",
  "Finn",
  "Cleo",
  "Mia",
  "Leo",
];
export const samplePortraits: Record<string, string> = Object.fromEntries(
  people.map((name) => [
    name,
    `/images/community/avatar-${name.toLowerCase()}-v1.webp`,
  ]),
);
export const sampleBreakfastPhotos: Record<
  string,
  { src: string; alt: string; caption: string }
> = {
  "sample-finn": {
    src: "/images/community/pear-toast-v1.webp",
    alt: "Pear toast with yogurt at a kitchen table",
    caption: "Pear toast, before the day gets busy.",
  },
  "sample-cleo": {
    src: "/images/community/sunday-table-v1.webp",
    alt: "A relaxed Sunday breakfast spread with oats, toast and fruit",
    caption: "A little of everything for a slow Sunday.",
  },
  "sample-nora": {
    src: "/images/community/berry-bowl-v1.webp",
    alt: "A homemade berry oat bowl with pumpkin seeds and a spoon",
    caption: "Warm oats, berries straight from the fridge.",
  },
  "sample-maya": {
    src: "/images/community/bircher-jar-v1.webp",
    alt: "A jar of overnight apple oats beside a kitchen window",
    caption: "Prepared last night. Apple added this morning.",
  },
};
