export type Goal = "energy" | "protein" | "less-sugar";
export type HealthRecord = {
  age: number | null;
  heightCm: number | null;
  weightKg: number | null;
  notes: string;
  useForAI: boolean;
};
export const defaultHealth = (): HealthRecord => ({
  age: null,
  heightCm: null,
  weightKg: null,
  notes: "",
  useForAI: false,
});
export type Profile = {
  name: string;
  goals: Goal[];
  diet: string[];
  minutes: number;
  activity: "light" | "moderate" | "active";
  onboarded: boolean;
  health?: HealthRecord;
};
export type RecipeRevision = {
  id: string;
  feedbackId: string;
  recipeId: string;
  sweetnessFactor: number;
  liquidFactor: number;
  flavourMethod: "none" | "toast-oats" | "crush-fruit" | "rest-longer";
  summary: string;
  createdAt: string;
  context: string;
};
export type Feedback = {
  id: string;
  recipeId: string;
  rating: number;
  tags: string[];
  note: string;
  createdAt: string;
};
export type CartItem = { productId: string; quantity: number };
export type Message = {
  role: "user" | "assistant";
  content: string;
  recipeId?: string;
  proposal?: { recipeId: string; note: string };
  recipeCards?: string[];
  savedRecipeId?: string;
  assistantProposalId?: string;
  assistantResult?: string;
  personalRecipeId?: string;
};
export type Order = {
  id: string;
  createdAt: string;
  items: CartItem[];
  total: number;
  status: "Demo order";
};
export type CommunityPost = {
  id: string;
  recipeId: string;
  name: string;
  text: string;
  createdAt: string;
};
export type UserState = {
  growth?: import("./growth").GrowthState;
  breakfast?: import("./breakfast").BreakfastState;
  profile: Profile;
  favorites: string[];
  feedback: Feedback[];
  cart: CartItem[];
  messages: Message[];
  orders: Order[];
  healthHistory?: { record: HealthRecord; recordedAt: string }[];
  revisions?: RecipeRevision[];
  aiUpdate?: {
    status: "updated" | "failed" | "unavailable";
    message: string;
    trigger: "profile" | "feedback" | "manual";
    at: string;
  };
  aiPick?: { recipeId: string; rationale: string; context: string } | null;
};
export type SessionUser = {
  id: string;
  name: string;
  email: string | null;
  guest: boolean;
};
export type AppData = {
  user: SessionUser;
  state: UserState;
  aiConfigured: boolean;
  community: CommunityPost[];
};
export const defaultState = (): UserState => ({
  profile: {
    name: "Friend",
    goals: ["energy"],
    diet: [],
    minutes: 10,
    activity: "moderate",
    onboarded: false,
    health: defaultHealth(),
  },
  favorites: [],
  feedback: [],
  cart: [],
  messages: [],
  orders: [],
});
