import { recipes, products, type Recipe } from "./catalog";
import type { Profile, Feedback, CartItem } from "./types";
import { feedbackIntent, revisedIngredients } from "./personalisation";
import type { RecipeRevision } from "./types";
export function preferenceKey(profile: Profile, feedback: Feedback[]) {
  return JSON.stringify({ profile, feedback: feedback.map((f) => f.id) });
}
export function rankRecipes(profile: Profile, feedback: Feedback[]) {
  const excluded = new Set(
    profile.diet.flatMap((d) => (d === "vegan" ? ["dairy", "eggs"] : d)),
  );
  const lessSweet = feedback.some((f) => feedbackIntent(f).sweet);
  const moreProtein = feedback.some((f) => f.tags.includes("More protein"));
  return recipes
    .filter(
      (r) =>
        r.minutes <= profile.minutes &&
        !r.allergens.some((a) => excluded.has(a)),
    )
    .map((recipe) => {
      let score = 0;
      const reasons: string[] = [];
      if (profile.goals.includes("energy")) {
        score += recipe.fiber * 3 + (recipe.category === "Warm bowls" ? 12 : 0);
        reasons.push(`${recipe.fiber} g fibre for a satisfying start`);
      }
      if (profile.goals.includes("protein") || moreProtein) {
        score += recipe.protein * 4;
        reasons.push(`${recipe.protein} g protein per serving`);
      }
      if (profile.goals.includes("less-sugar")) {
        score += Math.max(0, 20 - recipe.sugar) * 4;
        reasons.push("Prioritises recipes with less total sugar");
      }
      if (lessSweet) {
        score += Math.max(0, 20 - recipe.sugar) * 5;
        reasons.push("Adjusted to your lower sweetness preference");
      }
      if (feedback.some((f) => f.recipeId === recipe.id && f.rating >= 4))
        score += 8;
      score += Math.max(0, 10 - recipe.minutes) * 2;
      reasons.push(`Fits your ${profile.minutes}-minute morning`);
      return { recipe, reasons, score };
    })
    .sort((a, b) => b.score - a.score);
}
export function adjustedIngredients(
  recipe: Recipe,
  feedback: Feedback[],
  revision?: RecipeRevision,
) {
  if (revision) return revisedIngredients(recipe, revision);
  const lessSweet = feedback.some((f) => f.tags.includes("Too sweet"));
  return recipe.ingredients.map((i) =>
    i.honey && lessSweet ? { ...i, amount: "3.5 g" } : i,
  );
}
export function cartTotal(cart: CartItem[]) {
  return (
    Math.round(
      cart.reduce(
        (sum, i) =>
          sum +
          (products.find((p) => p.id === i.productId)?.price || 0) * i.quantity,
        0,
      ) * 100,
    ) / 100
  );
}
