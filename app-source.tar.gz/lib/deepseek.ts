import { ApiError } from "./http";
export async function callDeepSeek(
  messages: { role: string; content: string }[],
  json = false,
  maxTokens = 1000,
) {
  if (!process.env.DEEPSEEK_API_KEY)
    throw new ApiError(
      "DeepSeek is not configured. Your data is saved; configure the server key and retry.",
      503,
    );
  let response: Response;
  try {
    response = await fetch(
      (process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com").replace(
        /\/$/,
        "",
      ) + "/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: process.env.DEEPSEEK_MODEL || "deepseek-flash",
          messages,
          max_tokens: maxTokens,
          thinking: { type: "disabled" },
          stream: false,
          ...(json ? { response_format: { type: "json_object" } } : {}),
        }),
        signal: AbortSignal.timeout(50000),
      },
    );
  } catch {
    throw new ApiError(
      "DeepSeek could not connect. Your data is saved; retry the AI update.",
      504,
    );
  }
  if (!response.ok) {
    await response.body?.cancel();
    throw new ApiError(
      response.status === 402
        ? "DeepSeek has insufficient account balance. Your data is saved; top up and retry."
        : response.status === 401
          ? "The server API key was not accepted. Please check configuration."
          : "DeepSeek is temporarily unavailable. Your data is saved; please retry.",
      502,
    );
  }
  const result = await response.json(),
    content = result.choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content.trim())
    throw new ApiError("DeepSeek returned an empty answer. Please retry.", 502);
  return content;
}
