import { randomUUID } from "node:crypto";
import { database } from "./db";
import { products } from "./catalog";
import { ApiError } from "./http";
export type ProductReview = {
  id: string;
  productId: string;
  name: string;
  rating: number;
  text: string;
  hidden: boolean;
  createdAt: string;
};
function reviewDB() {
  const db = database();
  db.exec(`CREATE TABLE IF NOT EXISTS product_reviews (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
    product_id TEXT NOT NULL, name TEXT NOT NULL, rating INTEGER NOT NULL,
    text TEXT NOT NULL, hidden INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
  ); CREATE INDEX IF NOT EXISTS product_review_catalog ON product_reviews(product_id,created_at);`);
  return db;
}
export function validProduct(id: unknown): id is string {
  return products.some((p) => p.id === id);
}
const columns =
  "id,product_id AS productId,name,rating,text,hidden,created_at AS createdAt";
export function listProductReviews(productId?: string, admin = false) {
  const rows = reviewDB()
    .prepare(
      `SELECT ${columns} FROM product_reviews WHERE ${admin ? "1=1" : "hidden=0"} ${productId ? "AND product_id=?" : ""} ORDER BY created_at DESC,id DESC LIMIT 200`,
    )
    .all(...(productId ? [productId] : [])) as unknown as ProductReview[];
  return rows.map((r) => ({ ...r, hidden: !!r.hidden }));
}
export function productReviewPage(
  productId: string,
  filter = "All",
  requestedPage = 1,
) {
  if (!validProduct(productId)) throw new ApiError("Product not found.", 404);
  const db = reviewDB();
  const stats = db
    .prepare(
      `SELECT COUNT(*) total, AVG(rating) average,
    COALESCE(SUM(rating>=4),0) positive, COALESCE(SUM(rating=3),0) mixed,
    COALESCE(SUM(rating<=2),0) critical FROM product_reviews WHERE product_id=? AND hidden=0`,
    )
    .get(productId) as {
    total: number;
    average: number | null;
    positive: number;
    mixed: number;
    critical: number;
  };
  const rating =
    filter === "Positive"
      ? "AND rating>=4"
      : filter === "Mixed"
        ? "AND rating=3"
        : filter === "Critical"
          ? "AND rating<=2"
          : "";
  const total =
    filter === "Positive"
      ? stats.positive
      : filter === "Mixed"
        ? stats.mixed
        : filter === "Critical"
          ? stats.critical
          : stats.total;
  const pageSize = 8,
    pages = Math.max(1, Math.ceil(total / pageSize)),
    page = Math.min(
      pages,
      Math.max(
        1,
        Number.isFinite(requestedPage) ? Math.floor(requestedPage) : 1,
      ),
    );
  const rows = db
    .prepare(
      `SELECT ${columns} FROM product_reviews WHERE product_id=? AND hidden=0 ${rating} ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?`,
    )
    .all(
      productId,
      pageSize,
      (page - 1) * pageSize,
    ) as unknown as ProductReview[];
  return {
    reviews: rows.map((r) => ({ ...r, hidden: !!r.hidden })),
    stats,
    total,
    page,
    pages,
    pageSize,
  };
}
export function addProductReview(
  userId: string,
  body: Record<string, unknown>,
) {
  if (
    !validProduct(body.productId) ||
    typeof body.name !== "string" ||
    !body.name.trim() ||
    body.name.trim().length > 40 ||
    typeof body.text !== "string" ||
    body.text.trim().length < 5 ||
    body.text.trim().length > 1200 ||
    !Number.isInteger(body.rating) ||
    Number(body.rating) < 1 ||
    Number(body.rating) > 5
  )
    throw new ApiError(
      "Choose a product, a rating, a public name and a review of 5–1200 characters.",
    );
  const id = randomUUID();
  reviewDB()
    .prepare(
      "INSERT INTO product_reviews(id,user_id,product_id,name,rating,text,created_at) VALUES(?,?,?,?,?,?,?)",
    )
    .run(
      id,
      userId,
      body.productId,
      body.name.trim(),
      Number(body.rating),
      body.text.trim(),
      new Date().toISOString(),
    );
  return id;
}
export function moderateProductReview(id: string, hidden: boolean) {
  if (
    !reviewDB()
      .prepare("UPDATE product_reviews SET hidden=? WHERE id=?")
      .run(Number(hidden), id).changes
  )
    throw new ApiError("Review not found.", 404);
}
