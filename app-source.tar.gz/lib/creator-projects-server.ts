import { randomUUID } from "node:crypto";
import { z } from "zod";
import { database } from "./db";
import { ApiError } from "./http";
import { callDeepSeek } from "./deepseek";
import { growthSource } from "./growth-server";
import { mealFits, growthState } from "./growth";
import { getState } from "./db";
import {
  briefSchema,
  contentSchema,
  buildCreativeProject,
  ideaTemplates,
  type CreativeProject,
} from "./creator-ideas";
function db() {
  const d = database();
  d.exec(
    `CREATE TABLE IF NOT EXISTS creator_projects(id TEXT PRIMARY KEY,owner TEXT NOT NULL,revision INTEGER NOT NULL,json TEXT NOT NULL,request_id TEXT NOT NULL,UNIQUE(owner,request_id)); CREATE TABLE IF NOT EXISTS creator_bookmarks(owner TEXT NOT NULL,idea TEXT NOT NULL,PRIMARY KEY(owner,idea)); CREATE TABLE IF NOT EXISTS creator_events(id TEXT PRIMARY KEY,owner TEXT NOT NULL,kind TEXT NOT NULL,subject TEXT NOT NULL,created_at TEXT NOT NULL);`,
  );
  return d;
}
function event(owner: string, kind: string, subject: string) {
  db()
    .prepare("INSERT INTO creator_events VALUES(?,?,?,?,?)")
    .run(randomUUID(), owner, kind, subject, new Date().toISOString());
}
export function projectsOverview(owner: string) {
  const d = db();
  return {
    projects: (
      d
        .prepare(
          "SELECT json FROM creator_projects WHERE owner=? ORDER BY rowid DESC",
        )
        .all(owner) as { json: string }[]
    ).map((r) => JSON.parse(r.json) as CreativeProject),
    bookmarks: (
      d
        .prepare("SELECT idea FROM creator_bookmarks WHERE owner=?")
        .all(owner) as { idea: string }[]
    ).map((r) => r.idea),
    events: d
      .prepare(
        "SELECT kind,COUNT(*) AS count FROM creator_events WHERE owner=? GROUP BY kind",
      )
      .all(owner),
  };
}
function read(owner: string, id: string): CreativeProject {
  const row = db()
    .prepare("SELECT json FROM creator_projects WHERE id=? AND owner=?")
    .get(id, owner) as { json: string } | undefined;
  if (!row)
    throw new ApiError("This project is unavailable in your workspace.", 404);
  return JSON.parse(row.json);
}
function commit(owner: string, p: CreativeProject, revision: number) {
  p.revision = revision + 1;
  p.updatedAt = new Date().toISOString();
  const r = db()
    .prepare(
      "UPDATE creator_projects SET revision=?,json=? WHERE id=? AND owner=? AND revision=?",
    )
    .run(p.revision, JSON.stringify(p), p.id, owner, revision);
  if (!r.changes)
    throw new ApiError(
      "This project changed in another window. Reload the saved version before editing again.",
      409,
    );
  return { project: p };
}
const identity = z.object({
  id: z.string().uuid(),
  revision: z.number().int().min(1),
});
export async function projectAction(
  owner: string,
  body: Record<string, unknown>,
) {
  const action = z
    .enum([
      "bookmark",
      "create",
      "update",
      "duplicate",
      "delete",
      "suggest",
      "progress",
      "event",
    ])
    .parse(body.action);
  if (action === "bookmark") {
    const { ideaId, on } = z
      .object({ ideaId: z.string(), on: z.boolean() })
      .parse(body);
    if (!ideaTemplates.some((i) => i.id === ideaId))
      throw new ApiError("Unknown idea.");
    if (on)
      db()
        .prepare("INSERT OR IGNORE INTO creator_bookmarks VALUES(?,?)")
        .run(owner, ideaId);
    else
      db()
        .prepare("DELETE FROM creator_bookmarks WHERE owner=? AND idea=?")
        .run(owner, ideaId);
    return { ok: true };
  }
  if (action === "event") {
    const input = z
      .object({
        kind: z.enum(["idea-open", "plan-exported"]),
        subject: z.string().max(100),
      })
      .parse(body);
    if (input.kind === "plan-exported") read(owner, input.subject);
    else if (!ideaTemplates.some((i) => i.id === input.subject))
      throw new ApiError("Unknown idea.");
    event(owner, input.kind, input.subject);
    return { ok: true };
  }
  if (action === "create") {
    const b = z
      .object({
        requestId: z.string().uuid(),
        ideaId: z.string().max(60),
        recipeId: z.string().max(100),
        shareId: z.string().max(100).optional(),
        companionId: z.string().max(100).optional(),
        brief: briefSchema,
        legacy: z.boolean().optional(),
      })
      .parse(body);
    const existing = db()
      .prepare(
        "SELECT json FROM creator_projects WHERE owner=? AND request_id=?",
      )
      .get(owner, b.requestId) as { json: string } | undefined;
    if (existing) return { project: JSON.parse(existing.json) };
    if (
      (
        db()
          .prepare("SELECT count(*) AS n FROM creator_projects WHERE owner=?")
          .get(owner) as { n: number }
      ).n >= 100
    )
      throw new ApiError(
        "You have 100 projects. Delete a project before creating another.",
      );
    let p: CreativeProject;
    try {
      p = buildCreativeProject(
        growthSource(owner, b.recipeId, b.shareId),
        b.ideaId,
        b.brief,
        b.companionId ? growthSource(owner, b.companionId) : undefined,
      );
    } catch (e) {
      if (e instanceof ApiError) throw e;
      throw new ApiError((e as Error).message);
    }
    if (
      !mealFits(p.meal, getState(owner)) ||
      (p.companion && !mealFits(p.companion, getState(owner)))
    )
      throw new ApiError(
        "Adapt these recipes to your current food preferences before filming.",
      );
    p.id = randomUUID();
    p.revision = 1;
    p.createdAt = p.updatedAt = new Date().toISOString();
    p.requestId = b.requestId;
    if (b.shareId) p.sourceShare = b.shareId;
    if (b.legacy) {
      const kit = growthState(getState(owner)).kitDrafts.find(
        (k) => k.mealId === p.meal.id,
      )?.kit;
      if (!kit)
        throw new ApiError(
          "The old content kit is unavailable. Start with a template instead.",
        );
      p.hook = kit.hook.slice(0,300);
      p.caption = kit.caption;
      p.method =
        "Imported classic hook and caption · new recipe-linked storyboard";
    }
    db()
      .prepare("INSERT INTO creator_projects VALUES(?,?,?,?,?)")
      .run(p.id, owner, 1, JSON.stringify(p), b.requestId);
    event(owner, "project-created", p.id);
    return { project: p };
  }
  const input = identity.parse(body),
    p = read(owner, input.id);
  if (p.revision !== input.revision)
    throw new ApiError(
      "This project changed in another window. Reload the saved version.",
      409,
    );
  if (action === "delete") {
    db()
      .prepare(
        "DELETE FROM creator_projects WHERE id=? AND owner=? AND revision=?",
      )
      .run(p.id, owner, p.revision);
    return { ok: true };
  }
  if (action === "duplicate") {
    const requestId = z.string().uuid().parse(body.requestId);
    const old = db()
      .prepare(
        "SELECT json FROM creator_projects WHERE owner=? AND request_id=?",
      )
      .get(owner, requestId) as { json: string } | undefined;
    if (old) return { project: JSON.parse(old.json) };
    if (
      (
        db()
          .prepare("SELECT count(*) AS n FROM creator_projects WHERE owner=?")
          .get(owner) as { n: number }
      ).n >= 100
    )
      throw new ApiError("Delete a project before creating another.");
    const q = {
      ...p,
      id: randomUUID(),
      requestId,
      revision: 1,
      title: `${p.title.slice(0, 110)} (copy)`,
      progress: p.shots.map(() => "pending" as const),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    db()
      .prepare("INSERT INTO creator_projects VALUES(?,?,?,?,?)")
      .run(q.id, owner, 1, JSON.stringify(q), requestId);
    event(owner, "project-created", q.id);
    return { project: q };
  }
  if (action === "progress") {
    const { index, status } = z
      .object({
        index: z.number().int().min(0),
        status: z.enum(["pending", "captured", "skipped"]),
      })
      .parse(body);
    if (index >= p.shots.length) throw new ApiError("Choose an existing shot.");
    p.progress[index] = status;
    const result = commit(owner, p, input.revision);
    event(owner, "shot-marked", p.id);
    return result;
  }
  if (action === "update") {
    const c = contentSchema.parse(body.content);
    if (c.shots.reduce((n, s) => n + s.seconds, 0) !== p.brief.seconds)
      throw new ApiError(
        `Shot durations must add up to your ${p.brief.seconds}-second target.`,
      );
    if (
      new Set(c.shots.map((s) => s.id)).size !== c.shots.length ||
      c.shots.some((s) => {
        const original = p.shots.find((v) => v.id === s.id);
        return (
          !original ||
          s.recipeStep !== original.recipeStep ||
          s.action !== original.action
        );
      })
    )
      throw new ApiError("Keep the existing shot identities and recipe links.");
    const progress = c.shots.map(
      (s) => p.progress[p.shots.findIndex((v) => v.id === s.id)],
    );
    const result = commit(owner, { ...p, ...c, progress }, input.revision);
    event(owner, "project-saved", p.id);
    return result;
  }
  // Only narrative fields may be suggested. Ingredient amounts and recipe actions remain fixed.
  const { note } = z
    .object({ note: z.string().max(300).default("") })
    .parse(body);
  const output = await callDeepSeek(
    [
      {
        role: "system",
        content:
          "You help breakfast creators film a real recipe. Return JSON {hook,caption,shots:[{id,caption,angle}]}. Keep exact shot IDs/order. Suggest only framing and narrative. Respect phone setup, scene and target seconds. No added ingredients/equipment, nutrition/medical claims, prices, popularity, invented tasting or audience feedback. Do not put ingredient quantities or new preparation instructions in captions. Do not claim a video is filmed or uploaded. Content language follows brief. Never change cooking or waiting time.",
      },
      {
        role: "user",
        content: JSON.stringify({
          brief: p.brief,
          note,
          recipe: {
            name: p.meal.name,
            ingredients: p.meal.ingredients,
            steps: p.meal.steps,
            activeMinutes: p.meal.activeMinutes,
            waitingMinutes: p.meal.waitingMinutes,
          },
          hook: p.hook,
          shots: p.shots,
        }),
      },
    ],
    true,
    1900,
  );
  let suggestion: {
    hook: string;
    caption: string;
    shots: { id: string; caption: string; angle: string }[];
  };
  try {
    suggestion = z
      .object({
        hook: z.string().max(300),
        caption: z.string().max(1800),
        shots: z
          .array(
            z.object({
              id: z.string(),
              caption: z.string().max(300),
              angle: z.string().max(180),
            }),
          )
          .max(12),
      })
      .parse(JSON.parse(output));
  } catch {
    throw new ApiError(
      "AI returned an invalid suggestion. Your saved project is unchanged.",
      502,
    );
  }
  if (
    suggestion.shots.length !== p.shots.length ||
    suggestion.shots.some((s, i) => s.id !== p.shots[i].id)
  )
    throw new ApiError(
      "AI changed the shot structure. Your saved project is unchanged.",
      502,
    );
  if (read(owner, p.id).revision !== input.revision)
    throw new ApiError(
      "The project changed while AI was working. Your edits have been kept.",
      409,
    );
  return {
    suggestion: {
      ...p,
      hook: suggestion.hook,
      caption: suggestion.caption,
      shots: p.shots.map((s, i) => ({
        ...s,
        caption: suggestion.shots[i].caption,
        angle: suggestion.shots[i].angle,
      })),
      method: "AI narrative suggestion · recipe actions unchanged",
    },
  };
}
