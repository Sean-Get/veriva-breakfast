import { z } from "zod";
import { foodSnapshot, constraintsSatisfied, type GrowthMeal } from "./growth";
export const briefSchema = z.object({
  seriesTitle: z.string().trim().max(70).default(""),
  episode: z.number().int().min(1).max(100).default(1),
  setup: z.enum(["phone", "tripod"]).default("phone"),
  setting: z
    .enum(["dorm desk", "home kitchen", "café-style table"])
    .default("home kitchen"),
  equipment: z
    .enum(["any", "no-cook", "microwave", "stove", "kettle"])
    .default("any"),
  seconds: z.union([z.literal(15), z.literal(30), z.literal(60)]).default(30),
  language: z.enum(["en", "zh"]).default("en"),
  note: z.string().trim().max(300).default(""),
});
export type CreativeBrief = z.infer<typeof briefSchema>;
export const shotSchema = z.object({
  id: z.string().max(80),
  title: z.string().min(1).max(120),
  action: z.string().min(1).max(1800),
  angle: z.string().max(180),
  seconds: z.number().int().min(1).max(60),
  caption: z.string().max(300),
  recipeStep: z.number().int().min(0).optional(),
});
export type ShotPlan = z.infer<typeof shotSchema>;
export const contentSchema = z.object({
  title: z.string().trim().min(1).max(120),
  hook: z.string().max(300),
  caption: z.string().max(1800),
  shots: z.array(shotSchema).min(3).max(12),
});
export type ProjectContent = z.infer<typeof contentSchema>;
export type CreativeProject = ProjectContent & {
  sourceShare?: string;
  id: string;
  revision: number;
  ideaId: string;
  meal: GrowthMeal;
  companion?: GrowthMeal;
  brief: CreativeBrief;
  preparation: string[];
  progress: ("pending" | "captured" | "skipped")[];
  createdAt: string;
  updatedAt: string;
  requestId: string;
  method: string;
};
export const ideaTemplates = [
  {
    id: "quiet-morning",
    title: "A Quiet Morning",
    angle: "A small pause before the day begins.",
    category: "diary",
    recipe: "berry-oats",
    visual: "Warm light, a still camera, your own morning.",
  },
  {
    id: "five-minute",
    title: "Before My First Class",
    angle: "A breakfast that fits the time you actually have.",
    category: "tutorial",
    recipe: "concept-mango",
    visual: "Ingredients, a few practical steps, ready to go.",
  },
  {
    id: "texture",
    title: "Listen to Breakfast",
    angle: "Let the ingredients and the spoon tell the story.",
    category: "texture",
    recipe: "concept-berry",
    visual: "Close details, natural sound, the finished texture.",
  },
  {
    id: "local-flavour",
    title: "A Familiar Flavour, A New Bowl",
    angle: "Explore a familiar ingredient in a different breakfast.",
    category: "remix",
    recipe: "concept-sesame",
    visual: "Introduce the ingredient, then show how it becomes a bowl.",
  },
  {
    id: "overnight",
    title: "Tonight for Tomorrow",
    angle: "One preparation, two moments in your day.",
    category: "diary",
    recipe: "overnight-bircher",
    visual: "An evening setup and an honest next-morning reveal.",
  },
  {
    id: "two-ways",
    title: "Same Oats, Two Ways",
    angle: "Two real recipes. Which would you make?",
    category: "remix",
    recipe: "berry-oats",
    visual: "Match the framing, then show both finished versions.",
  },
  {
    id: "make-it-mine",
    title: "I Changed One Thing",
    angle: "Show the recipe change you have actually saved.",
    category: "remix",
    recipe: "concept-apple",
    visual: "Explain the original, the change, and your actual result.",
  },
  {
    id: "series",
    title: "One Box, More Mornings",
    angle: "Start a recurring breakfast series with this episode.",
    category: "tutorial",
    recipe: "concept-cocoa",
    visual: "A repeatable opening and your first complete episode.",
  },
] as const;
export function ideaCompatibility(
  meal: GrowthMeal,
  id: string,
  b: CreativeBrief,
  companion?: GrowthMeal,
): string {
  if (!ideaTemplates.some((t) => t.id === id))
    return "Choose an available idea.";
  const steps = meal.steps.join(" ").toLowerCase();
  if (
    !constraintsSatisfied(meal, {
      equipment: b.equipment,
      temperature: "any",
      sweetness: "regular",
      texture: "creamy",
      servings: meal.servings,
      avoid: "",
    })
  )
    return "The recipe needs different kitchen equipment. Adapt it in Make It Mine first.";
  if (id === "five-minute" && meal.activeMinutes + meal.waitingMinutes > 5)
    return "This recipe takes more than five minutes including waiting. Choose a different recipe or idea.";
  if (
    id === "overnight" &&
    (!meal.waitingMinutes || !/chill|refrigerat|overnight/.test(steps))
  )
    return "Choose a recipe with a real refrigerated waiting stage.";
  if (id === "make-it-mine" && (!meal.parentId || meal.parentId === meal.id))
    return "Save your own version in Make It Mine first, then return to film it.";
  if (id === "two-ways" && (!companion || companion.id === meal.id))
    return "Choose a second, different recipe for the comparison.";
  if (
    b.equipment === "no-cook" &&
    /heat|simmer|boil|microwave|cook on|stove/.test(steps)
  )
    return "This recipe includes heating. Adapt the recipe in Make It Mine before filming without heat.";
  if (
    b.equipment === "microwave" &&
    /simmer|stovetop|saucepan|hob/.test(steps) &&
    !/microwave/.test(steps)
  )
    return "These steps use a stove. Adapt them to your microwave first.";
  if (
    b.equipment === "kettle" &&
    /simmer|saucepan|microwave|stovetop/.test(steps)
  )
    return "These steps need more than a kettle. Adapt the recipe first.";
  if (companion && id === "two-ways")
    return ideaCompatibility(companion, "quiet-morning", b);
  return "";
}
export function buildCreativeProject(
  meal: GrowthMeal,
  ideaId: string,
  brief: CreativeBrief,
  companion?: GrowthMeal,
): CreativeProject {
  const idea = ideaTemplates.find((t) => t.id === ideaId);
  if (!idea) throw Error("Choose an available idea.");
  const reason = ideaCompatibility(meal, ideaId, brief, companion);
  if (reason) throw Error(reason);
  const zh = brief.language === "zh";
  const amounts = meal.ingredients
    .map((i) => `${i.amount} ${i.unit} ${i.name}`)
    .join(", ");
  const shots: ShotPlan[] = [
    {
      id: "opening",
      title:
        ideaId === "series"
          ? `Episode ${brief.episode} · Your recurring opening`
          : "Opening moment",
      action: `Set out the ingredients at your ${brief.setting}. ${idea.visual}`,
      angle:
        brief.setup === "tripod"
          ? "Fixed wide shot on tripod"
          : "Rest your phone on a stable surface; fixed wide shot",
      seconds: 3,
      caption: zh ? "从这一碗开始今天。" : idea.angle,
    },
    {
      id: "ingredients",
      title:
        ideaId === "texture"
          ? "Listen to the ingredients"
          : "What goes into the bowl",
      action: `Measure and show ${amounts}. ${ideaId === "texture" ? "Record the natural ingredient sounds without adding artificial crunch claims." : ""}`,
      angle:
        ideaId === "texture"
          ? "Close-up, keep the microphone nearby"
          : "Overhead or 45° close-up",
      seconds: 3,
      caption: zh
        ? "按食谱准备实际用量。"
        : "The ingredients, measured for this recipe.",
    },
    ...meal.steps.map((step, i) => ({
      id: `step-${i}`,
      title: `${ideaId === "overnight" ? (i === 0 ? "Tonight" : "Preparation") : ideaId === "texture" ? "Texture detail" : "Make the breakfast"} · ${i + 1}`,
      action: step,
      angle:
        ideaId === "texture"
          ? "Fixed close-up of the actual texture"
          : "45° detail; keep the camera clear of heat and splashes",
      seconds: 2,
      caption: zh
        ? `制作步骤 ${i + 1}，完整做法见食谱。`
        : `Step ${i + 1}. Full method in the recipe.`,
      recipeStep: i,
    })),
    {
      id: "serving",
      title:
        ideaId === "overnight"
          ? "After the required chilling time"
          : ideaId === "make-it-mine"
            ? "Your saved variation"
            : "The finished bowl",
      action: `Show the actual finished ${meal.name}. ${ideaId === "make-it-mine" ? "Describe your saved change; add a taste reaction only after trying it." : "Capture a spoonful and add your own honest taste notes."}`,
      angle: "Side close-up, then a still serving shot",
      seconds: 3,
      caption: zh
        ? "试吃后，写下你自己的真实感受。"
        : "Add your own taste notes after trying it.",
    },
  ];
  if (ideaId === "two-ways" && companion)
    shots.push({
      id: "comparison",
      title: "Your second recipe",
      action: `Prepare ${companion.name} following its complete method in the recipe section. Film its main preparation action, then show both bowls. Do not omit either recipe’s cooking or waiting time.`,
      angle: "Matching overhead frames, then side by side",
      seconds: 4,
      caption: zh
        ? "两种真实做法，你想试哪一种？"
        : "Two recipes. Which would you try?",
    });
  // At most twelve shots; long methods remain complete in the linked recipe.
  while (shots.length > 11) {
    const i = shots.findIndex((s) => s.id.startsWith("step-"));
    shots[i].action += ` Then: ${shots[i + 1].action}`;
    shots.splice(i + 1, 1);
  }
  shots.push({
    id: "ending",
    title: "Invite a variation",
    action:
      ideaId === "series"
        ? "End with the same framing you can reuse next episode. Ask viewers which recipe to make next."
        : "Hold the finished bowl still and leave space for the final question.",
    angle: "Still wide shot",
    seconds: 2,
    caption: zh ? "你会怎样做成自己的版本？" : "What would you add to yours?",
  });
  shots.forEach((s) => (s.seconds = 1));
  for (let i = 0; i < brief.seconds - shots.length; i++)
    shots[i % shots.length].seconds++;
  return {
    id: "",
    revision: 0,
    ideaId,
    meal: foodSnapshot(meal),
    ...(companion ? { companion: foodSnapshot(companion) } : {}),
    brief,
    preparation: [
      `Recipe: ${meal.activeMinutes} min active + ${meal.waitingMinutes} min waiting. Video target: ${brief.seconds} seconds.`,
      ...(companion
        ? [
            `Second recipe: ${companion.activeMinutes} min active + ${companion.waitingMinutes} min waiting. Ingredients are listed separately; do not treat them as one serving.`,
          ]
        : []),
      "Read the complete recipe before filming. A shot list does not replace cooking or food-storage instructions.",
      `${brief.setup === "phone" ? "A stable phone support" : "Your tripod"}, clean lens and window light. Use the actual finished food.`,
      ...(meal.concept
        ? [
            "Concept recipe and illustrative photo: actual cooking and taste testing are still needed.",
          ]
        : []),
    ],
    title:
      `${ideaId === "series" && brief.seriesTitle ? `${brief.seriesTitle} · Episode ${brief.episode}` : idea.title} · ${meal.name}`.slice(
        0,
        120,
      ),
    hook: zh ? "我的早餐，从这一碗开始。" : idea.angle,
    caption: zh
      ? `${meal.name}｜主动制作 ${meal.activeMinutes} 分钟，等待 ${meal.waitingMinutes} 分钟。按完整食谱制作，试吃后补充自己的感受。 #早餐灵感`
      : `${meal.name}. ${meal.activeMinutes} min active + ${meal.waitingMinutes} min waiting. Full ingredients and method in the recipe. Make it your own. #BreakfastIdeas`,
    shots,
    progress: shots.map(() => "pending"),
    createdAt: "",
    updatedAt: "",
    requestId: "",
    method: "Recipe-linked template",
  };
}
export function projectText(p: CreativeProject) {
  return [
    p.title,
    p.ideaId === "series"
      ? `Series: ${p.brief.seriesTitle || "My breakfast series"} · Episode ${p.brief.episode}`
      : "",
    p.hook,
    ...p.preparation,
    `Ingredients: ${p.meal.ingredients.map((i) => `${i.amount} ${i.unit} ${i.name}`).join(", ")}`,
    `Complete recipe:\n${p.meal.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}`,
    p.companion
      ? `Second recipe: ${p.companion.name}\n${p.companion.ingredients.map((i) => `${i.amount} ${i.unit} ${i.name}`).join(", ")}\n${p.companion.steps.join("\n")}`
      : "",
    ...p.shots.map(
      (s, i) =>
        `${i + 1}. ${s.title} (${s.seconds}s) [${p.progress[i]}]\n${s.angle}\n${s.action}\nCaption: ${s.caption}`,
    ),
    `Publishing caption:\n${p.caption}`,
    `Origin: ${p.meal.originCreator || p.meal.creator}. Recipe: ${p.meal.name}`,
  ]
    .filter(Boolean)
    .join("\n\n");
}
