import { z } from "zod";
import { recipes as catalog } from "./catalog";
import {
  workspace,
  type RecipeDraft,
  recipeAllowed,
  shoppingFor,
} from "./breakfast";
import { adjustedIngredients } from "./recommendation";
import { isRevisionCurrent, revisionSteps } from "./personalisation";
import type { UserState } from "./types";

export type GrowthMeal = RecipeDraft & {
  originCreator?: string;
  id: string;
  image: string;
  products: string[];
  originId: string;
  parentId?: string;
  creator: string;
  concept: boolean;
  servings: number;
  shareId?: string;
  attributionShare?: string;
};
export const customisationSchema = z.object({
  equipment: z
    .enum(["any", "stove", "microwave", "kettle", "no-cook"])
    .default("any"),
  temperature: z.enum(["any", "warm", "cold"]).default("any"),
  sweetness: z.enum(["gentle", "regular", "fruit-only"]).default("gentle"),
  texture: z.enum(["creamy", "thicker", "looser"]).default("creamy"),
  servings: z.number().int().min(1).max(4).default(1),
  avoid: z.string().trim().max(100).default(""),
});
export type Customisation = z.infer<typeof customisationSchema>;
export type CreatorKit = {
  title: string;
  hook: string;
  shots: { frame: string; action: string; voiceover: string }[];
  preparation: string[];
  caption: string;
  invitation: string;
  method: string;
};
export type GrowthVersion = {
  originCreator?: string;
  concept?: boolean;
  servings?: number;
  recipeId: string;
  originId: string;
  parentId: string;
  creator: string;
  image: string;
  products: string[];
  sourceShare?: string;
  createdAt: string;
  constraints?: Customisation;
};
export type GrowthPending = {
  id: string;
  meal: GrowthMeal;
  before: GrowthMeal;
  context: string;
  constraints?: Customisation;
  reason: string;
  sourceShare?: string;
  createdAt: string;
  temporary?: boolean;
};
export type CookingRun = {
  id: string;
  meal: GrowthMeal;
  completed: number[];
  startedAt: string;
  finishedAt?: string;
  rating?: number;
  note?: string;
  fixes: { message: string; step: number; at: string }[];
  sourceShare?: string;
};
export type GrowthState = {
  versions: GrowthVersion[];
  pending: GrowthPending[];
  cooking: CookingRun[];
  trialOrders: {
    id: string;
    bundle: string;
    createdAt: string;
    status: "Classroom demo order";
  }[];
  kitDrafts: { mealId: string; kit: CreatorKit; createdAt: string }[];
};
export function growthState(s: UserState): GrowthState {
  return {
    versions: [],
    pending: [],
    cooking: [],
    trialOrders: [],
    kitDrafts: [],
    ...s.growth,
  };
}
const ingredient = (
  name: string,
  amount: number,
  unit: RecipeDraft["ingredients"][number]["unit"],
) => ({ name, amount, unit });
function concept(
  id: string,
  name: string,
  description: string,
  ingredients: RecipeDraft["ingredients"],
  steps: string[],
  allergens: RecipeDraft["allergens"],
  image: string,
  activeMinutes = 5,
  waitingMinutes = 0,
): GrowthMeal {
  return {
    id,
    name,
    description,
    ingredients,
    steps,
    allergens,
    image,
    activeMinutes,
    waitingMinutes,
    estimatedCost: 9,
    vegan: !allergens.some((a) => ["dairy", "eggs"].includes(a)),
    products: ["oats"],
    originId: id,
    creator: "VERIVA concept kitchen",
    concept: true,
    servings: 1,
  };
}
export const conceptRecipes: GrowthMeal[] = [
  concept(
    "concept-sesame",
    "Sesame soy morning",
    "A warm, creamy concept with black sesame. Contains soy and sesame; check actual labels.",
    [
      ingredient("Rolled oats", 40, "g"),
      ingredient("Soy drink", 180, "ml"),
      ingredient("Black sesame seeds", 5, "g"),
      ingredient("Banana", 60, "g"),
    ],
    [
      "Measure the ingredients and check soy, sesame and oat labels.",
      "Heat oats and soy drink gently in a saucepan, stirring until cooked according to the oat pack.",
      "Stir in crushed banana. Add sesame and cool to a comfortable temperature.",
    ],
    ["gluten"],
    "/images/breakfast-hero.webp",
  ),
  concept(
    "concept-mango",
    "Mango morning cup",
    "A cool layered cup with yogurt and fruit.",
    [
      ingredient("Plain yogurt", 150, "g"),
      ingredient("Ready-to-eat oat muesli", 35, "g"),
      ingredient("Mango", 80, "g"),
    ],
    [
      "Check that the muesli is labelled ready to eat.",
      "Wash, peel and dice the mango.",
      "Layer yogurt, muesli and mango in a glass; serve straight away.",
    ],
    ["dairy", "gluten"],
    "/images/yogurt.webp",
    4,
  ),
  concept(
    "concept-apple",
    "Apple cinnamon comfort",
    "A warm apple bowl for a slower start.",
    [
      ingredient("Rolled oats", 45, "g"),
      ingredient("Milk", 180, "ml"),
      ingredient("Apple", 60, "g"),
      ingredient("Cinnamon", 0.25, "tsp"),
    ],
    [
      "Wash and grate the apple.",
      "Cook oats, milk and apple gently in a saucepan following the oat pack.",
      "Stir in cinnamon; cool before serving.",
    ],
    ["dairy", "gluten"],
    "/images/breakfast-hero.webp",
  ),
  concept(
    "concept-cocoa",
    "Cocoa banana overnight",
    "Prepare ahead and allow proper refrigeration time.",
    [
      ingredient("Rolled oats", 45, "g"),
      ingredient("Oat drink", 150, "ml"),
      ingredient("Banana", 60, "g"),
      ingredient("Cocoa powder", 3, "g"),
    ],
    [
      "Mix oats, oat drink and cocoa in a clean covered container.",
      "Refrigerate for at least four hours, following the oat pack.",
      "Slice fresh banana over the oats just before serving. Keep chilled until eaten.",
    ],
    ["gluten"],
    "/images/overnight.webp",
    4,
    240,
  ),
  concept(
    "concept-savory",
    "A savoury late morning",
    "An egg and vegetable oat bowl for brunch.",
    [
      ingredient("Rolled oats", 40, "g"),
      ingredient("Water", 180, "ml"),
      ingredient("Egg", 1, "pcs"),
      ingredient("Spinach", 60, "g"),
    ],
    [
      "Wash the spinach and prepare the measured ingredients.",
      "Cook the oats with water in a saucepan according to the pack instructions.",
      "Add spinach and beaten egg. Stir and cook until the egg is fully set; serve at a comfortable temperature.",
    ],
    ["gluten", "eggs"],
    "/images/breakfast-hero.webp",
    8,
  ),
  concept(
    "concept-berry",
    "Berry reset jar",
    "A chilled make-ahead fruit jar.",
    [
      ingredient("Rolled oats", 40, "g"),
      ingredient("Oat drink", 150, "ml"),
      ingredient("Chia seeds", 8, "g"),
      ingredient("Mixed berries", 60, "g"),
    ],
    [
      "Mix oats, chia and oat drink in a clean covered jar.",
      "Refrigerate for at least four hours and follow the oat label.",
      "Wash berries and add before eating. Keep chilled until served.",
    ],
    ["gluten"],
    "/images/overnight.webp",
    4,
    240,
  ),
];
export const demoCreators = [
  {
    id: "demo-nora",
    name: "Nora",
    recipeId: "berry-oats",
    story: "Warm bowls and small morning rituals.",
  },
  {
    id: "demo-luca",
    name: "Luca",
    recipeId: "overnight-bircher",
    story: "Prepare ahead for a late start.",
  },
  {
    id: "demo-mei",
    name: "Mei",
    recipeId: "concept-sesame",
    story: "Exploring familiar flavours in a new breakfast.",
  },
];
export function resolveGrowthRecipe(
  s: UserState,
  id: string,
): GrowthMeal | undefined {
  const c = conceptRecipes.find((r) => r.id === id);
  if (c) return structuredClone(c);
  const r = catalog.find((r) => r.id === id);
  if (r) {
    const revision = s.revisions?.find(
      (v) => v.recipeId === id && isRevisionCurrent(v, s),
    );
    const items = adjustedIngredients(r, s.feedback, revision);
    return {
      id: r.id,
      name: r.name,
      description: r.subtitle,
      activeMinutes: r.minutes,
      waitingMinutes: /overnight/.test(r.id) ? 240 : 0,
      estimatedCost: 9,
      ingredients: items.map((i) => {
        const amount = parseFloat(i.amount) || 0.25;
        const unit = /ml/.test(i.amount)
          ? "ml"
          : /g/.test(i.amount)
            ? "g"
            : "pinch";
        return { name: i.name, amount, unit };
      }),
      steps: revision ? revisionSteps(r, revision) : r.steps,
      allergens: r.allergens as RecipeDraft["allergens"],
      vegan: !r.allergens.some((a) => ["dairy", "eggs"].includes(a)),
      image: r.image,
      products: r.products,
      originId: r.id,
      creator: "VERIVA recipe kitchen",
      concept: false,
      servings: 1,
    };
  }
  const p = workspace(s).recipes.find((r) => r.id === id);
  if (!p) return;
  const v = growthState(s).versions.find((v) => v.recipeId === id);
  return {
    ...p,
    image: v?.image || "/images/breakfast-hero.webp",
    products: v?.products || ["oats"],
    originId: v?.originId || id,
    parentId: v?.parentId,
    creator: v?.creator || "Personal kitchen",
    concept: v?.concept || false,
    originCreator: v?.originCreator,
    servings: v?.servings || v?.constraints?.servings || 1,
    attributionShare: v?.sourceShare,
  };
}
export function foodSnapshot(r: GrowthMeal): GrowthMeal {
  return {
    ...(r.originCreator ? { originCreator: r.originCreator } : {}),
    id: r.id,
    name: r.name,
    description: r.description,
    activeMinutes: r.activeMinutes,
    waitingMinutes: r.waitingMinutes,
    estimatedCost: r.estimatedCost,
    ingredients: r.ingredients.map(({ name, amount, unit }) => ({
      name,
      amount,
      unit,
    })),
    steps: [...r.steps],
    allergens: [...r.allergens],
    vegan: r.vegan,
    image: r.image,
    products: [...r.products],
    originId: r.originId,
    ...(r.parentId ? { parentId: r.parentId } : {}),
    creator: r.creator,
    concept: r.concept,
    servings: r.servings,
  };
}
export function scaleMeal(r: GrowthMeal, servings: number): GrowthMeal {
  const n = Math.max(1, Math.min(4, servings)),
    factor = n / (r.servings || 1);
  return {
    ...structuredClone(r),
    servings: n,
    estimatedCost: Math.round(r.estimatedCost * factor * 100) / 100,
    ingredients: r.ingredients.map((i) => ({
      ...i,
      amount: Math.round(i.amount * factor * 100) / 100,
    })),
  };
}
export function ingredientChanges(before: GrowthMeal, after: GrowthMeal) {
  const keys = new Set(
    [...before.ingredients, ...after.ingredients].map((i) =>
      i.name.toLowerCase(),
    ),
  );
  return [...keys].flatMap((key) => {
    const b = before.ingredients.find((i) => i.name.toLowerCase() === key),
      a = after.ingredients.find((i) => i.name.toLowerCase() === key);
    const from = b ? `${b.amount} ${b.unit}` : "not included",
      to = a ? `${a.amount} ${a.unit}` : "removed";
    return from === to ? [] : [{ name: a?.name || b!.name, from, to }];
  });
}
export function constraintsSatisfied(r: RecipeDraft, c: Customisation) {
  const steps = r.steps.join(" ").toLowerCase();
  if (
    c.equipment === "no-cook" &&
    /\b(heat|boil|simmer|stove|saucepan|microwave|bake|oven)\b/.test(steps)
  )
    return false;
  if (
    c.equipment === "microwave" &&
    /\b(stovetop|saucepan|oven|skillet|frying pan)\b/.test(steps)
  )
    return false;
  if (
    c.equipment === "kettle" &&
    /\b(saucepan|stovetop|microwave|oven|skillet)\b/.test(steps)
  )
    return false;
  if (c.equipment === "stove" && /\b(microwave|oven|air fryer)\b/.test(steps))
    return false;
  if (
    c.temperature === "warm" &&
    !/warm|heat|hot|simmer|cook|microwave/.test(steps)
  )
    return false;
  if (
    c.temperature === "warm" &&
    /\bserve (?:it )?(?:cold|chilled)\b/.test(steps)
  )
    return false;
  if (c.temperature === "cold" && !/chill|refrigerat|cold/.test(steps))
    return false;
  const avoided = c.avoid
    .toLowerCase()
    .split(/[,，;；\n]/)
    .map((t) => t.trim())
    .filter(Boolean);
  const aliases: Record<string, string> = {
    牛奶: "milk",
    香蕉: "banana",
    芝麻: "sesame",
    豆奶: "soy",
    豆乳: "soy",
    蜂蜜: "honey",
    鸡蛋: "egg",
    芒果: "mango",
    苹果: "apple",
  };
  if (
    avoided.some((term) =>
      r.ingredients.some((i) =>
        i.name.toLowerCase().includes(aliases[term] || term),
      ),
    )
  )
    return false;
  if (
    c.sweetness === "fruit-only" &&
    r.ingredients.some((i) => /honey|sugar|syrup|jam|蜂蜜|糖浆/i.test(i.name))
  )
    return false;
  return true;
}
export function mealFits(r: GrowthMeal, s: UserState) {
  return recipeAllowed({ ...r, activeMinutes: r.activeMinutes }, s);
}
export function trialPortions(packGrams: number, oatsPerServing: number) {
  return Number.isFinite(packGrams) &&
    Number.isFinite(oatsPerServing) &&
    packGrams > 0 &&
    packGrams <= 5000 &&
    oatsPerServing > 0 &&
    oatsPerServing <= 500
    ? Math.floor(packGrams / oatsPerServing)
    : 0;
}
export function trialShopping(s: UserState, meals: GrowthMeal[]) {
  const w = workspace(s);
  return shoppingFor(
    {
      ...s,
      breakfast: {
        ...w,
        recipes: [
          ...meals.map((r) => ({
            ...r,
            source: "Guided" as const,
            createdAt: "",
            context: "",
          })),
          ...w.recipes,
        ],
      },
    },
    meals.map((r) => r.id),
  );
}
export type RescueKind = "thick" | "watery" | "bland" | "sweet" | "missing";
export function measuredRescue(
  original: GrowthMeal,
  kind: RescueKind,
  step: number,
) {
  const r = structuredClone(original),
    liquid = r.ingredients.find((i) => i.unit === "ml"),
    sweet = r.ingredients.find((i) => /honey|sugar|syrup/i.test(i.name));
  let message = "";
  if (kind === "thick" && liquid) {
    const extra = Math.max(5, Math.min(30, Math.round(liquid.amount * 0.1)));
    liquid.amount += extra;
    message = `Add ${extra} ml of the recipe's ${liquid.name}, stir and check again. This is one small adjustment, not a guaranteed final texture.`;
  } else if (kind === "watery") {
    message =
      "Pause and let the bowl rest for 2 minutes so the oats absorb liquid. Follow the oat pack; recheck before changing ingredients.";
    r.waitingMinutes += 2;
  } else if (kind === "sweet" && sweet) {
    const before = sweet.amount;
    sweet.amount = Math.round(before * 0.5 * 100) / 100;
    message = `For the next batch reduce ${sweet.name} from ${before} ${sweet.unit} to ${sweet.amount} ${sweet.unit}. Sweetener already mixed in cannot be removed; do not pretend it has disappeared.`;
  } else if (kind === "sweet") {
    message =
      "Taste before adding any more fruit or sweetener. For the current batch, adjust only with a suitable unsweetened ingredient already in your recipe; use Make It Mine for a measured next batch.";
  } else if (kind === "bland") {
    message =
      "Stir thoroughly and distribute the existing fruit or toppings more evenly. Taste again before adding anything outside your approved ingredient list.";
  } else {
    message =
      "Pause before substituting. Open Make It Mine and list the missing ingredient in Avoid ingredients to generate a measured replacement; do not skip an ingredient needed for safe preparation.";
  }
  r.steps.splice(Math.min(Math.max(0, step), r.steps.length), 0, message);
  return { recipe: r, message, kind, method: "Measured recipe guidance" };
}
export function makeCreatorKit(
  r: GrowthMeal,
  scene: string,
  style: string,
  language: "en" | "zh",
): CreatorKit {
  const zh = language === "zh",
    names = r.ingredients
      .map((i) => `${i.amount} ${i.unit} ${i.name}`)
      .join(", ");
  return {
    title: r.name,
    hook: zh ? `${scene}，从这一碗开始。` : `A ${scene} idea: ${r.name}.`,
    shots: [
      {
        frame: "01 · Ingredients / overhead",
        action: `Lay out ${names}.`,
        voiceover: zh
          ? "先准备好配方中的食材。"
          : "Here is what goes into this bowl.",
      },
      ...r.steps.slice(0, 5).map((step, i) => ({
        frame: `${String(i + 2).padStart(2, "0")} · ${style === "diary" ? "Morning moment" : "Preparation detail"}`,
        action: step,
        voiceover: step,
      })),
      {
        frame: "Final · Serving / close-up",
        action:
          "Show the finished texture in natural light; use the actual cooked result.",
        voiceover: zh
          ? `这是我的 ${r.name}，你也可以调整成自己的版本。`
          : `This is my ${r.name}. Make it yours.`,
      },
    ],
    preparation: [
      `Allow ${r.activeMinutes} minutes active preparation and ${r.waitingMinutes} minutes waiting; do not edit out required cooking or chilling time.`,
      "Film ingredients before starting. Place the camera safely away from heat and splashes.",
      "Use your actual ingredient labels and portions. Do not add unverified health, certification or price claims.",
    ],
    caption: zh
      ? `${r.name}｜${scene}。主动制作约 ${r.activeMinutes} 分钟，等待 ${r.waitingMinutes} 分钟。食材和做法见配方卡，点击 Make It Mine 调整自己的版本。 #早餐灵感 #燕麦食谱`
      : `${r.name} for a ${scene}. ${r.activeMinutes} min active + ${r.waitingMinutes} min waiting. ${r.description} Make it yours with the recipe card. #BreakfastIdeas #OatRecipes`,
    invitation: zh
      ? "收藏配方，尝试制作，再分享你的调整。"
      : "Save the recipe, try it, then share your variation.",
    method: "Recipe-linked content template",
  };
}
export const trialBundles = [
  {
    id: "warm-start",
    name: "Three slower mornings",
    ids: ["berry-oats", "concept-apple", "concept-sesame"],
    productId: "oats",
    description: "One oat pantry staple, three warm recipe ideas.",
  },
  {
    id: "prepare-ahead",
    name: "Tomorrow is ready",
    ids: ["overnight-bircher", "concept-cocoa", "concept-berry"],
    productId: "oats",
    description: "Three make-ahead ideas with required refrigeration time.",
  },
];
