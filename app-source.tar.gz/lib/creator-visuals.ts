/** Generated mood references for filming ideas, separate from recipe snapshots. */
export const creatorVisuals = {
  "quiet-morning": {
    src: "/images/creator-quiet-morning-v1.webp",
    alt: "Creamy berry oats beside a softly lit window, with ivory linen and a simple spoon",
  },
  "five-minute": {
    src: "/images/creator-five-minute-v1.webp",
    alt: "Mango yogurt and muesli cup on a student desk beside a notebook and sage tote",
  },
  texture: {
    src: "/images/creator-texture-v1.webp",
    alt: "Close-up of a spoon lifting creamy berry and chia oats from a glass jar",
  },
  "local-flavour": {
    src: "/images/creator-local-flavour-v1.webp",
    alt: "Black sesame and banana oat bowl with a small pitcher of soy drink",
  },
  overnight: {
    src: "/images/creator-overnight-v1.webp",
    alt: "Covered apple oat jar and a serving jar in a softly lit evening kitchen",
  },
  "two-ways": {
    src: "/images/creator-two-ways-v1.webp",
    alt: "Berry oats and apple cinnamon oats side by side, photographed from above",
  },
  "make-it-mine": {
    src: "/images/creator-make-it-mine-v1.webp",
    alt: "Apple cinnamon oat bowl with an apple and a measuring spoon on a warm wooden table",
  },
  series: {
    src: "/images/creator-series-v1.webp",
    alt: "Cocoa banana oats, mango yogurt and berry oats arranged as three breakfast ideas",
  },
} as const;
