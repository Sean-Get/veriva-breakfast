import { cookies } from "next/headers";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { database } from "./db";
import { ApiError } from "./http";
import { defaultState, type UserState } from "./types";
const cookieName = "veriva_admin";
const digest = (v: string) => createHash("sha256").update(v).digest("hex");
function adminDatabase() {
  const db = database();
  db.exec(
    "CREATE TABLE IF NOT EXISTS admin_sessions (token TEXT PRIMARY KEY,expires INTEGER NOT NULL)",
  );
  return db;
}
export async function requireAdmin() {
  const token = (await cookies()).get(cookieName)?.value;
  if (
    !process.env.VERIVA_ADMIN_PASSWORD ||
    !token ||
    !adminDatabase()
      .prepare("SELECT token FROM admin_sessions WHERE token=? AND expires>?")
      .get(digest(token), Date.now())
  )
    throw new ApiError("请先登录管理后台。", 401);
}
export async function loginAdmin(password: string) {
  const expected = process.env.VERIVA_ADMIN_PASSWORD;
  if (!expected)
    throw new ApiError(
      "后台尚未配置。请在服务端 .env.local 设置 VERIVA_ADMIN_PASSWORD 后重启。",
      503,
    );
  if (
    !timingSafeEqual(
      Buffer.from(digest(password)),
      Buffer.from(digest(expected)),
    )
  )
    throw new ApiError("管理口令不正确。", 401);
  const db = adminDatabase();
  db.prepare("DELETE FROM admin_sessions WHERE expires<?").run(Date.now());
  const token = randomBytes(32).toString("hex");
  db.prepare("INSERT INTO admin_sessions(token,expires) VALUES(?,?)").run(
    digest(token),
    Date.now() + 4 * 3600000,
  );
  (await cookies()).set(cookieName, token, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.COOKIE_SECURE === "true",
    maxAge: 4 * 3600,
    path: "/",
  });
}
export async function logoutAdmin() {
  const jar = await cookies(),
    token = jar.get(cookieName)?.value;
  if (token)
    adminDatabase()
      .prepare("DELETE FROM admin_sessions WHERE token=?")
      .run(digest(token));
  jar.delete(cookieName);
}
export type AdminUser = {
  id: string;
  name: string;
  email: string | null;
  guest: boolean;
  createdAt: number;
  onboarded: boolean;
  goals: string[];
  diet: string[];
  minutes: number;
  activity: string;
  favorites: number;
  feedback: number;
  messages: number;
  revisions: number;
  orders: number;
};
// Explicit DTO: never return the database row or the user's full JSON state.
export function adminUserSummary(row: {
  id: string;
  name: string;
  email: string | null;
  guest: number;
  created_at: number;
  json: string | null;
}): AdminUser {
  let state: UserState;
  try {
    state = row.json ? JSON.parse(row.json) : defaultState();
  } catch {
    state = defaultState();
  }
  const profile = { ...defaultState().profile, ...state.profile };
  return {
    id: row.id,
    name: profile.onboarded ? profile.name : row.name,
    email: row.email,
    guest: !!row.guest,
    createdAt: row.created_at,
    onboarded: !!profile.onboarded,
    goals: profile.goals,
    diet: profile.diet,
    minutes: profile.minutes,
    activity: profile.activity,
    favorites: state.favorites?.length || 0,
    feedback: state.feedback?.length || 0,
    messages: state.messages?.length || 0,
    revisions: state.revisions?.length || 0,
    orders: state.orders?.length || 0,
  };
}
export function adminUsers(url: URL) {
  const q = (url.searchParams.get("q") || "").trim().slice(0, 100),
    type = url.searchParams.get("type") || "all";
  const pageSize = 15;
  const db = database();
  const summary = db
    .prepare(
      "SELECT COUNT(*) total,COALESCE(SUM(guest=0),0) registered,COALESCE(SUM(guest=1),0) guests FROM users",
    )
    .get() as { total: number; registered: number; guests: number };
  const where = `WHERE (u.name LIKE ? ESCAPE '\\' OR COALESCE(u.email,'') LIKE ? ESCAPE '\\' OR COALESCE(json_extract(s.json,'$.profile.name'),'') LIKE ? ESCAPE '\\') ${type === "registered" ? "AND u.guest=0" : type === "guest" ? "AND u.guest=1" : ""}`;
  const term = "%" + q.replace(/[\\%_]/g, "\\$&") + "%";
  const { count } = db
    .prepare(
      `SELECT COUNT(*) count FROM users u LEFT JOIN user_state s ON s.user_id=u.id ${where}`,
    )
    .get(term, term, term) as { count: number };
  const rawPage = Number(url.searchParams.get("page") || 1);
  const page = Math.min(
    Math.max(1, Number.isFinite(rawPage) ? Math.floor(rawPage) : 1),
    Math.max(1, Math.ceil(count / pageSize)),
  );
  const rows = db
    .prepare(
      `SELECT u.id,u.name,u.email,u.guest,u.created_at,s.json FROM users u LEFT JOIN user_state s ON s.user_id=u.id ${where} ORDER BY u.created_at DESC,u.id LIMIT ? OFFSET ?`,
    )
    .all(term, term, term, pageSize, (page - 1) * pageSize) as Parameters<
    typeof adminUserSummary
  >[0][];
  return {
    summary,
    users: rows.map(adminUserSummary),
    count,
    page,
    pageSize,
    generatedAt: new Date().toISOString(),
  };
}
