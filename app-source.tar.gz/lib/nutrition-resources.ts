export const nutritionResources = [
  {
    id: "who-diet",
    organisation: "WHO",
    title: "Healthy diet",
    url: "https://www.who.int/news-room/fact-sheets/detail/healthy-diet",
    summary:
      "General guidance on varied foods, whole grains, fruit and vegetables, and limiting free sugars, including honey.",
  },
  {
    id: "nhs-eatwell",
    organisation: "NHS",
    title: "The Eatwell Guide",
    url: "https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/the-eatwell-guide/",
    summary:
      "A balanced pattern across a day or week, with higher-fibre starchy foods and a variety of food groups.",
  },
];
export const nutritionPrinciples =
  "Reference library, checked 2026-10-25: WHO Healthy diet recommends varied minimally processed foods, whole grains, vegetables, fruits and pulses, and limiting free sugars including honey. NHS Eatwell Guide frames balance across a day or week and encourages higher-fibre starchy foods. These are general principles, not personalised clinical prescriptions. Do not claim live web search, a human expert consultation, or that WHO/NHS endorsed this app. Only cite the exact source titles/URLs supplied.";
