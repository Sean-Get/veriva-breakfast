// New browser versions can return a Promise from scrollIntoView. React effects
// may only return a cleanup function or undefined, so never forward that value.
export function scrollToLatest(
  element: Pick<HTMLElement, "scrollIntoView"> | null,
): void {
  element?.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
