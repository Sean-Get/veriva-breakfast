import { z } from "zod";
import { recipes, type Recipe } from "./catalog";
import {
  defaultHealth,
  type UserState,
  type Feedback,
  type RecipeRevision,
} from "./types";
export function healthContext(state: UserState) {
  const health = { ...defaultHealth(), ...state.profile.health };
  const { health: _, ...profile } = state.profile;
  return {
    profile,
    dietaryExclusions: state.profile.diet.filter(d => d !== "vegan").map(d => `Avoid ${d}`),
    plantBasedOnly: state.profile.diet.includes("vegan"),
    health: health.useForAI ? health : null,
    healthHistory: health.useForAI
      ? (state.healthHistory || []).filter((r) => r.record.useForAI).slice(0, 3)
      : [],
    feedback: state.feedback.slice(0, 10),
    favourites: state.favorites,
      breakfastMemories: state.breakfast?.memories || [],
      pantry: state.breakfast?.pantry || [],
  };
}
export function profileFactAnswer(
  state: UserState,
  message: string,
): string | null {
  const h = state.profile.health;
  if (!h?.useForAI) return null;
  const question = /多少|几|what|how much/i.test(message);
  if (
    question &&
    /体重|(?:current|latest) weight|weigh/i.test(message) &&
    h.weightKg !== null
  )
    return /[\u4e00-\u9fff]/.test(message)
      ? `你当前保存的体重记录是 ${h.weightKg} kg。`
      : `Your current saved weight is ${h.weightKg} kg.`;
  return null;
}
export function feedbackIntent(feedback: Feedback) {
  const text =
    feedback.tags.join(" ") +
    " " +
    feedback.note.replace(/not (?:too )?sweet|不太甜|不甜/gi, "");
  return {
    sweet: /too sweet|less sweet|less honey|太甜|少糖|少蜂蜜/i.test(text),
    bland: /bland|tasteless|太淡|没味|無味|无味/i.test(text),
    thick: /too thick|too concentrated|太稠|过浓|太浓/i.test(text),
    thin: /too thin|too watery|太稀|太水/i.test(text),
  };
}
export function isRevisionCurrent(revision: RecipeRevision, state: UserState) {
  try {
    return (
      JSON.stringify(JSON.parse(revision.context).profile) ===
        JSON.stringify(state.profile) &&
      state.feedback.find((f) => f.recipeId === revision.recipeId)?.id ===
        revision.feedbackId
    );
  } catch {
    return false;
  }
}
export const revisionParameters = z.object({
  sweetnessFactor: z.number().min(0).max(1),
  liquidFactor: z.number().min(0.7).max(1.5),
  flavourMethod: z.enum(["none", "toast-oats", "crush-fruit", "rest-longer"]),
  summary: z.string().trim().min(5).max(600),
});
export function validateRevision(
  recipe: Recipe,
  feedback: Feedback,
  value: unknown,
) {
  const p = revisionParameters.safeParse(value);
  if (!p.success)
    throw new Error("The AI recipe adjustment was not valid. Please retry.");
  const v = p.data,
    intent = feedbackIntent(feedback);
  if (intent.thick && intent.thin)
    throw new Error("Choose either too thick or too thin, then try again.");
  if (intent.sweet && v.sweetnessFactor > 0.9)
    throw new Error("The AI did not reduce sweetness. Please retry.");
  if (intent.thick && v.liquidFactor < 1.05)
    throw new Error("The AI did not loosen the texture. Please retry.");
  if (intent.thin && v.liquidFactor > 0.95)
    throw new Error("The AI did not thicken the texture. Please retry.");
  if (intent.bland && v.flavourMethod === "none")
    throw new Error("The AI did not address flavour. Please retry.");
  if (
    v.flavourMethod === "toast-oats" &&
    !recipe.ingredients.some((i) => /oats/i.test(i.name))
  )
    throw new Error("This recipe has no oats to toast. Please retry.");
  if (
    v.flavourMethod === "crush-fruit" &&
    !recipe.ingredients.some((i) =>
      /berries|strawberries|banana|apple/i.test(i.name),
    )
  )
    throw new Error("This recipe has no fruit to crush. Please retry.");
  if (
    v.liquidFactor !== 1 &&
    !recipe.ingredients.some(
      (i) =>
        /milk|drink|water|yogurt/i.test(i.name) && /(?:g|ml)$/.test(i.amount),
    )
  )
    throw new Error("This recipe has no adjustable liquid. Please retry.");
  return v;
}
export function revisedIngredients(recipe: Recipe, revision: RecipeRevision) {
  return recipe.ingredients.map((i) => {
    let factor = 1;
    // Reduce optional sweetener first; naturally sweet fruit is adjusted only
    // when the recipe has no optional sweetener. No new ingredient is introduced.
    if (
      i.honey ||
      (!recipe.ingredients.some((x) => x.honey) &&
        /berries|strawberries|banana|apple/i.test(i.name))
    )
      factor = revision.sweetnessFactor;
    if (/milk|drink|water|yogurt/i.test(i.name) && /(?:g|ml)$/.test(i.amount))
      factor = revision.liquidFactor;
    const match = i.amount.match(/^(\d+(?:\.\d+)?)\s*(g|ml)$/);
    return match && factor !== 1
      ? {
          ...i,
          amount: `${Math.round(Number(match[1]) * factor * 10) / 10} ${match[2]}`,
        }
      : { ...i };
  });
}
export function revisionSummary(recipe: Recipe, revision: RecipeRevision) {
  const changes = revisedIngredients(recipe, revision).flatMap((item, index) =>
    item.amount !== recipe.ingredients[index].amount
      ? [`${item.name}: ${recipe.ingredients[index].amount} → ${item.amount}.`]
      : [],
  );
  const method = {
    none: "",
    "toast-oats": "Dry-toast the existing oats before cooking for more flavour.",
    "crush-fruit": "Crush some of the existing fruit to release more flavour.",
    "rest-longer": "Rest the bowl for 2–3 minutes to develop flavour and texture.",
  }[revision.flavourMethod];
  return [...changes, method].filter(Boolean).join(" ") || "Use the current ingredient amounts and preparation steps.";
}
export function revisionSteps(recipe: Recipe, revision: RecipeRevision) {
  const extra =
    revision.flavourMethod === "toast-oats"
      ? "Before cooking, dry-toast the existing oats over low heat for 1–2 minutes until fragrant. Do not add extra sugar or salt."
      : revision.flavourMethod === "crush-fruit"
        ? "Gently crush some of the existing fruit to release its flavour, then stir it through. No extra sweetener is needed."
        : revision.flavourMethod === "rest-longer"
          ? "Let the prepared bowl rest for 2–3 minutes, then stir so the existing flavours and texture come together."
          : null;
  return [
    ...(extra ? [extra] : []),
    ...recipe.steps,
    `Use the adjusted ingredient amounts above. ${revision.liquidFactor > 1 ? "Add the increased liquid gradually for a looser texture." : revision.liquidFactor < 1 ? "Start with the reduced liquid and allow a short resting time for a thicker texture." : ""}`,
  ];
}
