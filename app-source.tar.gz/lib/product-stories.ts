export const productStories: Record<
  string,
  {
    headline: string;
    detail: string;
    note: string;
    recipeId: string;
    photo: string;
  }
> = {
  "blueberry-apple-porridge": {
    headline: "A bright little beginning.",
    detail:
      "Blueberry notes, fresh apple and a warm bowl to ease into the day. A fruit-inspired breakfast with room for your own finishing touches.",
    note: "Fruit-forward · Warm & comforting",
    recipeId: "berry-oats",
    photo: "/images/breakfast-hero.webp",
  },
  "bircher-porridge": {
    headline: "A slower kind of morning.",
    detail:
      "Apple, a hint of cinnamon and the comfort of oats. Lovely inspiration for a breakfast prepared the night before, ready for an unhurried start.",
    note: "Apple-inspired · Make-ahead ideas",
    recipeId: "overnight-bircher",
    photo: "/images/overnight.webp",
  },
  oats: {
    headline: "Simple oats. So many mornings.",
    detail:
      "A familiar cupboard favourite, ready to become a warm bowl or a jar of overnight oats. Start simply, then make it yours.",
    note: "An everyday essential · Warm or overnight",
    recipeId: "berry-oats",
    photo: "/images/quiet-morning.webp",
  },
  muesli: {
    headline: "A little crunch to wake up to.",
    detail:
      "Cool yogurt, a handful of berries and that first crisp spoonful. Keep the muesli separate until the last moment for a little extra texture.",
    note: "Crunchy textures · Lovely with yogurt",
    recipeId: "yogurt-crunch",
    photo: "/images/yogurt.webp",
  },
  chia: {
    headline: "Something soft, for a fresh start.",
    detail:
      "A chilled little pudding with bright blueberries and coconut. Stir, let it rest, and leave the morning with one less thing to do.",
    note: "Prep ahead · A softer texture",
    recipeId: "chia-cloud",
    photo: "/images/chia.webp",
  },
};
