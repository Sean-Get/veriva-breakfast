export const productStories: Record<
  string,
  {
    headline: string;
    detail: string;
    note: string;
    recipeId: string;
    photo: string;
  }
> = {
  "blueberry-apple-porridge": {
    headline: "A bright little beginning.",
    detail:
      "Blueberry notes, fresh apple and a warm bowl to ease into the day. A fruit-inspired breakfast with room for your own finishing touches.",
    note: "Fruit-forward · Warm & comforting",
    recipeId: "berry-oats",
    photo: "/images/breakfast-hero.webp",
  },
  "bircher-porridge": {
    headline: "A slower kind of morning.",
    detail:
      "Apple, a hint of cinnamon and the comfort of oats. Lovely inspiration for a breakfast prepared the night before, ready for an unhurried start.",
    note: "Apple-inspired · Make-ahead ideas",
    recipeId: "overnight-bircher",
    photo: "/images/overnight.webp",
  },
  oats: {
    headline: "Simple oats. So many mornings.",
    detail:
      "A familiar cupboard favourite, ready to become a warm bowl or a jar of overnight oats. Start simply, then make it yours.",
    note: "An everyday essential · Warm or overnight",
    recipeId: "berry-oats",
    photo: "/images/quiet-morning.webp",
  },
  muesli: {
    headline: "A little crunch to wake up to.",
    detail:
      "Cool yogurt, a handful of berries and that first crisp spoonful. Keep the muesli separate until the last moment for a little extra texture.",
    note: "Crunchy textures · Lovely with yogurt",
    recipeId: "yogurt-crunch",
    photo: "/images/yogurt.webp",
  },
  chia: {
    headline: "Something soft, for a fresh start.",
    detail:
      "A chilled little pudding with bright blueberries and coconut. Stir, let it rest, and leave the morning with one less thing to do.",
    note: "Prep ahead · A softer texture",
    recipeId: "chia-cloud",
    photo: "/images/chia.webp",
  },
  "cocoa-hazelnut": {
    headline: "A warm little indulgence.",
    detail:
      "Cocoa, banana and a nutty finishing touch. Explore a comforting warm bowl, then adjust the toppings to suit your morning.",
    note: "Cocoa-inspired \u00b7 Warm bowl ideas",
    recipeId: "banana-protein",
    photo: "/images/banana.webp",
  },
  "apple-cinnamon": {
    headline: "A spoonful of orchard comfort.",
    detail:
      "Fresh apple and a little cinnamon turn simple oats into something quietly special. Try the overnight recipe for a slower start.",
    note: "Apple & spice \u00b7 Prepare ahead",
    recipeId: "overnight-bircher",
    photo: "/images/overnight.webp",
  },
  "coconut-almond": {
    headline: "A brighter kind of crunch.",
    detail:
      "Crisp granola, coconut and almonds bring another texture to a cool breakfast. Add it at the last moment, just before the first spoonful.",
    note: "Toasted textures \u00b7 Yogurt companion",
    recipeId: "yogurt-crunch",
    photo: "/images/yogurt.webp",
  },
  "raspberry-crunch": {
    headline: "A little berry brightness.",
    detail:
      "A berry-inspired muesli for mornings that need to be simple. Spoon over yogurt, add fresh fruit and enjoy the different textures.",
    note: "Berry-inspired \u00b7 No-cook ideas",
    recipeId: "yogurt-crunch",
    photo: "/images/yogurt.webp",
  },
  "pumpkin-seeds": {
    headline: "Small seeds. A lovely finish.",
    detail:
      "A small scattering changes the texture of a familiar bowl. Try them on warm oats, or explore a savoury breakfast with greens.",
    note: "Versatile topping \u00b7 Sweet or savoury",
    recipeId: "savory-oats",
    photo: "/images/savory.webp",
  },
};
