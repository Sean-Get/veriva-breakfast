import { z } from "zod";
import { recipes } from "./catalog";
import { rankRecipes } from "./recommendation";
import { feedbackIntent } from "./personalisation";
import type { UserState } from "./types";

export const ingredientSchema = z.object({
  name: z.string().trim().min(1).max(70),
  amount: z.number().positive().max(2000),
  unit: z.enum(["g", "ml", "pcs", "tsp", "tbsp", "pinch"]),
});
export const recipeDraftSchema = z.object({
  name: z.string().trim().min(2).max(90),
  description: z.string().max(250),
  activeMinutes: z.number().int().min(1).max(60),
  waitingMinutes: z.number().int().min(0).max(1440),
  estimatedCost: z.number().min(0).max(200),
  ingredients: z.array(ingredientSchema).min(2).max(12),
  steps: z.array(z.string().min(5).max(350)).min(2).max(8),
  allergens: z.array(z.enum(["nuts", "dairy", "gluten", "eggs"])).max(4),
  vegan: z.boolean(),
});
export type RecipeDraft = z.infer<typeof recipeDraftSchema>;
export type PersonalRecipe = RecipeDraft & {
  servings?: number;
  id: string;
  createdAt: string;
  source: "AI" | "Guided";
  context: string;
};
export type Memory = {
  id: string;
  text: string;
  source: "user" | "feedback";
  createdAt: string;
};
export type PantryItem = { id: string; name: string; quantity: string };
export type Plan = {
  id: string;
  startDate: string;
  budget: number;
  summary: string;
  days: { date: string; recipeId: string }[];
};
export type ShoppingItem = {
  id: string;
  name: string;
  amount: number;
  unit: string;
  checked: boolean;
};
export type BreakfastData = {
  memories: Memory[];
  pantry: PantryItem[];
  recipes: PersonalRecipe[];
  plan: Plan | null;
  shopping: ShoppingItem[];
};
export type Proposal = {
  id: string;
  kind: "recipe" | "week" | "memory" | "shopping" | "replace";
  title: string;
  context: string;
  createdAt: string;
  recipes?: PersonalRecipe[];
  plan?: Plan;
  memory?: string;
  shopping?: ShoppingItem[];
  date?: string;
  recipeId?: string;
  feedback?: { recipeId: string; note: string };
};
export type BreakfastState = BreakfastData & {
  proposals: Proposal[];
  undo: {
    id: string;
    before: BreakfastData;
    after: string;
    label: string;
    beforeFeedback?: UserState["feedback"];
    afterFeedback?: string;
  }[];
};
export function workspace(s: UserState): BreakfastState {
  return {
    memories: [],
    pantry: [],
    recipes: [],
    plan: null,
    shopping: [],
    proposals: [],
    undo: [],
    ...s.breakfast,
  };
}
export function snapshot(w: BreakfastState): BreakfastData {
  return structuredClone({
    memories: w.memories,
    pantry: w.pantry,
    recipes: w.recipes,
    plan: w.plan,
    shopping: w.shopping,
  });
}
export function recordUndo(
  w: BreakfastState,
  before: BreakfastData,
  id: string,
  label: string,
) {
  w.undo = [
    { id, before, after: JSON.stringify(snapshot(w)), label },
    ...w.undo,
  ].slice(0, 8);
}
export function undoLast(w: BreakfastState) {
  const entry = w.undo[0];
  if (!entry || entry.after !== JSON.stringify(snapshot(w))) return false;
  Object.assign(w, entry.before);
  w.undo.shift();
  return true;
}
export function planningContext(s: UserState) {
  const w = workspace(s);
  return JSON.stringify({
    profile: s.profile,
    feedback: s.feedback.slice(0, 12),
    memories: w.memories,
    pantry: w.pantry,
    plan: w.plan,
    recipes: w.recipes.map((r) => r.id),
  });
}
export function assistantContext(s: UserState, originalId?: string) {
  const w = workspace(s);
  return {
    memories: w.memories,
    pantry: w.pantry,
    personalRecipes: [
      ...w.recipes.filter((r) => r.id === originalId),
      ...w.recipes.filter((r) => r.id !== originalId),
    ]
      .slice(0, 25)
      .map(({ context, ...r }) => r),
    plan: w.plan,
    shopping: w.shopping,
  };
}

const terms: Record<string, RegExp> = {
  nuts: /\b(almond|walnut|cashew|hazelnut|pistachio|pecan|peanut|nut butter|nuts)\w*\b|杏仁|核桃|腰果|榛子|花生|坚果/i,
  dairy:
    /\b(yogurt|yoghurt|cheese|butter|cream|whey|greek yogurt)\b|牛奶|酸奶|奶酪|黄油|乳清/i,
  gluten:
    /\b(wheat|barley|rye|bread|muesli|granola|oats?)\b|小麦|大麦|黑麦|面包|燕麦/i,
  eggs: /\begg\w*\b|鸡蛋|蛋液/i,
  animal:
    /\b(chicken|beef|bacon|pork|fish|salmon|tuna|turkey|honey)\b|鸡肉|牛肉|猪肉|鱼|蜂蜜/i,
};
export function recipeAllowed(recipe: RecipeDraft, s: UserState) {
  const text =
    recipe.ingredients.map((i) => i.name).join(" ") +
    " " +
    recipe.steps.join(" ");
  const dairyMilk = recipe.ingredients.some(
    (i) =>
      /milk|奶/i.test(i.name) &&
      !/oat|soy|soya|coconut|rice|plant|燕麦|豆|椰|植物/i.test(i.name),
  );
  const detected = (key: string) =>
    terms[key]?.test(text) || (key === "dairy" && dairyMilk);
  for (const restriction of s.profile.diet) {
    if (restriction === "vegan") {
      if (
        !recipe.vegan ||
        recipe.allergens.some((a) => ["dairy", "eggs"].includes(a)) ||
        detected("dairy") ||
        detected("eggs") ||
        detected("animal")
      )
        return false;
    } else if (
      recipe.allergens.includes(restriction as never) ||
      detected(restriction)
    )
      return false;
  }
  return recipe.activeMinutes <= s.profile.minutes;
}
export function tasteRevisionAllowed(
  original: RecipeDraft,
  next: RecipeDraft,
  note: string,
) {
  const intent = feedbackIntent({ tags: [], note } as never);
  const base = (r: RecipeDraft) =>
    r.ingredients
      .filter((i) => i.unit === "ml" || /yogurt|yoghurt|酸奶/i.test(i.name))
      .reduce((sum, i) => sum + i.amount, 0);
  if (intent.thick && base(next) <= base(original)) return false;
  if (intent.thin && base(next) >= base(original)) return false;
  const sweet = original.ingredients.filter((i) =>
    /honey|sugar|syrup|banana|date|jam|蜂蜜|糖|香蕉|枣/i.test(i.name),
  );
  if (
    intent.sweet &&
    sweet.length &&
    !sweet.some(
      (i) =>
        (next.ingredients.find(
          (n) =>
            n.name.toLowerCase() === i.name.toLowerCase() && n.unit === i.unit,
        )?.amount || 0) < i.amount,
    )
  )
    return false;
  if (
    intent.bland &&
    JSON.stringify(original.ingredients) === JSON.stringify(next.ingredients) &&
    JSON.stringify(original.steps) === JSON.stringify(next.steps)
  )
    return false;
  return true;
}
export function findPersonal(s: UserState, id: string) {
  return workspace(s).recipes.find((r) => r.id === id);
}
export function availableRecipe(s: UserState, id: string) {
  return (
    rankRecipes(s.profile, s.feedback).some((r) => r.recipe.id === id) ||
    !!workspace(s).recipes.find((r) => r.id === id && recipeAllowed(r, s))
  );
}
export function learningSuggestion(s: UserState) {
  const count = s.feedback.filter((f) => feedbackIntent(f).sweet).length;
  return count >= 2 &&
    !workspace(s).memories.some((m) =>
      /less sweet|low sweetness|少甜|不太甜/i.test(m.text),
    )
    ? "Prefer less sweet breakfasts; taste before adding optional sweeteners."
    : null;
}
export function weekDates(start: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start))
    throw Error("Choose a valid start date.");
  const date = new Date(start + "T12:00:00Z");
  if (
    !Number.isFinite(date.getTime()) ||
    date.toISOString().slice(0, 10) !== start
  )
    throw Error("Choose a valid start date.");
  return Array.from({ length: 7 }, (_, i) =>
    new Date(date.getTime() + i * 86400000).toISOString().slice(0, 10),
  );
}
export function shoppingFor(s: UserState, ids: string[]): ShoppingItem[] {
  const items = new Map<string, ShoppingItem>();
  const w = workspace(s);
  const normal = (n: string) => n.toLowerCase().trim().replace(/\s+/g, " ");
  for (const id of ids) {
    const personal = w.recipes.find((r) => r.id === id);
    const ingredients =
      personal?.ingredients ||
      recipes
        .find((r) => r.id === id)
        ?.ingredients.map((i) => {
          const match = i.amount.match(/^([\d.]+)\s*(g|ml|pcs|tsp|tbsp)$/);
          return {
            name: i.name,
            amount: match ? Number(match[1]) : 1,
            unit: match ? match[2] : i.amount,
          };
        }) ||
      [];
    for (const i of ingredients) {
      const key = normal(i.name) + "|" + i.unit;
      const previous = items.get(key);
      if (previous)
        previous.amount = Math.round((previous.amount + i.amount) * 100) / 100;
      else
        items.set(key, {
          id: key,
          name: i.name,
          amount: i.amount,
          unit: i.unit,
          checked: false,
        });
    }
  }
  for (const pantry of w.pantry) {
    const match = pantry.quantity
      .trim()
      .match(/^([\d.]+)\s*(kg|g|ml|l|pcs|tsp|tbsp|pinch|个|克|毫升)$/i);
    if (!match) continue;
    let amount = Number(match[1]),
      unit = match[2].toLowerCase();
    if (unit === "kg") {
      amount *= 1000;
      unit = "g";
    }
    if (unit === "l") {
      amount *= 1000;
      unit = "ml";
    }
    unit =
      ({ 个: "pcs", 克: "g", 毫升: "ml" } as Record<string, string>)[unit] ||
      unit;
    const item = items.get(normal(pantry.name) + "|" + unit);
    if (item)
      item.amount = Math.max(0, Math.round((item.amount - amount) * 100) / 100);
  }
  return [...items.values()].filter((i) => i.amount > 0);
}
