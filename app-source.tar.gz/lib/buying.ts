import { products, recipes } from "./catalog";

export const sourceChecked = "2026-10-31";
export const officialStockists =
  "https://www.verival.at/en/pages/verival-im-handel";
export const officialShipping = "https://www.verival.at/en/pages/faqs";
export const buyingSources: Record<
  string,
  { name: string; url: string; scope: string }
> = {
  "blueberry-apple-porridge": {
    name: "Verival Blueberry–Apple Porridge",
    url: "https://www.verival.at/en/products/heidelbeer-apfel-porridge",
    scope: "Official product reference; app packaging is illustrative.",
  },
  "bircher-porridge": {
    name: "Verival porridge collection",
    url: "https://www.verival.at/en/collections/porridge",
    scope:
      "Official collection including Bircher; choose the exact current product.",
  },
  oats: {
    name: "Verival oat flakes",
    url: "https://www.verival.at/en/products/haferflocken",
    scope: "Official product reference; check pack size and allergen labels.",
  },
  muesli: {
    name: "Verival breakfast collection",
    url: "https://www.verival.at/en/collections/bio-fruehstueck",
    scope: "Official collection; not a verified match for this concept pack.",
  },
  chia: {
    name: "Verival chia seeds",
    url: "https://www.verival.at/en/products/chiasamen",
    scope: "Official product reference; check current availability and labels.",
  },
};
export type Point = { lat: number; lon: number };
export type Place = {
  id: string;
  name: string;
  lat: number;
  lon: number;
  distance: number;
  category: string;
  address: string;
  phone: string;
  website?: string;
  openingHours: string;
  stock: "unknown";
};
export function validPoint(p: Point) {
  return (
    Number.isFinite(p.lat) &&
    Number.isFinite(p.lon) &&
    Math.abs(p.lat) <= 85 &&
    Math.abs(p.lon) <= 180
  );
}
export function distanceMetres(a: Point, b: Point) {
  const radians = (x: number) => (x * Math.PI) / 180;
  const lat = radians(b.lat - a.lat),
    lon = radians(b.lon - a.lon);
  const h =
    Math.sin(lat / 2) ** 2 +
    Math.cos(radians(a.lat)) *
      Math.cos(radians(b.lat)) *
      Math.sin(lon / 2) ** 2;
  return Math.round(
    6371000 * 2 * Math.asin(Math.sqrt(Math.min(1, Math.max(0, h)))),
  );
}
export function safeWebsite(raw: unknown) {
  if (typeof raw !== "string") return undefined;
  try {
    const u = new URL(raw.startsWith("www.") ? "https://" + raw : raw);
    if (!["http:", "https:"].includes(u.protocol) || u.username || u.password)
      return undefined;
    return u.toString();
  } catch {
    return undefined;
  }
}
export function mapEmbed(point: Point, radius = 2000) {
  if (!validPoint(point)) return "";
  const deltaLat = radius / 111320,
    deltaLon =
      radius / (111320 * Math.max(0.08, Math.cos((point.lat * Math.PI) / 180)));
  const bbox = [
    Math.max(-180, point.lon - deltaLon),
    Math.max(-85, point.lat - deltaLat),
    Math.min(180, point.lon + deltaLon),
    Math.min(85, point.lat + deltaLat),
  ].join(",");
  const url = new URL("https://www.openstreetmap.org/export/embed.html");
  url.searchParams.set("bbox", bbox);
  url.searchParams.set("layer", "mapnik");
  url.searchParams.set("marker", `${point.lat},${point.lon}`);
  return url.toString();
}
export function amapSearch(keyword: string, city = "") {
  const u = new URL("https://uri.amap.com/search");
  u.searchParams.set("keyword", keyword.slice(0, 160));
  if (city.trim()) u.searchParams.set("city", city.trim().slice(0, 80));
  u.searchParams.set("view", "map");
  u.searchParams.set("src", "VERIVA");
  u.searchParams.set("callnative", "0");
  return u.toString();
}
export function osmPlace(place: Pick<Place, "lat" | "lon">) {
  return `https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lon}#map=17/${place.lat}/${place.lon}`;
}
export function directions(from: Point, to: Point) {
  const u = new URL("https://www.openstreetmap.org/directions");
  u.searchParams.set("engine", "fossgis_osrm_car");
  u.searchParams.set("route", `${from.lat},${from.lon};${to.lat},${to.lon}`);
  return u.toString();
}
export function retailSearch(keyword: string, provider: "jd" | "tmall") {
  const u = new URL(
    provider === "jd"
      ? "https://search.jd.com/Search"
      : "https://list.tmall.com/search_product.htm",
  );
  u.searchParams.set(
    provider === "jd" ? "keyword" : "q",
    keyword.slice(0, 120),
  );
  if (provider === "jd") u.searchParams.set("enc", "utf-8");
  return u.toString();
}
export function shoppingContext(productId?: string, recipeId?: string) {
  const product = products.find((p) => p.id === productId),
    recipe = recipes.find((r) => r.id === recipeId);
  return {
    product,
    recipe,
    productIds: product ? [product.id] : recipe?.products || [],
    ingredients: recipe?.ingredients.map((i) => i.name) || [],
  };
}
export function normalisePlaces(
  raw: unknown,
  centre: Point,
  radius: number,
): Place[] {
  const elements = (raw as { elements?: unknown[] })?.elements;
  if (!Array.isArray(elements)) return [];
  const places: Place[] = [];
  const seen = new Set<string>();
  for (const element of elements.slice(0, 200)) {
    if (!element || typeof element !== "object") continue;
    const e = element as Record<string, unknown>,
      tags = (e.tags || {}) as Record<string, unknown>,
      center = (e.center || {}) as Record<string, unknown>;
    const lat = Number(e.lat ?? center.lat),
      lon = Number(e.lon ?? center.lon),
      name = typeof tags.name === "string" ? tags.name.slice(0, 100) : "";
    if (!name || !validPoint({ lat, lon })) continue;
    const distance = distanceMetres(centre, { lat, lon });
    if (distance > radius) continue;
    const key =
      name.toLowerCase() + "|" + lat.toFixed(4) + "|" + lon.toFixed(4);
    if (seen.has(key)) continue;
    seen.add(key);
    const clean = (key: string) =>
      typeof tags[key] === "string" ? String(tags[key]).slice(0, 180) : "";
    places.push({
      id: `${e.type}/${e.id}`,
      name,
      lat,
      lon,
      distance,
      category: clean("shop") || "food shop",
      address: [
        clean("addr:street"),
        clean("addr:housenumber"),
        clean("addr:suburb"),
        clean("addr:city"),
      ]
        .filter(Boolean)
        .join(", "),
      phone: clean("contact:phone") || clean("phone"),
      website: safeWebsite(tags["contact:website"] || tags.website),
      openingHours: clean("opening_hours"),
      stock: "unknown",
    });
  }
  return places.sort((a, b) => a.distance - b.distance).slice(0, 12);
}
