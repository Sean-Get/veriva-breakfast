import { products, recipes } from "./catalog";
import { adjustedIngredients } from "./recommendation";
import { isRevisionCurrent } from "./personalisation";
import type { UserState } from "./types";
export type ShopContext = {
  key: string;
  title: string;
  recipeHref?: string;
  productIds: string[];
  ingredients: { name: string; amount: string }[];
  missing: boolean;
};
export function shopContext(
  params: { product?: string | null; recipe?: string | null },
  state: UserState,
): ShopContext {
  const all: ShopContext = {
    key: "all",
    title: "",
    productIds: products.map((p) => p.id),
    ingredients: [],
    missing: false,
  };
  if (params.recipe) {
    const recipe = recipes.find((r) => r.id === params.recipe);
    if (recipe) {
      const revision = state.revisions?.find(
        (r) => r.recipeId === recipe.id && isRevisionCurrent(r, state),
      );
      return {
        key: "recipe:" + recipe.id + (revision?.id || ""),
        title: recipe.name,
        recipeHref: "/recipes/" + recipe.id,
        productIds: recipe.products,
        ingredients: adjustedIngredients(recipe, state.feedback, revision).map(
          (i) => ({
            name: i.name,
            amount: i.amount,
          }),
        ),
        missing: false,
      };
    }
    const personal = state.breakfast?.recipes?.find(
      (r) => r.id === params.recipe,
    );
    if (personal)
      return {
        key: "personal:" + personal.id,
        title: personal.name,
        recipeHref: "/my-recipes/" + encodeURIComponent(personal.id),
        productIds: [],
        ingredients: personal.ingredients.map((i) => ({
          name: i.name,
          amount: `${i.amount} ${i.unit}`,
        })),
        missing: false,
      };
    return { ...all, missing: true };
  }
  if (params.product) {
    const product = products.find((p) => p.id === params.product);
    if (product)
      return {
        ...all,
        key: "product:" + product.id,
        title: product.name,
        productIds: [product.id],
      };
    return { ...all, missing: true };
  }
  return all;
}
