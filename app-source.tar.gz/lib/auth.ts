import { cookies } from "next/headers";
import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import { database, saveState } from "./db";
import { defaultState, type SessionUser } from "./types";
export const cookieName = "veriva_session";
const digest = (s: string) => createHash("sha256").update(s).digest("hex");
export function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  return salt + ":" + scryptSync(password, salt, 64).toString("hex");
}
export function passwordMatches(password: string, hash: string) {
  const [salt, key] = hash.split(":");
  if (!salt || !key) return false;
  const stored = Buffer.from(key, "hex");
  const next = scryptSync(password, salt, 64);
  return stored.length === next.length && timingSafeEqual(stored, next);
}
export async function currentUser(): Promise<SessionUser | null> {
  const token = (await cookies()).get(cookieName)?.value;
  if (!token) return null;
  const u = database()
    .prepare(
      "SELECT u.id,u.name,u.email,u.guest FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>?",
    )
    .get(digest(token), Date.now()) as
    | { id: string; name: string; email: string | null; guest: number }
    | undefined;
  return u ? { ...u, guest: !!u.guest } : null;
}
export async function sessionFor(userId: string) {
  const token = randomBytes(32).toString("hex");
  database().prepare("DELETE FROM sessions WHERE expires<?").run(Date.now());
  database()
    .prepare("INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)")
    .run(digest(token), userId, Date.now() + 30 * 86400000);
  (await cookies()).set(cookieName, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE === "true",
    maxAge: 30 * 86400,
    path: "/",
  });
}
export async function endSession() {
  const jar = await cookies();
  const token = jar.get(cookieName)?.value;
  if (token)
    database().prepare("DELETE FROM sessions WHERE token=?").run(digest(token));
  jar.delete(cookieName);
}
export async function createGuest() {
  const id = randomUUID();
  database()
    .prepare("INSERT INTO users(id,name,guest,created_at) VALUES(?,?,1,?)")
    .run(id, "Friend", Date.now());
  saveState(id, defaultState());
  await sessionFor(id);
  return { id, name: "Friend", email: null, guest: true } satisfies SessionUser;
}
