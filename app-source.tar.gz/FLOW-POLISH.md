# VERIVA v7.5 · A more connected morning

## What is improved
- Product detail → Map & buying options keeps the selected product.
- Recipe / My recipes → Find ingredients opens the matching Shop checklist. Ingredient quantities use the same current taste adjustments as the recipe page. The map and marketplace choices keep the recipe's ingredients.
- Personal recipe buying links resolve only from the current user's saved collection. Unknown or deleted recipes display a clear message.
- The ingredient checklist is temporary for the current visit and does not change saved pantry quantities.
- My recipes supports ingredient/name search, Favourites / Personal filters, current preference filtering and removing a favourite.
- Daily AI requests ignore old responses after changes, recover from failed loading, and refresh the daily context on return to the tab and at the Shanghai date boundary. Saving an AI breakfast keeps the same recommendation and shows a saved state.
- Quick questions open an editable chat draft; they are sent only when the user presses Send. Chat links back to today's recommendation.
- Product reviews are paginated and filtered on the server. Overall totals and averages cover all visible submitted reviews, including older pages. Hidden reviews and fictional examples are excluded.

## Suggested classroom demonstration
1. Open a product, choose Map & buying options, and show that the exact product remains selected.
2. Open a recipe, choose Find ingredients & nearby shops, tick two ingredients, then jump to the map.
3. Ask AI for a daily breakfast, save it, and confirm that the same breakfast now says Saved to My recipes.
4. Search My recipes for an ingredient, then try a search with no matches and Clear filters.
5. Open one of Oatie's starter questions, edit the draft and send it. Return to AI Expert and ask for a new pick based on the conversation.
6. Submit different product ratings. Filter Positive / Mixed / Critical. After more than eight reviews, show the next page. Use /admin to hide and restore a review and show that public totals change.

## Delivery
Extract the entire ZIP to a short Windows path and start Start-VERIVA.cmd. The original authorised classroom AI configuration is retained. AI calls require Internet. Keep the server window open. Copy the old complete data folder before starting the new version to retain existing records.

This is the complete local APP. The static GitHub Pages and chatgpt.site landing URLs have not been converted into a shared server. Each local copy has its own data.
