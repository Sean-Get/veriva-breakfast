# VERIVA v7.4 · Connected Breakfast

Start the complete APP with Start-VERIVA.cmd. No Node installation is required. AI requires an Internet connection; the classroom configuration is retained from the previously authorised package.

## Classroom walkthrough
1. Health: select optional No nuts / No dairy / No gluten / No eggs or Plant-based. Save. Health-record sharing remains optional.
2. Click Oatie on the right to open AI Expert. Talk to Oatie to record breakfast preferences in the conversation.
3. Return to AI Expert and select Ask AI for today's pick. The request uses the current profile, recent conversation, saved memories and feedback. Non-consented health records are excluded. Profile match works without AI and is labelled separately.
4. Open Recipe & cooking steps, or Save to My recipes. Recipes → My recipes groups saved favourites and personal recipes.
5. Shop: click a package or product title for description, clearer pack facts, demo price, basket and product reviews. Positive, Mixed and Critical filters apply to actual submissions. Fictional examples are separate and excluded from ratings.
6. Post a review with a chosen public name. In /admin, scroll to product review moderation and refresh. Hide and restore the same record. Visit totals remain at the top.
7. Recipes have Cooking tips & experiences. Nearby maps and buying links are in Shop. Factory adds official ingredient, mixing and packing photographs with source links.

## Navigation changes
Planner is now AI Expert in the main navigation. Existing memories, pantry, personal recipe controls, weekly planning and Undo remain under the breakfast workspace linked from AI Expert. Old /planner links open AI Expert. Create & explore is removed from navigation and its old route opens the recipe library; creator video ideas remain available as requested earlier. Guide is removed from consumer navigation and its old page is unavailable.

## Data and sharing
Keep the complete data folder when upgrading. Visit counts, product reviews and daily AI picks persist on the server. Different local copies have separate databases. The package has no personal database or QA reviews. This update does not publish the full backend to the existing static GitHub Pages or chatgpt.site landing URLs.

## Demonstration limits
Pack images and prices are illustrative, without real checkout. Example reviews are fictional. Official supply-chain sources are brand-published evidence, not an independent audit. Nearby classroom shops are fictional; live maps and external buying links require network access and do not confirm stock. No real tablet hardware performance claim is made from viewport simulation.
