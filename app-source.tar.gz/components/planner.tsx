"use client";
import "./planner.css";
import { useState } from "react";
import Link from "next/link";
import { useStore, api } from "./store";
import { Button } from "./ui";
import { WhereToBuy } from "./where-to-buy";
import { GrowthEntry } from "./growth";
import { recipes as catalog } from "@/lib/catalog";
import {
  workspace,
  learningSuggestion,
  shoppingFor,
  recipeAllowed,
  planningContext,
  type PersonalRecipe,
  type Proposal,
} from "@/lib/breakfast";

function useAssistant() {
  const { refresh, notify } = useStore();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function run(body: Record<string, unknown>) {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await api("/api/assistant", body);
      await refresh();
      if (result.message) notify(result.message);
      return result;
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return { run, busy, error };
}
function ErrorNote({ text }: { text: string }) {
  return text ? (
    <p role="alert" className="planner-error">
      {text}
    </p>
  ) : null;
}
function RecipePreview({ recipe }: { recipe: PersonalRecipe }) {
  return (
    <div className="personal-recipe-preview">
      <h3>{recipe.name}</h3>
      <p>{recipe.description}</p>
      <p className="small-note">
        {recipe.activeMinutes} min active · {recipe.waitingMinutes} min waiting
        · ~¥{recipe.estimatedCost.toFixed(2)} estimated / recipe · {recipe.servings||1} serving(s)
      </p>
      <ul>
        {recipe.ingredients.map((i, n) => (
          <li key={n}>
            {i.amount} {i.unit} · {i.name}
          </li>
        ))}
      </ul>
      <ol>
        {recipe.steps.map((step, n) => (
          <li key={n}>{step}</li>
        ))}
      </ol>
      <p className="small-note">
        Declared allergens: {recipe.allergens.join(", ") || "none declared"}.
        Check actual labels and cross-contact.
      </p>
    </div>
  );
}

export function AssistantProposalCard({ id }: { id: string }) {
  const { data } = useStore(),
    { run, busy, error } = useAssistant(),
    proposal = workspace(data.state).proposals.find((p) => p.id === id);
  if (!proposal)
    return (
      <div className="assistant-proposal">
        <p>This proposal is no longer pending.</p>
        <Link href="/workspace">View your saved workspace →</Link>
      </div>
    );
  return (
    <section className="assistant-proposal" aria-label={proposal.title}>
      <span className="date-label">REVIEW BEFORE APPLYING</span>
      <h3>{proposal.title}</h3>
      {proposal.context !== planningContext(data.state) && (
        <p role="alert">
          Your workspace changed. Discard this proposal and generate a fresh
          one.
        </p>
      )}
      {proposal.memory && <blockquote>{proposal.memory}</blockquote>}
      {proposal.plan && (
        <>
          <p>{proposal.plan.summary}</p>
          <p>
            Weekly budget: ¥{proposal.plan.budget} · planning estimates only
          </p>
          <ol>
            {proposal.plan.days.map((d) => (
              <li key={d.date}>
                {d.date} ·{" "}
                {proposal.recipes?.find((r) => r.id === d.recipeId)?.name ||
                  workspace(data.state).recipes.find((r) => r.id === d.recipeId)
                    ?.name ||
                  catalog.find((r) => r.id === d.recipeId)?.name}
              </li>
            ))}
          </ol>
        </>
      )}
      {proposal.recipes?.map((r) => (
        <details key={r.id} open={proposal.kind === "recipe"}>
          <summary>
            {r.name} · {r.activeMinutes} min active
          </summary>
          <RecipePreview recipe={r} />
        </details>
      ))}
      {proposal.shopping && (
        <>
          <p>
            Amounts are combined across the plan; known pantry quantities are
            subtracted by exact ingredient name and unit.
          </p>
          <ul>
            {proposal.shopping.length ? (
              proposal.shopping.map((i) => (
                <li key={i.id}>
                  {i.name} · {i.amount} {i.unit}
                </li>
              ))
            ) : (
              <li>No extra measured ingredients needed.</li>
            )}
          </ul>
        </>
      )}
      <ErrorNote text={error} />
      <div className="planner-actions">
        <Button
          variant="secondary"
          disabled={busy}
          onClick={() => run({ action: "dismiss", id })}
        >
          Discard proposal
        </Button>
        <Button
          disabled={busy || proposal.context !== planningContext(data.state)}
          onClick={() => run({ action: "execute", id })}
        >
          {busy ? "Applying…" : "Apply & save"}
        </Button>
        <Link href="/workspace">Open workspace →</Link>
      </div>
      <p className="small-note">
        This will change your saved workspace. Undo is available in your workspace.
      </p>
    </section>
  );
}

export function Planner() {
  const { data } = useStore(),
    w = workspace(data.state),
    { run, busy, error } = useAssistant();
  const [tab, setTab] = useState("Memory"),
    [memory, setMemory] = useState(""),
    [editId, setEditId] = useState(""),
    [pantryName, setPantryName] = useState(""),
    [quantity, setQuantity] = useState(""),
    [request, setRequest] = useState(""),
    [budget, setBudget] = useState(100),
    [start, setStart] = useState(() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }),
    [replacement, setReplacement] = useState<Record<string, string>>({});
  const suggestion = learningSuggestion(data.state);
  async function generate(mode: string) {
    await run({ action: "propose", mode, request, startDate: start, budget });
  }
  const recipeName = (id: string) =>
    w.recipes.find((r) => r.id === id)?.name ||
    catalog.find((r) => r.id === id)?.name ||
    "Unavailable recipe";
  const missingReferences = w.plan?.days.some(
    (d) =>
      !w.recipes.some(
        (r) => r.id === d.recipeId && recipeAllowed(r, data.state),
      ) && !catalog.some((r) => r.id === d.recipeId),
  );
  return (
    <main className="main planner-page">
      <div className="planner-heading">
        <div>
          <span className="date-label">YOUR MORNING, CONNECTED</span>
          <h1>A little plan. A better morning.</h1>
          <p>
            Your breakfast memories, ingredients and ideas, all in one place.
          </p>
        </div>
        <Link className="subtle-link" href="/chat">
          Talk to your breakfast AI →
        </Link>
      </div>
      <div className="planner-toolbar">
        <div role="tablist" aria-label="Breakfast workspace">
          {["Memory", "Pantry", "Recipes", "Week", "Shopping"].map((t) => (
            <button
              key={t}
              role="tab"
              aria-selected={tab === t}
              onClick={() => setTab(t)}
            >
              {t}
            </button>
          ))}
        </div>
        <Button
          variant="secondary"
          disabled={busy || !w.undo.length}
          onClick={() => run({ action: "undo" })}
        >
          Undo last action
        </Button>
      </div>
      <ErrorNote text={error} />
      {!!w.proposals.length && (
        <section className="planner-pending">
          <h2>Ready for your review</h2>
          {w.proposals.slice(0, 3).map((p) => (
            <AssistantProposalCard key={p.id} id={p.id} />
          ))}
        </section>
      )}
      <section className="planner-panel" role="tabpanel" aria-label={tab}>
        {tab === "Memory" && (
          <>
            <h2>What your AI remembers.</h2>
            <p>
              These breakfast preferences are included in future AI requests.
              Edit or delete them anytime. Keep health measurements in{" "}
              <Link href="/health">Health records</Link>, where AI consent is
              separate.
            </p>
            {suggestion && (
              <aside className="planner-learning">
                <h3>A pattern in your feedback</h3>
                <p>
                  You have mentioned too much sweetness more than once. Remember
                  a less-sweet preference for future breakfasts?
                </p>
                <Button
                  variant="secondary"
                  disabled={busy}
                  onClick={() =>
                    run({
                      action: "propose",
                      mode: "memory",
                      request: suggestion,
                    })
                  }
                >
                  Review this memory
                </Button>
              </aside>
            )}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const result = await run({
                  action: "memory-edit",
                  id: editId || undefined,
                  text: memory,
                });
                if (result) {
                  setMemory("");
                  setEditId("");
                }
              }}
            >
              <label>
                Breakfast preference
                <input
                  required
                  minLength={3}
                  maxLength={180}
                  value={memory}
                  onChange={(e) => setMemory(e.target.value)}
                  placeholder="I prefer warm breakfasts and a gentle sweetness."
                />
              </label>
              <Button disabled={busy}>
                {editId ? "Save memory changes" : "Add memory"}
              </Button>
              {editId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditId("");
                    setMemory("");
                  }}
                >
                  Cancel editing
                </button>
              )}
            </form>
            <ul className="workspace-list">
              {w.memories.map((m) => (
                <li key={m.id}>
                  <p>{m.text}</p>
                  <div>
                    <button
                      onClick={() => {
                        setEditId(m.id);
                        setMemory(m.text);
                      }}
                    >
                      Edit
                    </button>
                    <button
                      disabled={busy}
                      onClick={() => run({ action: "memory-delete", id: m.id })}
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))}
            </ul>
            {!w.memories.length && (
              <p>
                No saved memories yet. Tell your AI what makes a good morning
                for you.
              </p>
            )}
          </>
        )}
        {tab === "Pantry" && (
          <>
            <h2>What do you already have?</h2>
            <p>
              Use ingredient names you cook with. Add measured quantities such
              as “200 g”, “500 ml” or “2 pcs” so the shopping list can subtract
              them.
            </p>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const result = await run({
                  action: "pantry",
                  items: [
                    ...w.pantry,
                    { id: crypto.randomUUID(), name: pantryName, quantity },
                  ],
                });
                if (result) {
                  setPantryName("");
                  setQuantity("");
                }
              }}
            >
              <div className="planner-fields">
                <label>
                  Ingredient
                  <input
                    required
                    maxLength={70}
                    value={pantryName}
                    onChange={(e) => setPantryName(e.target.value)}
                    placeholder="Rolled oats"
                  />
                </label>
                <label>
                  Amount on hand
                  <input
                    maxLength={70}
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="200 g"
                  />
                </label>
              </div>
              <Button disabled={busy}>Add ingredient</Button>
            </form>
            <ul className="workspace-list">
              {w.pantry.map((p) => (
                <li key={p.id}>
                  <span>
                    {p.name} · {p.quantity || "quantity not recorded"}
                  </span>
                  <button
                    disabled={busy}
                    onClick={() =>
                      run({
                        action: "pantry",
                        items: w.pantry.filter((i) => i.id !== p.id),
                      })
                    }
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
            <Button
              variant="secondary"
              disabled={busy || !w.pantry.length}
              onClick={() => {
                setRequest(
                  "Use my saved pantry ingredients first. Tell me what else is needed.",
                );
                setTab("Recipes");
              }}
            >
              Create breakfast with these ingredients →
            </Button>
          </>
        )}
        {tab === "Recipes" && (
          <>
            <h2>Breakfasts made for you.</h2>
            <p>
              Generate a measured recipe using your memories, pantry and current
              dietary exclusions. Review it before saving.
            </p>
            <label>
              What would you like?
              <textarea
                value={request}
                maxLength={700}
                onChange={(e) => setRequest(e.target.value)}
                placeholder="A warm, less sweet breakfast with oats and banana, ready in five minutes."
              />
            </label>
            <Button disabled={busy} onClick={() => generate("recipe")}>
              {busy ? "Working…" : "Create a personal recipe"}
            </Button>
            <div className="planner-recipe-grid">
              {w.recipes.map((r) => (
                <article key={r.id}>
                  <span className="date-label">YOUR AI RECIPE</span>
                  <h3>{r.name}</h3>
                  <p>{r.description}</p>
                  <p>
                    {r.activeMinutes} min active · {r.waitingMinutes} min
                    waiting
                  </p>
                  <Link href={"/my-recipes/" + r.id}>
                    Ingredients & method →
                  </Link>
                  {!recipeAllowed(r, data.state) && (
                    <p className="planner-error">
                      Your preferences changed. Revise this recipe before
                      cooking or planning.
                    </p>
                  )}
                  <button
                    disabled={busy}
                    onClick={() => run({ action: "recipe-delete", id: r.id })}
                  >
                    Remove saved recipe
                  </button>
                </article>
              ))}
            </div>
            {!w.recipes.length && (
              <p>Your saved personal recipes will appear here.</p>
            )}
          </>
        )}
        {tab === "Week" && (
          <>
            <h2>Your next seven mornings.</h2>
            <p>
              Balance variety, preparation time and ingredient reuse. Costs are
              rough food estimates in CNY, not current store prices or a
              spending guarantee.
            </p>
            <div className="planner-fields">
              <label>
                First day
                <input
                  type="date"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                />
              </label>
              <label>
                Weekly food budget (CNY)
                <input
                  type="number"
                  min={7}
                  max={2000}
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                />
              </label>
            </div>
            <label>
              Anything to plan around?
              <textarea
                maxLength={700}
                value={request}
                onChange={(e) => setRequest(e.target.value)}
                placeholder="Reuse fruit across the week; warm bowls before class."
              />
            </label>
            <Button
              disabled={busy || !start || budget < 7}
              onClick={() => generate("week")}
            >
              {busy ? "Working…" : "Create seven-day plan"}
            </Button>
            {w.plan && (
              <>
                <p>{w.plan.summary}</p>
                <p>
                  Planned cost: ~¥
                  {w.plan.days
                    .reduce(
                      (sum, d) =>
                        sum +
                        (w.recipes.find((r) => r.id === d.recipeId)
                          ?.estimatedCost || 0),
                      0,
                    )
                    .toFixed(2)}{" "}
                  / ¥{w.plan.budget} budget
                </p>
                {missingReferences && (
                  <p role="alert">
                    Some breakfasts no longer fit your preferences. Review the
                    days below.
                  </p>
                )}
                <div className="week-grid">
                  {w.plan.days.map((d) => (
                    <article key={d.date}>
                      <time>{d.date}</time>
                      <h3>{recipeName(d.recipeId)}</h3>
                      <Link
                        href={
                          (d.recipeId.startsWith("custom-")
                            ? "/my-recipes/"
                            : "/recipes/") + d.recipeId
                        }
                      >
                        View breakfast →
                      </Link>
                      <label>
                        Replace with
                        <select
                          value={replacement[d.date] || ""}
                          onChange={(e) =>
                            setReplacement({
                              ...replacement,
                              [d.date]: e.target.value,
                            })
                          }
                        >
                          <option value="">Choose a saved recipe</option>
                          {w.recipes
                            .filter((r) => recipeAllowed(r, data.state))
                            .map((r) => (
                              <option key={r.id} value={r.id}>
                                {r.name}
                              </option>
                            ))}
                        </select>
                      </label>
                      <Button
                        variant="secondary"
                        disabled={busy || !replacement[d.date]}
                        onClick={() =>
                          run({
                            action: "propose",
                            mode: "replace",
                            date: d.date,
                            recipeId: replacement[d.date],
                          })
                        }
                      >
                        Review replacement
                      </Button>
                    </article>
                  ))}
                </div>
                <Button
                  disabled={busy}
                  onClick={() => run({ action: "propose", mode: "shopping" })}
                >
                  Create shopping list from this week
                </Button>
              </>
            )}
          </>
        )}
        {tab === "Shopping" && (
          <>
            <h2>A little list, less waste.</h2>
            <p>
              Repeated ingredients are combined. Recorded pantry quantities are
              subtracted only when ingredient names and units match; unknown
              quantities are kept on the list for you to check.
            </p>
            <Button
              variant="secondary"
              disabled={busy || !w.plan}
              onClick={() => run({ action: "propose", mode: "shopping" })}
            >
              Rebuild from my week
            </Button>
            <ul className="workspace-list">
              {w.shopping.map((i) => (
                <li key={i.id}>
                  <label>
                    <input
                      type="checkbox"
                      checked={i.checked}
                      disabled={busy}
                      onChange={() =>
                        run({ action: "shopping-toggle", id: i.id })
                      }
                    />
                    <span
                      style={{
                        textDecoration: i.checked ? "line-through" : undefined,
                      }}
                    >
                      {i.name} · {i.amount} {i.unit}
                    </span>
                  </label>
                </li>
              ))}
            </ul>
            {!w.shopping.length && (
              <p>
                No shopping list saved yet. Create one from a saved recipe or
                weekly plan.
              </p>
            )}
            <p className="small-note">
              This list does not add products to your basket or place an order.
            </p>
          </>
        )}
      </section>
    </main>
  );
}

export function PersonalRecipePage({ id }: { id: string }) {
  const { data } = useStore(),
    w = workspace(data.state),
    recipe = w.recipes.find((r) => r.id === id),
    { run, busy, error } = useAssistant(),
    [feedback, setFeedback] = useState("");
  if (!recipe)
    return (
      <main className="main planner-page">
        <h1>Your personal recipe</h1>
        <p>This recipe is not in your saved workspace.</p>
        <Link href="/workspace">Open workspace →</Link>
      </main>
    );
  const missing = shoppingFor(data.state, [id]);
  return (
    <main className="main planner-page">
      <Link href="/workspace">← Your breakfast workspace</Link>
      <span className="date-label">PERSONAL RECIPE · AI GENERATED</span>
      <h1>{recipe.name}</h1>
      {!recipeAllowed(recipe, data.state) && (
        <p role="alert" className="planner-error">
          This recipe no longer meets your current time or dietary preferences.
          Generate a revised version before using it.
        </p>
      )}
      <RecipePreview recipe={recipe} />
      <GrowthEntry recipeId={id} />
      <Link href={`/shop?recipe=${encodeURIComponent(id)}#shopping-list`}>Find ingredients in the shop →</Link>
      <section className="planner-panel">
        <h2>What else do you need?</h2>
        <ul>
          {missing.map((i) => (
            <li key={i.id}>
              {i.name} · {i.amount} {i.unit}
            </li>
          ))}
        </ul>
        {!missing.length && (
          <p>Your recorded pantry covers the measured ingredients.</p>
        )}
        <Button
          disabled={busy}
          onClick={() =>
            run({ action: "propose", mode: "shopping", recipeId: id })
          }
        >
          Review shopping list
        </Button>
      </section>
      <section className="planner-panel">
        <h2>Make the next bowl better.</h2>
        <p>
          Describe a taste or texture change. Your current recipe stays saved
          while you review a revised version.
        </p>
        <label>
          Your feedback
          <textarea
            maxLength={500}
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Too sweet; keep the rest the same."
          />
        </label>
        <Button
          disabled={busy || !feedback.trim()}
          onClick={() =>
            run({
              action: "propose",
              mode: "recipe",
              recipeId: id,
              request: `Revise my saved recipe ${recipe.name} (${id}). Feedback: ${feedback}. Keep unrelated ingredient quantities and my dietary exclusions. Save as a new version only after I approve.`,
            })
          }
        >
          {busy ? "Working…" : "Create revised version"}
        </Button>
        <ErrorNote text={error} />
      </section>
      {w.proposals
        .filter((p) => p.kind === "recipe" || p.kind === "shopping")
        .slice(0, 3)
        .map((p) => (
          <AssistantProposalCard key={p.id} id={p.id} />
        ))}
    </main>
  );
}
