"use client";
import * as Dialog from "@radix-ui/react-dialog";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { XIcon } from "@phosphor-icons/react";
import { useRef, type ComponentProps, type ReactNode } from "react";
import { m, AnimatePresence, useReducedMotion } from "motion/react";
export const cn = (...v: ClassValue[]) => twMerge(clsx(v));
const variants = cva("button", {
  variants: {
    variant: {
      primary: "button-primary",
      secondary: "button-secondary",
      ghost: "button-ghost",
      dark: "button-dark",
    },
    size: { default: "", small: "button-small", icon: "button-icon" },
  },
  defaultVariants: { variant: "primary", size: "default" },
});
export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ComponentProps<"button"> &
  VariantProps<typeof variants> & { asChild?: boolean }) {
  const C = asChild ? Slot : "button";
  return (
    <C className={cn(variants({ variant, size }), className)} {...props} />
  );
}
export function Modal({
  open,
  onOpenChange,
  title,
  description,
  children,
  className,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
}) {
  const reduced = useReducedMotion();
  const returnFocus = useRef<HTMLElement | null>(null);
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal forceMount>
        <AnimatePresence>
          {open && (
            <Dialog.Overlay forceMount asChild key="overlay">
              <m.div
                className="modal-overlay"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: reduced ? 0 : 0.2 }}
              />
            </Dialog.Overlay>
          )}
          {open && (
            <Dialog.Content
              forceMount
              asChild
              key="content"
              onOpenAutoFocus={() => {
                returnFocus.current =
                  document.activeElement instanceof HTMLElement
                    ? document.activeElement
                    : null;
              }}
              onCloseAutoFocus={(event) => {
                event.preventDefault();
                if (returnFocus.current?.isConnected)
                  returnFocus.current.focus({ preventScroll: true });
              }}
            >
              <m.div
                className={cn("modal", className)}
                initial={{
                  opacity: 0,
                  transform: reduced
                    ? "translate(-50%, -50%)"
                    : "translate(-50%, -50%) scale(0.97)",
                }}
                animate={{
                  opacity: 1,
                  transform: "translate(-50%, -50%) scale(1)",
                }}
                exit={{
                  opacity: 0,
                  transform: reduced
                    ? "translate(-50%, -50%)"
                    : "translate(-50%, -50%) scale(0.97)",
                }}
                transition={{
                  duration: reduced ? 0 : 0.22,
                  ease: [0.23, 1, 0.32, 1],
                }}
              >
                <div className="modal-heading">
                  <div>
                    <Dialog.Title>{title}</Dialog.Title>
                    {description ? (
                      <Dialog.Description>{description}</Dialog.Description>
                    ) : (
                      <Dialog.Description className="sr-only">
                        {title}
                      </Dialog.Description>
                    )}
                  </div>
                  <Dialog.Close
                    className="icon-button"
                    aria-label="Close dialog"
                  >
                    <XIcon size={22} />
                  </Dialog.Close>
                </div>
                {children}
              </m.div>
            </Dialog.Content>
          )}
        </AnimatePresence>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
