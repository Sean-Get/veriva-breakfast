"use client";
import { useState } from "react";
import { demoArea, demoMapPoint, demoRoute } from "@/lib/buying-demo";
import { type Place } from "@/lib/buying";

export function DemoBuyingMap({
  places,
  selected,
  route,
  onSelect,
}: {
  places: Place[];
  selected: Place | null;
  route: Place | null;
  onSelect: (place: Place) => void;
}) {
  const [zoom, setZoom] = useState(1);
  const focus = selected ? demoMapPoint(selected) : demoMapPoint(demoArea);
  const width = 900 / zoom,
    height = 620 / zoom;
  const vx = Math.max(0, Math.min(900 - width, focus[0] - width / 2)),
    vy = Math.max(0, Math.min(620 - height, focus[1] - height / 2));
  return (
    <div className="demo-map-panel">
      <div className="demo-map-toolbar">
        <span>CLASSROOM MAP · FICTIONAL</span>
        <div>
          <button
            type="button"
            aria-label="Zoom out demo map"
            disabled={zoom <= 1}
            onClick={() => setZoom((z) => Math.max(1, z - 0.5))}
          >
            −
          </button>
          <output aria-label="Map zoom">{Math.round(zoom * 100)}%</output>
          <button
            type="button"
            aria-label="Zoom in demo map"
            disabled={zoom >= 2.5}
            onClick={() => setZoom((z) => Math.min(2.5, z + 0.5))}
          >
            +
          </button>
          <button type="button" onClick={() => setZoom(1)}>
            Reset view
          </button>
        </div>
      </div>
      <svg
        className="demo-map-svg"
        viewBox={`${vx} ${vy} ${width} ${height}`}
        aria-label="Interactive fictional campus map"
        role="group"
      >
        <rect width="900" height="620" fill="#eeeedd" />
        <path
          d="M750 -20 Q640 160 740 310 T730 650"
          fill="none"
          stroke="#bed7d3"
          strokeWidth="74"
        />
        <rect x="40" y="38" width="210" height="175" rx="48" fill="#cfddbd" />
        <rect x="52" y="405" width="210" height="170" rx="35" fill="#cfddbd" />
        {[100, 270, 440, 610].map((x, i) => (
          <g key={x}>
            <rect
              x={x}
              y="90"
              width="98"
              height="75"
              rx="12"
              fill={i % 2 ? "#e0cbbb" : "#dfd4bc"}
            />
            <rect x={x} y="365" width="90" height="82" rx="12" fill="#e0d6c3" />
            <rect
              x={x}
              y="500"
              width="105"
              height="62"
              rx="12"
              fill="#e1cfbf"
            />
          </g>
        ))}
        <g fill="none" stroke="#fffdf5" strokeWidth="27" strokeLinecap="round">
          <path d="M0 310H900M0 230H900M0 470H900M386 0V620M498 0V620M562 0V620M322 0V620M738 0V620M162 0V620" />
        </g>
        <g fill="#67735f" fontSize="15" fontFamily="sans-serif">
          <text x="86" y="64">
            The breakfast garden
          </text>
          <text x="445" y="292">
            Orchard Walk
          </text>
          <text x="55" y="490">
            Library Square
          </text>
          <text x="765" y="390" transform="rotate(-80 765 390)">
            Morning River
          </text>
        </g>
        {route && (
          <polyline
            data-testid="demo-route"
            points={demoRoute(route)
              .map((p) => p.join(","))
              .join(" ")}
            fill="none"
            stroke="#2e6545"
            strokeWidth="9"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="13 9"
          />
        )}
        <circle cx="450" cy="310" r="15" fill="#fff" />
        <circle cx="450" cy="310" r="8" fill="#4d7693" />
        <text x="462" y="335" fontSize="14" fill="#294837">
          Demo start
        </text>
        {places.map((place, i) => {
          const [x, y] = demoMapPoint(place),
            active = selected?.id === place.id;
          return (
            <g
              key={place.id}
              role="button"
              tabIndex={0}
              aria-label={`Select ${place.name} on demo map`}
              aria-pressed={active}
              onClick={() => onSelect(place)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onSelect(place);
                }
              }}
              className="demo-map-marker"
            >
              <circle
                cx={x}
                cy={y}
                r={active ? 24 : 20}
                fill={active ? "#8b593d" : "#355e43"}
                stroke="#fffdf5"
                strokeWidth="4"
              />
              <text
                x={x}
                y={y + 6}
                textAnchor="middle"
                fill="#fff"
                fontSize="18"
                fontWeight="700"
              >
                {i + 1}
              </text>
              <rect
                x={x - 76}
                y={y - 53}
                width="152"
                height="24"
                rx="8"
                fill="#fffdf5"
              />
              <text
                x={x}
                y={y - 36}
                textAnchor="middle"
                fill="#294837"
                fontSize="12"
              >
                {place.name}
              </text>
            </g>
          );
        })}
      </svg>
      <p className="demo-map-caption">
        {selected
          ? `${selected.name} · ${selected.distance} m from demo start`
          : "Select a numbered shop to explore."}
        {route ? ` · Illustrative route to ${route.name}` : ""}
      </p>
    </div>
  );
}
