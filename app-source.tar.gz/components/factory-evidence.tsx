const evidence = [
  {
    step: "01 · INGREDIENTS",
    image: "/images/factory-ingredients-v2.webp",
    title: "From selected raw ingredients",
    text: "Verival describes using organically farmed raw ingredients and long-term suppliers.",
    source: "https://www.verival.at/en/pages/zutaten",
  },
  {
    step: "02 · MIXING",
    image: "/images/factory-mixing-v2.webp",
    title: "Mixed and filled in Tyrol",
    text: "The brand's ingredient page shows porridge being mixed by hand at its production facility.",
    source: "https://www.verival.at/en/pages/zutaten",
  },
  {
    step: "03 · PACKING",
    image: "/images/factory-production.webp",
    title: "Packed and dispatched",
    text: "Verival's FAQ describes production, packing and dispatch at its Langkampfen factory.",
    source: "https://www.verival.at/en/pages/faqs",
  },
];
export function FactoryEvidence() {
  return (
    <section className="factory-evidence" id="factory-evidence">
      <span className="date-label">FOLLOW THE SUPPLY CHAIN</span>
      <h2>From ingredients to your cupboard.</h2>
      <p>
        Official photographs and source material, gathered for this classroom
        project.
      </p>
      <div className="evidence-grid">
        {evidence.map((e) => (
          <article key={e.step}>
            <img
              src={e.image}
              alt={e.title}
              width={600}
              height={430}
              loading="lazy"
            />
            <span className="date-label">{e.step}</span>
            <h3>{e.title}</h3>
            <p>{e.text}</p>
            <a href={e.source} target="_blank" rel="noreferrer">
              View official source ↗
            </a>
          </article>
        ))}
      </div>
      <div className="evidence-note">
        <h3>Evidence you can inspect</h3>
        <p>
          <a
            href="https://www.verival.at/en/pages/faqs"
            target="_blank"
            rel="noreferrer"
          >
            Brand FAQ: ingredient quality and production ↗
          </a>
        </p>
        <p>
          <a
            href="https://www.verival.at/en/pages/ueber-uns"
            target="_blank"
            rel="noreferrer"
          >
            Brand story: origin and organic certification statements ↗
          </a>
        </p>
        <small>
          Sources checked 6 November 2026. Photos © Verival. These are
          brand-published statements, not an independent audit, shipment
          tracking or product-specific stock evidence.
        </small>
      </div>
    </section>
  );
}
