"use client";
import { RecipeCollectionEntry } from "./recipe-collection-entry";
import { VisitTracker } from "./traffic";
import { shopContext } from "@/lib/shop-context";
import { ShoppingContext } from "./shop-context";
import { ExpertPage, FloatingExpert, MyRecipesPage } from "./expert";
import Link from "next/link";
import { IdeasPage, CreatorProjectPage, MyCreations } from "./creator-ideas";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useRef, useState, type FormEvent } from "react";
import {
  ArrowRightIcon,
  ArrowUpRightIcon,
  ArrowLeftIcon,
  LeafIcon,
  SparkleIcon,
  SunIcon,
  HeartIcon,
  HouseIcon,
  BookOpenIcon,
  ShoppingBagIcon,
  UserIcon,
  ClockIcon,
  MagnifyingGlassIcon,
  CheckIcon,
  PlusIcon,
  MinusIcon,
  PaperPlaneTiltIcon,
  ArrowCounterClockwiseIcon,
  SignOutIcon,
  SlidersHorizontalIcon,
  StarIcon,
  PlantIcon,
  DropIcon,
  LightningIcon,
  BarbellIcon,
  GlobeHemisphereWestIcon,
  PackageIcon,
  ChatCircleDotsIcon,
  XIcon,
  ShieldCheckIcon,
  WarningCircleIcon,
} from "@phosphor-icons/react";
import { Button, Modal, cn } from "./ui";
import { useStore, api } from "./store";
import {
  recipes,
  products,
  goalNames,
  dietNames,
  type Recipe,
} from "@/lib/catalog";
import {
  rankRecipes,
  adjustedIngredients,
  cartTotal,
  preferenceKey,
} from "@/lib/recommendation";
import {
  defaultHealth,
  type Profile,
  type Goal,
  type Message,
} from "@/lib/types";
import { revisionSteps, isRevisionCurrent } from "@/lib/personalisation";
import { scrollToLatest } from "@/lib/browser";
import { HealthFields } from "./health-fields";
import {
  HealthPage,
  CommunityPage,
  OrdersPage,
  FloatingBasket,
  HealthEntry,
} from "./week6";
import { AdminPage } from "./admin";
import { ProductHome, ProductDetail, RecipePersonalPick } from "./product-home";
import { RecipeCommunity } from "./recipe-community";
import { EnglishGuide } from "./english-guide";
import { AnimatedNotice } from "./motion";
import { CookingGuide, CookingPhoto } from "./recipe-cooking";
import { isProductPage } from "@/lib/navigation";
import { recipeMethods } from "@/lib/recipe-methods";
import { ChatRecipeCards, ChatCapabilities } from "./chat-recipes";
import { Planner, PersonalRecipePage, AssistantProposalCard } from "./planner";
import { recipeIdsInText } from "@/lib/chat-recipes";
import { WhereToBuy } from "./where-to-buy";
import {
  DiscoverPage,
  RecipeLab,
  CreatorStudio,
  CookingMode,
  PublicSharePage,
  MyBreakfast,
  TrialPage,
  CampaignPage,
  GrowthEntry,
} from "./growth";
import {
  PersonalAIEntry,
  SavedMethodList,
  ChatRecordContext,
  NutritionReferences,
  ChatAdjustmentCard,
} from "./personal-ai";
import {
  FactoryFeature,
  FactoryPage,
  MorningPath,
  GuidePage,
} from "./experience";

const nav = [
  { href: "/", label: "Home", icon: HouseIcon },
  { href: "/recipes", label: "Recipes", icon: BookOpenIcon },
  { href: "/shop", label: "Shop", icon: ShoppingBagIcon },
  { href: "/you", label: "You", icon: UserIcon },
];
const money = (v: number) =>
  new Intl.NumberFormat("en-CN", {
    style: "currency",
    currency: "CNY",
    maximumFractionDigits: 0,
  }).format(v);
function run(action: Promise<unknown>, notify: (v: string) => void) {
  action.catch((e) => notify(e.message));
}
function Brand() {
  return (
    <Link className="brand" href="/" aria-label="VERIVA home">
      <span className="brand-symbol">
        <LeafIcon weight="fill" size={22} />
      </span>
      veriva<span className="brand-dot">.</span>
    </Link>
  );
}
function Header() {
  const path = usePathname(),
    { data, setAuthOpen } = useStore();
  const n = data.state.cart.reduce((a, b) => a + b.quantity, 0);
  return (
    <>
      <header className="header">
        <div className="header-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Main navigation">
            {nav.slice(0, 3).map((n) => (
              <Link
                key={n.href}
                href={n.href}
                className={cn(
                  "nav-link",
                  (n.href === "/" ? path === "/" : path.startsWith(n.href)) &&
                    "active",
                )}
              >
                {n.label}
              </Link>
            ))}
            <Link className={cn("nav-link", ["/expert", "/planner", "/chat"].includes(path) && "active")} href="/expert">AI Expert</Link>
          </nav>
          <div className="header-actions">
            <Link
              href="/health"
              className="guide-header-link"
              aria-label="Health records"
            >
              <HeartIcon size={19} />
              <span>Health</span>
            </Link>
<span className="header-note">
              <SunIcon size={18} /> A better kind of morning
            </span>
            {isProductPage(path) && (
              <Link
                href="/cart"
                className="icon-button cart-icon basket-prominent"
                aria-label={`Basket, ${n} items`}
              >
                <ShoppingBagIcon size={22} /><span>Basket</span><b>{n}</b>
              </Link>
            )}
            {data.user.guest ? (
              <button
                className="avatar"
                aria-label="Sign in"
                onClick={() => setAuthOpen(true)}
              >
                <UserIcon size={20} />
              </button>
            ) : (
              <Link className="avatar" href="/you" aria-label="Your profile">
                {data.state.profile.name.charAt(0).toUpperCase()}
              </Link>
            )}
          </div>
        </div>
      </header>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {nav.map((n) => (
          <Link
            key={n.href}
            className={cn(
              (n.href === "/"
                ? path === "/"
                : path.startsWith(n.href) ||
                  (n.href === "/you" &&
                    ["/profile", "/health", "/orders"].some((p) =>
                      path.startsWith(p),
                    ))) && "active",
            )}
            href={n.href}
          >
            <n.icon
              size={23}
              weight={
                (n.href === "/" ? path === "/" : path.startsWith(n.href))
                  ? "fill"
                  : "regular"
              }
            />
            <span>{n.label}</span>
          </Link>
        ))}
      </nav>
    </>
  );
}
function Footer() {
  return (
    <footer className="footer">
      <Brand />
      <span>Small rituals. Better mornings.</span>
      <div>
        <Link href="/expert">
          AI Expert <SparkleIcon size={14} />
        </Link>
        <Link href="/factory">
          The factory <ArrowUpRightIcon size={14} />
        </Link>
        <span>Student concept · Not an official Verival store</span>
        <Link href="/recipes#breakfast-table">The breakfast table</Link>
        <Link href="/about">
          About this prototype <ArrowUpRightIcon size={14} />
        </Link>
      </div>
    </footer>
  );
}
function Auth() {
  const { authOpen, setAuthOpen, refresh, notify } = useStore();
  const [mode, setMode] = useState<"login" | "register">("register"),
    [pending, setPending] = useState(false),
    [error, setError] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError("");
    const f = new FormData(e.currentTarget);
    try {
      await api("/api/auth", {
        action: mode,
        name: mode === "register" ? f.get("name") : undefined,
        email: f.get("email"),
        password: f.get("password"),
      });
      await refresh();
      setAuthOpen(false);
      notify(
        mode === "register"
          ? "Your account is ready. Your morning preferences are saved."
          : "Welcome back.",
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  return (
    <Modal
      open={authOpen}
      onOpenChange={setAuthOpen}
      title={
        mode === "register"
          ? "Make mornings yours."
          : "A familiar kind of morning."
      }
      description="Save your recipes and preferences with a local account."
    >
      <form className="form-stack" onSubmit={submit}>
        {mode === "register" ? (
          <label>
            Your name
            <input
              name="name"
              autoComplete="given-name"
              maxLength={40}
              required
              placeholder="What should we call you?"
            />
          </label>
        ) : null}
        <label>
          Email
          <input
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@example.com"
          />
        </label>
        <label>
          Password
          <input
            name="password"
            type="password"
            autoComplete={
              mode === "register" ? "new-password" : "current-password"
            }
            required
            minLength={8}
            maxLength={128}
            placeholder="At least 8 characters"
          />
        </label>
        {error ? (
          <p role="alert" className="error-text">
            {error}
          </p>
        ) : null}
        <Button disabled={pending}>
          {pending
            ? "One moment…"
            : mode === "register"
              ? "Create account"
              : "Sign in"}
          <ArrowRightIcon size={18} />
        </Button>
        <button
          type="button"
          className="text-button"
          onClick={() => {
            setMode(mode === "register" ? "login" : "register");
            setError("");
          }}
        >
          {mode === "register"
            ? "Already have an account? Sign in"
            : "New here? Create an account"}
        </button>
        <p className="small-note">
          This prototype runs on this server. Email verification and password
          recovery are not connected.
        </p>
      </form>
    </Modal>
  );
}
function SaveButton({
  recipeId,
  className,
}: {
  recipeId: string;
  className?: string;
}) {
  const { data, mutate, notify, busy } = useStore();
  const saved = data.state.favorites.includes(recipeId);
  return (
    <button
      className={cn("save-button", saved && "saved", className)}
      aria-label={saved ? "Remove from saved recipes" : "Save recipe"}
      aria-pressed={saved}
      disabled={busy}
      onClick={() => run(mutate({ action: "favorite", recipeId }), notify)}
    >
      <HeartIcon size={21} weight={saved ? "fill" : "regular"} />
    </button>
  );
}
function RecipeCard({ recipe, index = 0 }: { recipe: Recipe; index?: number }) {
  return (
    <article
      className="recipe-card"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="recipe-image" style={{ background: recipe.color }}>
        <Link href={"/recipes/" + recipe.id}>
          <CookingPhoto
            recipeId={recipe.id}
            panel={2}
            alt={`${recipe.name} serving suggestion`}
          />
        </Link>
        <SaveButton recipeId={recipe.id} />
        <span className="image-label">{recipe.tags[0]}</span>
      </div>
      <div className="recipe-card-info">
        <div className="recipe-meta">
          <span>
            <ClockIcon size={14} />
            {recipe.minutes} min
          </span>
          <span>{recipe.calories} kcal</span>
        </div>
        <h3>
          <Link href={"/recipes/" + recipe.id}>{recipe.name}</Link>
        </h3>
        <p>{recipe.subtitle}</p>
      </div>
    </article>
  );
}
function AIUpdateNotice() {
  const { data, refresh, notify } = useStore();
  const [pending, setPending] = useState(false);
  const update = data.state.aiUpdate;
  if (!update || update.status === "updated") return null;
  return (
    <aside className="ai-update-notice" role="status">
      <div>
        <strong>Your records are saved. The AI update is not complete.</strong>
        <p>{update.message}</p>
      </div>
      <Button
        variant="secondary"
        size="small"
        disabled={pending}
        onClick={async () => {
          setPending(true);
          try {
            await api("/api/recommend", {
              action:
                update.trigger === "feedback" ? "retry-feedback" : "recommend",
            });
            await refresh();
            notify("AI personalisation is updated.");
          } catch (e) {
            notify((e as Error).message);
            await refresh();
          } finally {
            setPending(false);
          }
        }}
      >
        {pending ? "Updating…" : "Retry AI update"}
      </Button>
    </aside>
  );
}
function RecipeLibrary() {
  const { data } = useStore();
  const [query, setQuery] = useState(""),
    [category, setCategory] = useState("All"),
    [saved, setSaved] = useState(false),
    [fit, setFit] = useState(false);
  const eligible = new Set(
    rankRecipes(data.state.profile, data.state.feedback).map(
      (r) => r.recipe.id,
    ),
  );
  const filtered = recipes.filter(
    (r) =>
      (category === "All" || r.category === category) &&
      (!saved || data.state.favorites.includes(r.id)) &&
      (!fit || eligible.has(r.id)) &&
      (
        r.name +
        " " +
        r.subtitle +
        " " +
        r.ingredients.map((i) => i.name).join(" ")
      )
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <main className="main">
      <div className="page-title">
        <span className="date-label">GOOD FOOD, GOOD POSSIBILITIES</span>
        <h1>Find your next favourite.</h1>
        <p>
          Simple recipes, a little inspiration, and a place to share your
          morning.
        </p>
      </div>
      <AIUpdateNotice />
      <RecipePersonalPick />
      <RecipeCollectionEntry />
      <div className="module-links recipe-secondary-links">
        <Link href="/ideas">Video inspiration →</Link>
        <Link href="/recipes#breakfast-table">
          Explore recipe conversations →
        </Link>
        <Link href="/shop">Buy packaged pantry products →</Link>
      </div>
      <div className="library-toolbar">
        <label className="search-field">
          <MagnifyingGlassIcon size={21} />
          <span className="sr-only">Search recipes</span>
          <input
            placeholder="Search oats, berries, something savoury…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {query ? (
            <button aria-label="Clear search" onClick={() => setQuery("")}>
              <XIcon size={17} />
            </button>
          ) : null}
        </label>
        <button
          className={cn("filter-button", saved && "selected")}
          onClick={() => setSaved(!saved)}
          aria-pressed={saved}
        >
          <HeartIcon weight={saved ? "fill" : "regular"} size={19} />
          Saved ({data.state.favorites.length})
        </button>
        <button
          className={cn("filter-button", fit && "selected")}
          onClick={() => setFit(!fit)}
          aria-pressed={fit}
        >
          <SlidersHorizontalIcon size={18} />
          Fits my preferences
        </button>
      </div>
      <div className="category-row" role="group" aria-label="Recipe categories">
        {["All", "Warm bowls", "Overnight oats", "No-cook"].map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={cn("chip", category === c && "selected")}
          >
            {c}
          </button>
        ))}
        <span>{filtered.length} little possibilities</span>
      </div>
      <div className="recipe-grid">
        {filtered.map((r, i) => (
          <RecipeCard key={r.id} recipe={r} index={i} />
        ))}
      </div>
      {!filtered.length ? (
        <div className="empty-state">
          <MagnifyingGlassIcon size={36} />
          <h2>A fresh search?</h2>
          <p>Try another ingredient, or clear a filter to see more recipes.</p>
          <Button
            variant="secondary"
            onClick={() => {
              setQuery("");
              setCategory("All");
              setSaved(false);
              setFit(false);
            }}
          >
            Clear filters
          </Button>
        </div>
      ) : null}
      <p className="nutrition-note">
        Nutrition values are estimates for one serving. Check ingredient labels
        for your dietary needs.
      </p>
      <RecipeCommunity />
    </main>
  );
}
function FeedbackDialog({
  recipe,
  open,
  setOpen,
}: {
  recipe: Recipe;
  open: boolean;
  setOpen: (v: boolean) => void;
}) {
  const { data, mutate, notify, busy, refresh } = useStore();
  const hasRevision = (data.state.revisions || []).some(
    (r) => r.recipeId === recipe.id && isRevisionCurrent(r, data.state),
  );
  const [done, setDone] = useState(false),
    [retrying, setRetrying] = useState(false);
  useEffect(() => {
    if (open) {
      setDone(false);
      setError("");
    }
  }, [open]);
  const [rating, setRating] = useState(5),
    [tags, setTags] = useState<string[]>([]),
    [note, setNote] = useState(""),
    [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    try {
      const saved = await mutate({
        action: "feedback",
        recipeId: recipe.id,
        rating,
        tags,
        note,
      });
      if (saved.aiUpdate?.status === "updated") {
        setDone(true);
        notify("Feedback saved. Your AI breakfast update is ready.");
      } else {
        setError(
          "Your feedback is saved. " +
            (saved.aiUpdate?.message || "The AI update needs another try."),
        );
      }
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <Modal
      open={open}
      onOpenChange={setOpen}
      title="How was your morning?"
      description={`A little feedback on ${recipe.name.toLowerCase()}.`}
    >
      <form onSubmit={submit} className="form-stack">
        <div
          className="rating-stars"
          role="group"
          aria-label="Rate your breakfast"
        >
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              type="button"
              key={n}
              aria-label={`${n} star${n > 1 ? "s" : ""}`}
              aria-pressed={rating === n}
              onClick={() => setRating(n)}
            >
              <StarIcon size={34} weight={n <= rating ? "fill" : "regular"} />
            </button>
          ))}
        </div>
        <div className="tag-options">
          {[
            "Just right",
            "Too sweet",
            "Too bland",
            "Too thin",
            "More protein",
            "Love the crunch",
            "Too thick",
          ].map((t) => (
            <button
              key={t}
              type="button"
              className={cn("chip", tags.includes(t) && "selected")}
              aria-pressed={tags.includes(t)}
              onClick={() =>
                setTags(
                  tags.includes(t)
                    ? tags.filter((x) => x !== t)
                    : [
                        ...tags.filter(
                          (x) =>
                            !(
                              (t === "Too thick" && x === "Too thin") ||
                              (t === "Too thin" && x === "Too thick")
                            ),
                        ),
                        t,
                      ],
                )
              }
            >
              {tags.includes(t) ? (
                <CheckIcon size={15} />
              ) : (
                <PlusIcon size={15} />
              )}{" "}
              {t}
            </button>
          ))}
        </div>
        <label>
          Anything else? <span className="optional">Optional</span>
          <textarea
            maxLength={500}
            rows={3}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="A little less honey next time…"
          />
        </label>
        <p className="small-note">
          Submitting calls DeepSeek immediately to revise ingredient amounts,
          texture or preparation, and choose your next breakfast. Notes can be
          in Chinese or English.
        </p>
        {error ? (
          <p className="error-text" role="alert">
            {error}
          </p>
        ) : null}
        {done ? (
          <div className="ai-revision" role="status">
            <SparkleIcon size={22} />
            <h3>
              {hasRevision
                ? "Your AI adjustment is ready."
                : "A suitable alternative is ready."}
            </h3>
            <p>
              {hasRevision
                ? "Ingredient amounts and preparation have been updated below the recipe. Your next breakfast pick is updated too."
                : "This recipe conflicts with your current preferences. AI chose an eligible alternative on your home page."}
            </p>
            <Button type="button" onClick={() => setOpen(false)}>
              {hasRevision
                ? "See my revised recipe"
                : "Close & review preferences"}
              <ArrowRightIcon size={17} />
            </Button>
          </div>
        ) : (
          <>
            <Button disabled={busy}>
              {busy ? "Saving and adjusting with AI…" : "Save & adjust with AI"}
              <SparkleIcon size={17} />
            </Button>
            {error ? (
              <Button
                type="button"
                variant="secondary"
                disabled={retrying || busy}
                onClick={async () => {
                  setRetrying(true);
                  try {
                    await api("/api/recommend", { action: "retry-feedback" });
                    await refresh();
                    setError("");
                    setDone(true);
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setRetrying(false);
                  }
                }}
              >
                {retrying ? "Adjusting…" : "Retry AI adjustment"}
              </Button>
            ) : null}
          </>
        )}
      </form>
    </Modal>
  );
}
function RecipeDetail({ id }: { id: string }) {
  const { data, mutate, notify, busy, refresh, setAuthOpen } = useStore();
  const [feedback, setFeedback] = useState(false),
    [checked, setChecked] = useState<string[]>([]),
    [post, setPost] = useState(""),
    [postError, setPostError] = useState("");
  const recipe = recipes.find((r) => r.id === id);
  if (!recipe) return <Missing />;
  const revision = (data.state.revisions || []).find(
    (r) => r.recipeId === id && isRevisionCurrent(r, data.state),
  );
  const adjusted = adjustedIngredients(recipe, data.state.feedback, revision);
  const preparation = revision ? revisionSteps(recipe, revision) : recipe.steps;
  const match = rankRecipes(data.state.profile, data.state.feedback).find(
    (r) => r.recipe.id === id,
  );
  return (
    <main className="main detail-page">
      <Link className="back-link" href="/recipes">
        <ArrowLeftIcon size={17} />
        All recipes
      </Link>
      <div className="detail-top">
        <div className="detail-photo" style={{ background: recipe.color }}>
          <CookingPhoto
            recipeId={id}
            panel={2}
            alt={`${recipeMethods[id].name} serving suggestion`}
          />
          <span className="image-label">{recipe.category}</span>
        </div>
        <div className="detail-intro">
          <div className="detail-title-line">
            <span className="date-label">A LITTLE MORNING INSPIRATION</span>
            <SaveButton recipeId={id} />
          </div>
          <h1>
            {recipe.name}
            <span>.</span>
          </h1>
          <p className="detail-subtitle">{recipe.subtitle}</p>
          <div className="detail-tags">
            <span>
              <ClockIcon size={17} />
              {recipe.minutes} min active prep
            </span>
            <span>
              <UserIcon size={16} />1 serving
            </span>
          </div>
          <div className="nutrition-grid">
            {[
              [recipe.calories, "kcal"],
              [recipe.protein + " g", "protein"],
              [recipe.fiber + " g", "fibre"],
              [recipe.sugar + " g", "total sugar"],
            ].map(([v, l]) => (
              <div key={l}>
                <strong>{v}</strong>
                <span>{l}</span>
              </div>
            ))}
          </div>
          <p className="small-note">
            Estimated nutrition · Actual values depend on ingredients and
            portions.
          </p>
          {match ? (
            <div className="match-note">
              <SparkleIcon size={20} />
              <div>
                <strong>A fit for your morning</strong>
                <p>{match.reasons.slice(0, 2).join(" · ")}</p>
              </div>
            </div>
          ) : (
            <div className="warning-note">
              <WarningCircleIcon size={20} />
              <p>
                This recipe doesn’t fit your current time or dietary
                preferences. <Link href="/profile">Review preferences</Link>
              </p>
            </div>
          )}
          <Button asChild>
            <Link href={"/chat?recipe=" + id}>
              Make this recipe yours <SparkleIcon size={18} />
            </Link>
          </Button>
        </div>
      </div>
      <div className="detail-body">
        <section>
          {revision ? (
            <div className="ai-revision">
              <SparkleIcon size={23} />
              <h3>Revised by your breakfast AI.</h3>
              <p>{revision.summary}</p>
              <ul>
                {adjusted.map((ingredient, i) =>
                  ingredient.amount !== recipe.ingredients[i].amount ? (
                    <li key={ingredient.name}>
                      {ingredient.name}:{" "}
                      <del>{recipe.ingredients[i].amount}</del> →{" "}
                      <strong>{ingredient.amount}</strong>
                    </li>
                  ) : null,
                )}
              </ul>
              <small>
                Saved {new Date(revision.createdAt).toLocaleString("en")} ·
                DeepSeek
              </small>
            </div>
          ) : null}
          <AIUpdateNotice />
          <div className="section-header compact">
            <h2>What goes in.</h2>
            <span>
              {checked.length}/{adjusted.length} ready
            </span>
          </div>
          <ul className="ingredient-list">
            {adjusted.map((i) => (
              <li key={i.name}>
                <button
                  className={cn(
                    "ingredient-check",
                    checked.includes(i.name) && "checked",
                  )}
                  aria-pressed={checked.includes(i.name)}
                  onClick={() =>
                    setChecked(
                      checked.includes(i.name)
                        ? checked.filter((x) => x !== i.name)
                        : [...checked, i.name],
                    )
                  }
                >
                  <span>
                    {checked.includes(i.name) ? <CheckIcon size={13} /> : null}
                  </span>
                  {i.name}
                </button>
                <strong>{i.amount}</strong>
              </li>
            ))}
          </ul>
          {!revision &&
          adjusted.some((i) => i.honey && i.amount === "3.5 g") ? (
            <p className="adjustment">
              <CheckIcon size={16} />A local sweetness adjustment is shown. The
              saved AI revision below takes priority when available.
            </p>
          ) : null}
          <Link className="subtle-link" href={`/shop?recipe=${encodeURIComponent(id)}#shopping-list`}>
            Explore the pantry ingredients <ArrowRightIcon size={18} />
          </Link>
          <p>
            <Link className="subtle-link" href={`/shop?recipe=${encodeURIComponent(id)}#shopping-list`}>
              Find ingredients nearby & online →
            </Link>
          </p>
          <p className="small-note">
            Fresh fruit, dairy and other ingredients are not included in the
            pantry shop.
          </p>
        </section>
        <section>
          <h2>A little inspiration for your bowl.</h2>
          <CookingPhoto
            recipeId={id}
            panel={2}
            alt={`${recipeMethods[id].name} finished bowl`}
            className="cooking-result"
          />
          <p>{recipeMethods[id].waiting}</p>
          <Link className="subtle-link" href="#method">
            See the illustrated method ↓
          </Link>
          <div className="feedback-invite">
            <div>
              <HeartIcon size={23} />
              <h3>Make tomorrow even better.</h3>
              <p>Your taste matters. Tell us how it went.</p>
            </div>
            <Button variant="secondary" onClick={() => setFeedback(true)}>
              Leave feedback <ArrowRightIcon size={17} />
            </Button>
          </div>
        </section>
      </div>
      <CookingGuide
        key={id + (revision?.id || "base")}
        recipe={recipe}
        revisionInstructions={revision ? preparation : []}
      />
      <GrowthEntry recipeId={id} />
      <div className="module-links"><Link href={`/shop?recipe=${encodeURIComponent(id)}#shopping-list`}>Find ingredients & nearby shops →</Link><Link href={`/chat?recipe=${encodeURIComponent(id)}`}>Ask Oatie about this recipe →</Link></div>
      <RecipeCommunity recipeId={id} />
<FeedbackDialog recipe={recipe} open={feedback} setOpen={setFeedback} />
    </main>
  );
}

function ProfileForm() {
  const { data, mutate, notify, busy } = useStore();
  const router = useRouter();
  const [profile, setProfile] = useState<Profile>(data.state.profile),
    [step, setStep] = useState(1),
    [error, setError] = useState("");
  useEffect(() => setProfile(data.state.profile), [data.state.profile]);
  function toggleGoal(g: Goal) {
    setProfile((p) => ({
      ...p,
      goals: p.goals.includes(g)
        ? p.goals.filter((x) => x !== g)
        : [...p.goals, g],
    }));
  }
  async function save() {
    if (!profile.name.trim() || !profile.goals.length) {
      setError("Add your name and choose at least one goal.");
      setStep(1);
      return;
    }
    try {
      const saved = await mutate({
        action: "profile",
        profile: { ...profile, onboarded: true },
      });
      notify(
        saved.aiUpdate?.status === "updated"
          ? "Profile saved. AI updated your breakfast using your latest records."
          : "Profile saved. The AI update needs a retry on your home page.",
      );
      router.push("/");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <main className="main onboarding">
      <Link href="/you" className="back-link">
        <ArrowLeftIcon size={17} />
        Your profile
      </Link>
      <div className="onboarding-layout">
        <aside>
          <span className="date-label">A MOMENT FOR YOU</span>
          <h1>
            Good mornings
            <br />
            start with you.
          </h1>
          <p>
            No perfect routine needed. Just a few things that help us find your
            kind of breakfast.
          </p>
          <div className="onboarding-steps">
            {["Your morning", "Your preferences", "Your pace"].map((t, i) => (
              <button
                key={t}
                onClick={() => setStep(i + 1)}
                className={cn(step === i + 1 && "active")}
              >
                <span>{step > i + 1 ? <CheckIcon size={15} /> : i + 1}</span>
                {t}
              </button>
            ))}
          </div>
          <span className="privacy-note">
            <ShieldCheckIcon size={19} />
            Saving profiles or feedback updates AI recommendations. Health
            records are sent to DeepSeek only when you enable their AI use.
          </span>
        </aside>
        <section className="onboarding-form">
          <div className="progress-bar">
            <span style={{ width: `${(step / 3) * 100}%` }} />
          </div>
          <span className="date-label">STEP {step} OF 3</span>
          {step === 1 ? (
            <>
              <h2>What does a good morning feel like?</h2>
              <label>
                Your name
                <input
                  value={profile.name === "Friend" ? "" : profile.name}
                  maxLength={40}
                  onChange={(e) =>
                    setProfile({ ...profile, name: e.target.value })
                  }
                  placeholder="Your first name"
                  autoComplete="given-name"
                />
              </label>
              <label>
                What matters to you?
                <span className="helper">Choose one or more.</span>
              </label>
              <div className="choice-grid">
                {[
                  {
                    id: "energy",
                    label: "Steady energy",
                    description: "Feel satisfied through your morning.",
                    icon: LightningIcon,
                  },
                  {
                    id: "protein",
                    label: "More protein",
                    description: "A little extra fuel for your day.",
                    icon: BarbellIcon,
                  },
                  {
                    id: "less-sugar",
                    label: "Less added sugar",
                    description: "Let the ingredients do the talking.",
                    icon: DropIcon,
                  },
                ].map((g) => (
                  <button
                    key={g.id}
                    className={cn(
                      "choice",
                      profile.goals.includes(g.id as Goal) && "selected",
                    )}
                    aria-pressed={profile.goals.includes(g.id as Goal)}
                    onClick={() => toggleGoal(g.id as Goal)}
                  >
                    <g.icon size={24} />
                    <strong>{g.label}</strong>
                    <span>{g.description}</span>
                    <span className="choice-check">
                      {profile.goals.includes(g.id as Goal) ? (
                        <CheckIcon size={14} />
                      ) : null}
                    </span>
                  </button>
                ))}
              </div>
            </>
          ) : step === 2 ? (
            <>
              <h2>Anything we should leave out?</h2>
              <p className="muted">
                We’ll filter recipes around your choices. You can change these
                anytime.
              </p>
              <div className="diet-options">
                {Object.entries(dietNames).map(([id, label]) => (
                  <button
                    key={id}
                    className={cn(
                      "diet-choice",
                      profile.diet.includes(id) && "selected",
                    )}
                    aria-pressed={profile.diet.includes(id)}
                    onClick={() =>
                      setProfile({
                        ...profile,
                        diet: profile.diet.includes(id)
                          ? profile.diet.filter((x) => x !== id)
                          : [...profile.diet, id],
                      })
                    }
                  >
                    <PlantIcon size={21} />
                    {label}
                    <span>
                      {profile.diet.includes(id) ? (
                        <CheckIcon size={18} />
                      ) : (
                        <PlusIcon size={18} />
                      )}
                    </span>
                  </button>
                ))}
              </div>
              <p className="small-note">
                For allergies or coeliac disease, check actual product labels
                and cross-contact information. Recipe filters are ingredient
                guidance, not a safety certification.
              </p>
            </>
          ) : (
            <>
              <h2>A breakfast that fits your day.</h2>
              <label>How much active prep time do you have?</label>
              <div className="segment-options">
                {[5, 10, 15].map((n) => (
                  <button
                    key={n}
                    className={cn(profile.minutes === n && "selected")}
                    onClick={() => setProfile({ ...profile, minutes: n })}
                  >
                    {n} minutes
                  </button>
                ))}
              </div>
              <label>Your usual activity level</label>
              <div className="activity-options">
                {[
                  ["light", "Easy pace", "Mostly sitting or light movement"],
                  [
                    "moderate",
                    "A little of both",
                    "Regular walks and a few workouts",
                  ],
                  [
                    "active",
                    "Always moving",
                    "Frequent training or an active day",
                  ],
                ].map(([id, label, desc]) => (
                  <button
                    key={id}
                    className={cn(profile.activity === id && "selected")}
                    onClick={() =>
                      setProfile({
                        ...profile,
                        activity: id as Profile["activity"],
                      })
                    }
                  >
                    <span>
                      <strong>{label}</strong>
                      <small>{desc}</small>
                    </span>
                    {profile.activity === id ? <CheckIcon size={20} /> : null}
                  </button>
                ))}
              </div>
              <HealthFields
                value={{ ...defaultHealth(), ...profile.health }}
                onChange={(health) => setProfile({ ...profile, health })}
              />
            </>
          )}
          {error ? (
            <p role="alert" className="error-text">
              {error}
            </p>
          ) : null}
          <div className="onboarding-buttons">
            {step > 1 ? (
              <Button variant="ghost" onClick={() => setStep(step - 1)}>
                <ArrowLeftIcon size={17} />
                Back
              </Button>
            ) : null}
            <Button
              disabled={busy}
              onClick={() => {
                if (step < 3) {
                  if (
                    step === 1 &&
                    (!profile.name.trim() ||
                      profile.name === "Friend" ||
                      !profile.goals.length)
                  ) {
                    setError("Tell us your name and choose at least one goal.");
                    return;
                  }
                  setError("");
                  setStep(step + 1);
                } else save();
              }}
            >
              {busy
                ? "Saving & personalising with AI…"
                : step === 3
                  ? "Find my breakfast"
                  : "Continue"}
              <ArrowRightIcon size={18} />
            </Button>
          </div>
        </section>
      </div>
    </main>
  );
}
function You() {
  const { data, setAuthOpen, refresh, notify } = useStore();
  const s = data.state;
  async function logout() {
    await api("/api/auth", { action: "logout" });
    await refresh();
    notify("Signed out. You’re now browsing as a new guest.");
  }
  return (
    <main className="main">
      <div className="page-title">
        <span className="date-label">YOUR OWN LITTLE CORNER</span>
        <h1>Your mornings, together.</h1>
        <p>A few favourites. A little progress. All yours.</p>
      </div>
      <HealthEntry />
      <PersonalAIEntry />
      <p>
        <Link className="subtle-link" href="/workspace">
          Memories, personal recipes & your weekly plan →
        </Link>
      </p>
      <div className="module-links">
        <Link href="/my-breakfast">My versions & cooking history →</Link>
        <Link href="/trials">Three ways to try →</Link>
        <Link href="/campaign">Campaign view →</Link>
        <Link href="/orders">Orders & delivery →</Link>
        <Link href="/recipes#breakfast-table">Community conversations →</Link>
      </div>
      <div className="profile-layout">
        <aside className="profile-card">
          <span className="profile-avatar">
            {s.profile.name === "Friend" ? (
              <UserIcon size={38} />
            ) : (
              s.profile.name.charAt(0).toUpperCase()
            )}
          </span>
          <h2>
            {s.profile.name === "Friend"
              ? "Hello, breakfast person."
              : s.profile.name}
          </h2>
          <span className="status-pill">
            {data.user.guest ? "Browsing as a guest" : "Your local account"}
          </span>
          <p>
            {data.user.guest
              ? "Create an account to keep access to your mornings after signing out."
              : data.user.email}
          </p>
          <Button variant="secondary" asChild>
            <Link href="/profile">
              Edit breakfast preferences
              <ArrowUpRightIcon size={17} />
            </Link>
          </Button>
          {data.user.guest ? (
            <Button onClick={() => setAuthOpen(true)}>
              Create account
              <ArrowRightIcon size={17} />
            </Button>
          ) : (
            <button
              onClick={() => run(logout(), notify)}
              className="text-button"
            >
              <SignOutIcon size={17} />
              Sign out
            </button>
          )}
        </aside>
        <div className="profile-content">
          <section>
            <h2>Your recipes & AI adjustments</h2>
            <SavedMethodList />
          </section>
          <section className="your-preferences">
            <h2>Your kind of breakfast.</h2>
            <div className="tag-options">
              {s.profile.goals.map((g) => (
                <span className="chip selected" key={g}>
                  <CheckIcon size={15} />
                  {goalNames[g]}
                </span>
              ))}
              {s.profile.diet.map((d) => (
                <span className="chip" key={d}>
                  {dietNames[d]}
                </span>
              ))}
              <span className="chip">
                <ClockIcon size={15} />
                {s.profile.minutes} min prep
              </span>
            </div>
            <div className="profile-stats">
              <div>
                <strong>{s.favorites.length}</strong>
                <span>Saved recipes</span>
              </div>
              <div>
                <strong>{s.feedback.length}</strong>
                <span>Breakfast reflections</span>
              </div>
              <div>
                <strong>
                  {
                    new Set(s.feedback.map((f) => f.createdAt.slice(0, 10)))
                      .size
                  }
                </strong>
                <span>Mornings logged</span>
              </div>
            </div>
          </section>
          <section>
            <div className="section-header">
              <h2>Worth waking up for.</h2>
              <Link href="/recipes" className="subtle-link">
                Find more <ArrowRightIcon size={17} />
              </Link>
            </div>
            {s.favorites.length ? (
              <div className="saved-grid">
                {recipes
                  .filter((r) => s.favorites.includes(r.id))
                  .map((r) => (
                    <RecipeCard key={r.id} recipe={r} />
                  ))}
              </div>
            ) : (
              <div className="empty-saved">
                <img
                  src="/images/overnight.webp"
                  alt="Apple and cinnamon breakfast inspiration"
                  width={200}
                  height={160}
                  loading="lazy"
                />
                <HeartIcon size={27} />
                <p>
                  See something you love? Tap the heart on any recipe to keep it
                  here.
                </p>
                <Link href="/recipes" className="subtle-link">
                  Discover recipes
                  <ArrowRightIcon size={17} />
                </Link>
              </div>
            )}
          </section>
          <section>
            <h2>Your health records.</h2>
            <p className="small-note">
              Self-reported records, editable in breakfast preferences. AI use
              is opt-in.
            </p>
            {s.profile.health ? (
              <div className="health-summary">
                <span>Age: {s.profile.health.age ?? "Not set"}</span>
                <span>
                  Height:{" "}
                  {s.profile.health.heightCm
                    ? `${s.profile.health.heightCm} cm`
                    : "Not set"}
                </span>
                <span>
                  Weight:{" "}
                  {s.profile.health.weightKg
                    ? `${s.profile.health.weightKg} kg`
                    : "Not set"}
                </span>
                <p>
                  {s.profile.health.notes ||
                    "No health or breakfast notes added."}
                </p>
                <strong>
                  {s.profile.health.useForAI
                    ? "Included in your AI context"
                    : "Kept local; excluded from AI requests"}
                </strong>
              </div>
            ) : null}
            {(s.healthHistory || []).length ? (
              <details>
                <summary>Record history ({s.healthHistory!.length})</summary>
                {s.healthHistory!.slice(0, 5).map((r, i) => (
                  <div className="health-history" key={i}>
                    <time>{new Date(r.recordedAt).toLocaleString("en")}</time>
                    <p>
                      {r.record.weightKg ?? "—"} kg · {r.record.heightCm ?? "—"}{" "}
                      cm · Age {r.record.age ?? "—"}
                    </p>
                    <p>{r.record.notes}</p>
                  </div>
                ))}
              </details>
            ) : null}
            <Link className="subtle-link" href="/health">
              Edit health records
              <ArrowUpRightIcon size={16} />
            </Link>
          </section>
          <section>
            <h2>What we’re learning.</h2>
            {s.feedback.length ? (
              <div className="feedback-history">
                {s.feedback.slice(0, 5).map((f) => (
                  <div key={f.id}>
                    <span className="history-icon">
                      <HeartIcon size={18} />
                    </span>
                    <div>
                      <strong>
                        {recipes.find((r) => r.id === f.recipeId)?.name}
                      </strong>
                      <p>
                        {f.tags.join(" · ") ||
                          "Thanks for reflecting on your breakfast."}
                      </p>
                      {f.note ? <p>{f.note}</p> : null}
                    </div>
                    <span>{f.rating}/5</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="muted">
                Your taste is the best guide. Leave feedback after a recipe to
                help shape your next recommendation.
              </p>
            )}
          </section>
          {s.orders.length ? (
            <section>
              <h2>Your demo orders.</h2>
              <div className="order-list">
                {s.orders.map((o) => (
                  <Link href={`/orders/${o.id}`} key={o.id}>
                    <div>
                      <strong>{o.id}</strong>
                      <small>
                        {new Date(o.createdAt).toLocaleDateString("en")} ·{" "}
                        {o.status}
                      </small>
                    </div>
                    <strong>{money(o.total)}</strong>
                  </Link>
                ))}
              </div>
            </section>
          ) : null}
        </div>
      </div>
    </main>
  );
}

function Shop() {
  const { data, mutate, notify, busy } = useStore();
  const params = useSearchParams();
  const shopping = shopContext({product:params.get("product"),recipe:params.get("recipe")},data.state);
  const featured = products.find(p=>p.id===shopping.productIds[0]) || products.find(p=>p.id==="oats")!;
  const [category, setCategory] = useState("All");
  return (
    <main className="main">
      <div className="shop-banner">
        <div>
          <span className="date-label">THE BREAKFAST PANTRY</span>
          <h1>
            Good things
            <br />
            start here.
          </h1>
          <p>
            A few thoughtful essentials.
            <br />
            So your next breakfast is one step closer.
          </p>
          <Link href="/cart" className="subtle-link">
            Your basket
            <ArrowRightIcon size={18} />
          </Link>
        </div>
        <img
          src={featured.image}
          alt={`Single illustrative package of ${featured.name}`}
          width={800}
          height={800}
        />
      </div>
      <ShoppingContext key={shopping.key} context={shopping} />
      <div className="shop-notice">
        <PackageIcon size={19} />
        <span>
          Prototype pantry · Illustrative products and prices in CNY · No real
          purchases
        </span>
      </div>
      <div className="category-row">
        {["All", "Porridge", "Oats", "Muesli", "Pantry"].map((c) => (
          <button
            key={c}
            className={cn("chip", c === category && "selected")}
            onClick={() => setCategory(c)}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="module-links">
        <span>Shop packaged pantry products below.</span>
        <Link href="/recipes">
          Looking for ingredients & cooking steps? Browse recipes →
        </Link>
      </div>
      <div className="product-grid">
        {products
          .filter((p) => category === "All" || p.category === category)
          .map((p) => (
            <article key={p.id} id={p.id} className="product-card">
              <Link href={`/products/${p.id}`} className="product-image" aria-label={`View ${p.name} details`}>
                <img
                  src={p.image}
                  alt={p.name + " — illustrative imagery"}
                  width={700}
                  height={700}
                />
                <span>{p.weight}</span>
              </Link>
              <div className="product-body">
                <span className="date-label">{p.type}</span>
                <h2><Link href={`/products/${p.id}`}>{p.name}</Link></h2>
                <p>{p.description}</p>
                <div>
                  <strong>{money(p.price)}</strong>
                  <Button
                    size="small"
                    variant="secondary"
                    disabled={busy}
                    onClick={() =>
                      run(
                        mutate({
                          action: "cart",
                          productId: p.id,
                          quantity: Math.min(
                            20,
                            (data.state.cart.find((i) => i.productId === p.id)
                              ?.quantity || 0) + 1,
                          ),
                        }).then(() =>
                          notify("A little goodness added to your basket."),
                        ),
                        notify,
                      )
                    }
                  >
                    Add to basket
                    <PlusIcon size={17} />
                  </Button>
                </div>
              </div>
            </article>
          ))}
      </div>
      <WhereToBuy key={shopping.key} productIds={shopping.productIds} ingredients={shopping.ingredients.map(i=>i.name)} />
      <div className="shop-bottom">
        <LeafIcon size={27} />
        <div>
          <h3>Curious about where breakfast begins?</h3>
          <p>
            Explore Verival’s Austrian roots and approach to organic breakfast.
          </p>
        </div>
        <Link href="/story" className="subtle-link">
          Our story
          <ArrowRightIcon size={18} />
        </Link>
      </div>
    </main>
  );
}
function Cart() {
  const { data, mutate, notify, busy } = useStore();
  const [orderId, setOrderId] = useState("");
  const cart = data.state.cart,
    total = cartTotal(cart);
  async function checkout() {
    try {
      const s = await mutate({ action: "order" });
      setOrderId(s.orders[0].id);
    } catch (e) {
      notify((e as Error).message);
    }
  }
  return (
    <main className="main cart-page">
      <Link className="back-link" href="/shop">
        <ArrowLeftIcon size={17} />
        Back to the pantry
      </Link>
      <div className="page-title">
        <h1>A little basket of good.</h1>
        <p>Your next morning is taking shape.</p>
      </div>
      <Link className="subtle-link" href="/orders">
        Your orders & delivery <ArrowRightIcon size={17} />
      </Link>
      {orderId ? (
        <div className="order-success">
          <span>
            <CheckIcon size={34} />
          </span>
          <h2>A practice run, beautifully done.</h2>
          <p>
            Demo order <strong>{orderId}</strong> is saved in your profile.
          </p>
          <p>No payment was taken. No products will be shipped.</p>
          <Button asChild>
            <Link href={`/orders/${orderId}`}>
              View order & delivery
              <ArrowRightIcon size={17} />
            </Link>
          </Button>
        </div>
      ) : !cart.length ? (
        <div className="empty-state">
          <ShoppingBagIcon size={40} />
          <h2>Room for something good.</h2>
          <p>
            Your basket is empty. Find a few essentials for your next breakfast.
          </p>
          <Button asChild>
            <Link href="/shop">
              Explore the pantry
              <ArrowRightIcon size={17} />
            </Link>
          </Button>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-items">
            {cart.map((i) => {
              const p = products.find((p) => p.id === i.productId)!;
              return (
                <article className="cart-item" key={i.productId}>
                  <img src={p.image} alt={p.name} width={150} height={150} />
                  <div>
                    <span className="date-label">{p.weight}</span>
                    <h2><Link href={`/products/${p.id}`}>{p.name}</Link></h2>
                    <span>{money(p.price)} each</span>
                    <div className="quantity">
                      <button
                        disabled={busy}
                        aria-label={`Remove one ${p.name}`}
                        onClick={() =>
                          run(
                            mutate({
                              action: "cart",
                              productId: p.id,
                              quantity: i.quantity - 1,
                            }),
                            notify,
                          )
                        }
                      >
                        <MinusIcon size={15} />
                      </button>
                      <span>{i.quantity}</span>
                      <button
                        disabled={busy || i.quantity >= 20}
                        aria-label={`Add one ${p.name}`}
                        onClick={() =>
                          run(
                            mutate({
                              action: "cart",
                              productId: p.id,
                              quantity: i.quantity + 1,
                            }),
                            notify,
                          )
                        }
                      >
                        <PlusIcon size={15} />
                      </button>
                    </div>
                  </div>
                  <strong>{money(p.price * i.quantity)}</strong>
                </article>
              );
            })}
          </div>
          <aside className="cart-summary">
            <h2>Your morning essentials.</h2>
            <div>
              <span>Items subtotal</span>
              <span>{money(total)}</span>
            </div>
            <div>
              <span>Shipping</span>
              <span>Demo only</span>
            </div>
            <div className="cart-total">
              <strong>Total</strong>
              <strong>{money(total)}</strong>
            </div>
            <p className="demo-note">
              <ShieldCheckIcon size={20} />
              This is a simulated checkout. No payment details or delivery
              address are collected.
            </p>
            <Button disabled={busy} onClick={checkout}>
              {busy ? "Saving order…" : "Place demo order"}
              <ArrowRightIcon size={17} />
            </Button>
          </aside>
        </div>
      )}
    </main>
  );
}
function Chat() {
  const { data, ready, refresh, mutate, notify } = useStore();
  const params = useSearchParams();
  const [recipeId, setRecipeId] = useState(params.get("recipe") || "");
  const recipe = recipes.find((r) => r.id === recipeId);
  const restoredContext = useRef(false);
  useEffect(() => {
    if (!ready || restoredContext.current) return;
    restoredContext.current = true;
    if (recipeId || !data.state.messages.length) return;
    const previous = [...data.state.messages]
      .reverse()
      .find((m) => m.recipeId || m.proposal?.recipeId);
    if (previous)
      setRecipeId(previous.recipeId || previous.proposal?.recipeId || "");
  }, [ready, recipeId, data.state.messages]);
  useEffect(() => {
    const requested = params.get("recipe");
    if (requested) setRecipeId(requested);
  }, [params]);
  const [input, setInput] = useState((params.get("prompt")||"").slice(0,1000)),
    [sending, setSending] = useState(false),
    [error, setError] = useState(""),
    [optimistic, setOptimistic] = useState<Message | null>(null);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollToLatest(end.current);
  }, [data.state.messages.length, sending]);
  async function send(text: string) {
    if (!text.trim() || sending) return;
    setInput("");
    setError("");
    setSending(true);
    setOptimistic({ role: "user", content: text });
    try {
      const reply = await api("/api/chat", { message: text, recipeId });
      if (reply.recipeId !== undefined) setRecipeId(reply.recipeId || "");
      await refresh();
      if (reply.savedRecipeId) notify("Saved to My recipes.");
    } catch (e) {
      setError((e as Error).message);
      setInput(text);
    } finally {
      setSending(false);
      setOptimistic(null);
    }
  }
  const prompts = recipe
    ? [
        "How can I make this less sweet?",
        "Can you suggest a dairy-free swap?",
        "Help me prep this ahead.",
      ]
    : [
        "What can I make in 5 minutes?",
        "How do I prepare muesli?",
        "A breakfast with more protein, please.",
      ];
  return (
    <main className="main chat-page">
      <aside className="chat-sidebar">
        <Link className="back-link" href="/">
          <ArrowLeftIcon size={17} />
          Back to your morning
        </Link>
        <img className="chat-oatie" src="/images/oatie-assistant-v1.webp" alt="Oatie, your breakfast companion" width={120} height={120} />
        <Link className="subtle-link" href="/expert">Today’s recommendation →</Link>
        <h1>
          A little help
          <br />
          for your morning.
        </h1>
        <p>
          Your breakfast expert, here for the little questions and the fresh
          ideas.
        </p>
        <div className="chat-context">
          <HealthEntry />
          <ChatRecordContext />
          <NutritionReferences />
          <ChatCapabilities />
          <span className="date-label">THOUGHTFULLY AWARE OF</span>
          <div>
            {data.state.profile.goals.map((g) => (
              <span key={g}>
                <CheckIcon size={15} />
                {goalNames[g]}
              </span>
            ))}
            {data.state.profile.diet.map((d) => (
              <span key={d}>
                <CheckIcon size={15} />
                {dietNames[d]}
              </span>
            ))}
            <span>
              <ClockIcon size={15} />
              {data.state.profile.minutes}-minute mornings
            </span>
          </div>
          <Link href="/profile">
            Edit preferences
            <ArrowUpRightIcon size={15} />
          </Link>
        </div>
        <p className="small-note">
          Your profile, recent feedback and conversation are sent to DeepSeek
          when you ask a question. This is general food guidance, not medical
          advice.
        </p>
        <Link href="/recipes" className="chat-inspiration">
          <img
            src="/images/chia.webp"
            alt="Berry and chia breakfast inspiration"
            width={1000}
            height={1000}
            loading="lazy"
          />
          <span>
            <strong>A fresh place to start.</strong>
            <small>
              Find a bowl to talk about <ArrowUpRightIcon size={14} />
            </small>
          </span>
        </Link>
      </aside>
      <section className="chat-window">
        <div className="chat-recipe-context">
          <div className="chat-context-mobile">
            <ChatRecordContext />
            <ChatCapabilities />
          </div>
          <label htmlFor="conversation-recipe">
            The recipe we are talking about
            <select
              id="conversation-recipe"
              value={recipeId}
              disabled={sending}
              onChange={(e) => setRecipeId(e.target.value)}
            >
              <option value="">General breakfast questions</option>
              {recipes.map((r) => (
                <option key={r.id} value={r.id}>
                  {recipeMethods[r.id].name}
                </option>
              ))}
            </select>
          </label>
          {recipe && (
            <Link href={`/recipes/${recipe.id}#method`}>
              See the current method →
            </Link>
          )}
          <p>
            Your current records and saved adjustments stay in context. A
            suggestion changes the recipe only after you save it.
          </p>
        </div>
        <div className="chat-header">
          <span className="assistant-avatar">
            <SparkleIcon size={20} />
          </span>
          <div>
            <strong>Breakfast expert</strong>
            <span>
              {data.aiConfigured ? "Powered by DeepSeek" : "AI setup needed"}
            </span>
          </div>
          <button
            className="icon-button"
            aria-label="Clear conversation"
            onClick={() => {
              if (
                window.confirm(
                  "Clear this conversation? This cannot be undone.",
                )
              )
                run(mutate({ action: "clear-chat" }), notify);
            }}
          >
            <ArrowCounterClockwiseIcon size={20} />
          </button>
        </div>
        {recipe ? (
          <div className="chat-recipe">
            <img src={recipe.image} alt="" width={48} height={48} />
            <div>
              <small>Let’s talk about</small>
              <strong>{recipe.name}</strong>
            </div>
            <Link href={"/recipes/" + recipe.id} aria-label="Return to recipe">
              <ArrowUpRightIcon size={20} />
            </Link>
          </div>
        ) : null}
        <div className="chat-messages" aria-live="polite">
          {!data.state.messages.length ? (
            <div className="chat-welcome">
              <span>
                <PlantIcon size={39} weight="thin" />
              </span>
              <h2>
                What’s on your mind
                <br />
                this morning?
              </h2>
              <p>
                A new recipe, a simple swap,
                <br />
                or a little inspiration. Start here.
              </p>
              <div>
                {prompts.map((p) => (
                  <button key={p} onClick={() => send(p)}>
                    {p}
                    <ArrowUpRightIcon size={16} />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            data.state.messages.map((m, i) => (
              <div className={cn("chat-message", m.role)} key={i}>
                {m.role === "assistant" ? (
                  <span className="message-mark">
                    <SparkleIcon size={18} />
                  </span>
                ) : null}
                <div>
                  <small>{m.role === "assistant" ? "VERIVA" : "You"}</small>
                  <div className="message-text">
                    {m.content.split("\n").map((line, j) => (
                      <p key={j}>
                        {line
                          .replace(/^#{1,4}\s/, "")
                          .split(/(\*\*.*?\*\*)/g)
                          .map((t, k) =>
                            t.startsWith("**") ? (
                              <strong key={k}>{t.slice(2, -2)}</strong>
                            ) : (
                              t
                            ),
                          )}
                      </p>
                    ))}
                  </div>
                  {m.role === "assistant" && m.proposal ? (
                    <ChatAdjustmentCard proposal={m.proposal} />
                  ) : null}
                  {m.role === "assistant" &&
                  (m.recipeCards?.length ||
                    recipeIdsInText(m.content).length) ? (
                    <ChatRecipeCards
                      ids={m.recipeCards || recipeIdsInText(m.content)}
                      onDiscuss={setRecipeId}
                    />
                  ) : null}
                  {m.role === "assistant" && m.assistantProposalId ? (
                    <AssistantProposalCard id={m.assistantProposalId} />
                  ) : null}
                  {m.role === "assistant" && m.personalRecipeId ? (
                    <Link href={"/my-recipes/" + m.personalRecipeId}>
                      View your personal recipe →
                    </Link>
                  ) : null}
                  {m.role === "assistant" && m.assistantResult ? (
                    <Link href="/my-recipes">View saved recipe →</Link>
                  ) : null}
                </div>
              </div>
            ))
          )}
          {optimistic ? (
            <div className="chat-message user">
              <div>
                <small>You</small>
                <p>{optimistic.content}</p>
              </div>
            </div>
          ) : null}
          {sending ? (
            <div className="chat-loading">
              <SparkleIcon size={18} />
              <span>
                Thinking about your morning
                <span className="loading-dots">…</span>
              </span>
            </div>
          ) : null}
          {error ? (
            <p className="chat-error" role="alert">
              <WarningCircleIcon size={19} />
              {error}
            </p>
          ) : null}
          <div ref={end} />
        </div>
        <form
          className="chat-input"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <label className="sr-only" htmlFor="chat-message">
            Your breakfast question
          </label>
          <textarea
            id="chat-message"
            rows={1}
            value={input}
            maxLength={2000}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (
                e.key === "Enter" &&
                !e.shiftKey &&
                !e.nativeEvent.isComposing
              ) {
                e.preventDefault();
                send(input);
              }
            }}
            placeholder="Ask a little breakfast question…"
          />
          <button aria-label="Send message" disabled={sending || !input.trim()}>
            <ArrowRightIcon size={22} />
          </button>
        </form>
        <span className="chat-footnote">
          AI can make mistakes. Always check ingredients that matter to you.
        </span>
      </section>
    </main>
  );
}

function Story() {
  return (
    <main className="main story-page">
      <Link href="/" className="back-link">
        <ArrowLeftIcon size={17} />
        Back home
      </Link>
      <section className="story-hero">
        <div>
          <span className="date-label">FROM AUSTRIA, WITH CARE</span>
          <h1>
            Every good morning
            <br />
            begins somewhere.
          </h1>
          <p>
            For Verival, it starts in Tyrol. With organic ingredients, a love of
            breakfast, and the belief that simple things can make a difference.
          </p>
          <a
            className="subtle-link"
            href="https://www.verival.at/en/pages/ueber-uns"
            target="_blank"
            rel="noreferrer"
          >
            Visit Verival’s official story
            <ArrowUpRightIcon size={18} />
          </a>
        </div>
        <div className="story-photo">
          <img
            src="/images/overnight.webp"
            alt="Apple and cinnamon overnight oats, a breakfast inspiration"
            width={1000}
            height={1000}
          />
          <span>Breakfast inspiration · AI-created photograph</span>
        </div>
      </section>
      <section className="story-values">
        <div>
          <GlobeHemisphereWestIcon size={29} />
          <h2>Rooted in Tyrol.</h2>
          <p>
            Verival was founded in 1993 and makes its organic breakfast products
            in Langkampfen, Austria.
          </p>
        </div>
        <div>
          <LeafIcon size={29} />
          <h2>Ingredients first.</h2>
          <p>
            The brand focuses on organic porridge, muesli and granola. Explore
            the official product pages for ingredient lists and certifications.
          </p>
        </div>
        <div>
          <SunIcon size={29} />
          <h2>A ritual to share.</h2>
          <p>
            VERIVA explores how this breakfast culture can become more
            approachable, personal and easy to enjoy in China.
          </p>
        </div>
      </section>
      <section className="transparency-note">
        <ShieldCheckIcon size={30} />
        <div>
          <h2>Trust begins with the source.</h2>
          <p>
            We link to Verival’s own information. This prototype does not
            display live factory readings, batch audit results, a virtual
            factory tour or verified local stock.
          </p>
          <a
            className="subtle-link"
            href="https://www.verival.at/en/pages/ueber-uns"
            target="_blank"
            rel="noreferrer"
          >
            Read the source
            <ArrowUpRightIcon size={17} />
          </a>
        </div>
      </section>
    </main>
  );
}
function About() {
  return (
    <main className="main about-page">
      <Link href="/" className="back-link">
        <ArrowLeftIcon size={17} />
        Home
      </Link>
      <h1>A thoughtful prototype.</h1>
      <p>
        VERIVA is a student project for ENT207TC Digital Startup Lab. It
        explores a personalised breakfast experience inspired by Verival and the
        team’s Ningbo Autfine client brief. It is not an official brand
        application or an operational retail store.
      </p>
      <h2>What works here</h2>
      <p>
        Local account registration and password login, stored preferences,
        ingredient-based recipe filtering, AI recipe picks, DeepSeek chat, saved
        recipes, feedback-based adjustments, community notes, a persistent
        basket and simulated orders.
      </p>
      <h2>Your data</h2>
      <p>
        Account and application data are saved in a SQLite database on this
        server. Passwords are hashed; session cookies are HttpOnly. AI
        interactions send your question, profile, eligible recipes and recent
        feedback to DeepSeek. Do not enter medical records or sensitive
        information into this prototype.
      </p>
      <h2>What is illustrative</h2>
      <p>
        Recipe nutrition is estimated. Pantry products, imagery and prices
        illustrate the flow. There is no real payment, delivery, WeChat login,
        email verification, password recovery or verified factory telemetry.
      </p>
      <h2>Food imagery</h2>
      <p>
        Breakfast and pantry photographs were created with AI for this
        prototype. They are not evidence of real products or production
        facilities.
      </p>
      <h2>Built for learning</h2>
      <p>
        The final handoff includes source code, database setup, configuration
        instructions and a record of checks. Real user testing must be carried
        out with actual participants.
      </p>
    </main>
  );
}
function Missing() {
  return (
    <main className="main empty-state">
      <PlantIcon size={45} />
      <h1>A little off the breakfast path.</h1>
      <p>That page or recipe is not here.</p>
      <Button asChild>
        <Link href="/">
          Back to your morning
          <ArrowRightIcon size={17} />
        </Link>
      </Button>
    </main>
  );
}
function AppContent() {
  const path = usePathname(),
    creatorParams = useSearchParams(),
    { toast, error } = useStore();
  useEffect(() => {
    const target = window.location.hash
      ? document.getElementById(window.location.hash.slice(1))
      : null;
    if (target) target.scrollIntoView({ behavior: "instant", block: "start" });
    else window.scrollTo({ top: 0, behavior: "instant" });
  }, [path]);
  let page;
  if (path === "/") page = <ProductHome />;
  else if (path.startsWith("/products/"))
    page = <ProductDetail id={path.split("/")[2]} />;
  else if (path === "/discover") page = <RecipeLibrary />;
  else if (path === "/ideas") page = <IdeasPage />;
  else if (path === "/creations") page = <MyCreations />;
  else if (path === "/shoot") page = <CreatorProjectPage shoot />;
  else if (path === "/studio")
    page = creatorParams.get("project") ? (
      <CreatorProjectPage />
    ) : (
      <CreatorStudio />
    );
  else if (path === "/lab") page = <RecipeLab />;
  else if (path === "/cook") page = <CookingMode />;
  else if (path === "/my-breakfast") page = <MyBreakfast />;
  else if (path === "/trials") page = <TrialPage />;
  else if (path === "/campaign") page = <CampaignPage />;
  else if (path.startsWith("/share/"))
    page = <PublicSharePage id={path.split("/")[2]} />;
  else if (path === "/recipes") page = <RecipeLibrary />;
  else if (path === "/planner" || path === "/expert") page = <ExpertPage />;
  else if (path === "/workspace") page = <Planner />;
  else if (path === "/my-recipes") page = <MyRecipesPage />;
  else if (path.startsWith("/my-recipes/"))
    page = <PersonalRecipePage id={path.split("/")[2]} />;
  else if (path.startsWith("/recipes/"))
    page = <RecipeDetail key={path} id={path.split("/")[2]} />;
  else if (path === "/profile") page = <ProfileForm />;
  else if (path === "/health") page = <HealthPage />;
  else if (path === "/community") page = <RecipeLibrary />;
  else if (path === "/orders") page = <OrdersPage />;
  else if (path.startsWith("/orders/"))
    page = <OrdersPage id={path.split("/")[2]} />;
  else if (path === "/you") page = <You />;
  else if (path === "/shop") page = <Shop />;
  else if (path === "/cart") page = <Cart />;
  else if (path === "/chat") page = <Chat />;
  else if (path === "/story") page = <Story />;
  else if (path === "/factory") page = <FactoryPage />;
  else if (path === "/guide") page = <Missing />;
  else if (path === "/about") page = <About />;
  else if (path === "/admin") return <AdminPage />;
  else page = <Missing />;
  return (
    <>
      <a className="skip-link" href="#content">
        Skip to content
      </a>
      <VisitTracker />
      <Header />
      <div id="content">
        {error ? (
          <div className="global-error" role="alert">
            {error} · Refresh to reconnect.
          </div>
        ) : null}
        {page}
      </div>
      {path !== "/chat" ? <Footer /> : null}
      <Auth />
      <FloatingBasket />
      <FloatingExpert />
      <AnimatedNotice text={toast} />
    </>
  );
}
export function VerivaApp() {
  return (
    <Suspense
      fallback={
        <div className="initial-loading">A little goodness is on its way…</div>
      }
    >
      <AppContent />
    </Suspense>
  );
}
