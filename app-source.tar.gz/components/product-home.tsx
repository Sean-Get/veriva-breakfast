"use client";
import Link from "next/link";
import { useState } from "react";
import {
  ArrowRightIcon,
  ArrowLeftIcon,
  BookOpenIcon,
  ShoppingBagIcon,
} from "@phosphor-icons/react";
import { products, recipes } from "@/lib/catalog";
import { productStories } from "@/lib/product-stories";
import { rankRecipes, preferenceKey } from "@/lib/recommendation";
import { useStore, api } from "./store";
import { Button } from "./ui";
import { FactoryFeature } from "./experience";
import { PersonalAIEntry } from "./personal-ai";
import { CookingPhoto } from "./recipe-cooking";
import { Reveal, PhotoLightbox } from "./motion";
import { ProductReviews } from "./product-reviews";
import { IdeaHome } from "./creator-ideas";
import { PastoralHomeHero } from "./pastoral";
export function ProductHome() {
  return (
    <main className="main quiet-home">
      <PastoralHomeHero />
      <div className="quiet-intro">
        <span>GOOD THINGS, SIMPLY MADE</span>
        <h2>Something to look forward to.</h2>
        <p>
          Familiar grains, fresh ideas and a few small rituals.
          <br />A collection for whatever your morning brings.
        </p>
      </div>

      <IdeaHome />
      <section className="quiet-collection" aria-label="Breakfast collection">
        {products.slice(0, 5).map((product) => {
          const story = productStories[product.id];
          return (
            <Reveal key={product.id}>
              <article className="quiet-product">
                <Link href={`/products/${product.id}`} className="quiet-food">
                  <img
                    src={story.photo}
                    alt={`${product.name} breakfast inspiration`}
                    width={900}
                    height={800}
                    loading="lazy"
                  />
                </Link>
                <div className="quiet-product-copy">
                  <span>{story.note}</span>
                  <h2>
                    <Link href={`/products/${product.id}`}>
                      {story.headline}
                    </Link>
                  </h2>
                  <h3>{product.name}</h3>
                  <p>{story.detail}</p>
                  <Link
                    href={`/products/${product.id}`}
                    className="quiet-discover"
                  >
                    Discover this breakfast <ArrowRightIcon size={17} />
                  </Link>
                </div>
              </article>
            </Reveal>
          );
        })}
      </section>
      <Reveal>
        <section className="quiet-recipe-invite">
          <img
            src="/images/berry-serving-reference.webp"
            alt="A freshly finished bowl of berry oats"
            width={827}
            height={1094}
            loading="lazy"
          />
          <div>
            <span>FROM YOUR KITCHEN</span>
            <h2>A bowl of possibilities.</h2>
            <p>
              A few ingredients, a little guidance, and something lovely at the
              end. Find a recipe, or see what others are making.
            </p>
            <Link href="/recipes" className="quiet-discover">
              Recipes & breakfast stories <ArrowRightIcon size={17} />
            </Link>
          </div>
        </section>
      </Reveal>
      <PersonalAIEntry />
      <FactoryFeature />
    </main>
  );
}
export function ProductDetail({ id }: { id: string }) {
  const { data, mutate, notify, busy } = useStore();
  const product = products.find((p) => p.id === id),
    story = productStories[id];
  if (!product || !story)
    return (
      <main className="main empty-state">
        <h1>Breakfast not found.</h1>
        <Link href="/">Return home</Link>
      </main>
    );
  return (
    <main className="main product-detail">
      <Link className="back-link" href="/">
        <ArrowLeftIcon size={17} />
        The breakfast collection
      </Link>
      <div className="product-detail-hero">
        <PhotoLightbox
          src={product.image}
          alt={`${product.name} single concept package`}
          className="product-pack-image"
        />
        <div>
          <span className="date-label">YOUR PANTRY COLLECTION</span>
          <h1>{product.name}</h1>
          <p className="product-detail-lead">{story.headline}</p>
          <p>{story.detail}</p>
          <dl className="product-key-facts">
            <div>
              <dt>Pack</dt>
              <dd>{product.weight}</dd>
            </div>
            <div>
              <dt>Type</dt>
              <dd>{product.category}</dd>
            </div>
            <div>
              <dt>Demo price</dt>
              <dd>CN¥{product.price}</dd>
            </div>
          </dl>
          <Button
            disabled={busy}
            onClick={async () => {
              try {
                await mutate({
                  action: "cart",
                  productId: id,
                  quantity: Math.min(
                    20,
                    (data.state.cart.find((i) => i.productId === id)
                      ?.quantity || 0) + 1,
                  ),
                });
                notify("Added to your basket.");
              } catch (e) {
                notify((e as Error).message);
              }
            }}
          >
            Add to basket · CN¥{product.price}
          </Button>
          <div className="product-detail-choices">
            <Button asChild variant="secondary">
              <Link href={`/shop?product=${encodeURIComponent(id)}#find-buy`}>
                Map & buying options
              </Link>
            </Button>
            <Button asChild variant="secondary">
              <Link href={`/recipes/${story.recipeId}#method`}>
                <BookOpenIcon size={18} />
                Find a way to make it
              </Link>
            </Button>
            <Button asChild>
              <Link href={`/shop#${product.id}`}>
                <ShoppingBagIcon size={18} />
                See it in the shop
              </Link>
            </Button>
          </div>
          <p className="small-note">
            Preparation ideas use separate base recipes. Check the actual pack
            for ingredients and allergen information.
          </p>
        </div>
      </div>
      <section className="product-pack-story product-pack-summary">
        <div>
          <h2>Meet your cupboard companion.</h2>
          <p>{product.description}</p>
          <p className="small-note">
            Student concept · Illustrative packaging and photography. Prices and
            demo purchasing are shown in the shop.
          </p>
          <Link className="quiet-discover" href="/recipes">
            More breakfast ideas <ArrowRightIcon size={17} />
          </Link>
        </div>
      </section>
      <section className="growth-entry">
        <h3>One pantry staple. More than one morning.</h3>
        <p>
          Explore three recipe ideas, confirm what you already have, and
          estimate portions from your actual pack.
        </p>
        <Link href="/trials">Explore Three Ways to Try →</Link>
      </section>
      <ProductReviews key={id} productId={id} />
    </main>
  );
}
export function RecipePersonalPick() {
  const { data, refresh, notify } = useStore();
  const [pending, setPending] = useState(false);
  const ranked = rankRecipes(data.state.profile, data.state.feedback);
  const pick =
    data.state.aiPick?.context ===
    preferenceKey(data.state.profile, data.state.feedback)
      ? data.state.aiPick
      : null;
  const recipe =
    recipes.find((r) => r.id === pick?.recipeId) || ranked[0]?.recipe;
  async function choose() {
    setPending(true);
    try {
      await api("/api/recommend", { action: "recommend" });
      await refresh();
    } catch (e) {
      notify((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  return (
    <section className="recipe-personal-pick">
      {recipe && (
        <Link href={`/recipes/${recipe.id}#method`}>
          <CookingPhoto
            recipeId={recipe.id}
            panel={2}
            alt={`${recipe.name} serving suggestion`}
          />
        </Link>
      )}
      <div>
        <span>
          {pick ? "YOUR SAVED AI PICK" : "MATCHED TO YOUR PREFERENCES"}
        </span>
        <h2>{recipe?.name || "Let's find a better fit."}</h2>
        <p>
          {pick?.rationale ||
            "Your dietary choices and available time come first. Ask AI for a fresh idea whenever you like."}
        </p>
        <div>
          {recipe && (
            <Link className="subtle-link" href={`/recipes/${recipe.id}#method`}>
              See the recipe <ArrowRightIcon size={16} />
            </Link>
          )}
          <Button
            variant="secondary"
            size="small"
            disabled={pending}
            onClick={choose}
          >
            {pending ? "Choosing thoughtfully…" : "Ask AI for a fresh pick"}
          </Button>
        </div>
      </div>
    </section>
  );
}
