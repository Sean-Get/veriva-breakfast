"use client";
import { samplePortraits, sampleBreakfastPhotos } from "@/lib/community-media";
import { PhotoLightbox } from "./motion";
export function CommunityAvatar({
  name,
  sample = false,
}: {
  name: string;
  sample?: boolean;
}) {
  const portrait = sample ? samplePortraits[name] : undefined;
  const hue =
    (Array.from(name).reduce((sum, letter) => sum + letter.charCodeAt(0), 0) %
      80) +
    65;
  return (
    <span
      className="story-avatar"
      style={{ background: `hsl(${hue} 24% 87%)` }}
      aria-hidden="true"
    >
      {name.trim().slice(0, 1).toUpperCase() || "V"}
      {portrait && (
        <img
          src={portrait}
          alt=""
          width={80}
          height={80}
          loading="lazy"
          onError={(event) => {
            event.currentTarget.hidden = true;
          }}
        />
      )}
    </span>
  );
}
export function CommunityBreakfastPhoto({ storyId }: { storyId: string }) {
  const photo = sampleBreakfastPhotos[storyId];
  if (!photo) return null;
  return (
    <figure className="community-breakfast-photo">
      <PhotoLightbox
        src={photo.src}
        alt={photo.alt}
        className="community-photo-open"
      >
        <img
          src={photo.src}
          alt={photo.alt}
          width={640}
          height={640}
          loading="lazy"
        />
      </PhotoLightbox>
      <figcaption>
        {photo.caption}
        <small>AI-generated illustration · Sample story</small>
      </figcaption>
    </figure>
  );
}
