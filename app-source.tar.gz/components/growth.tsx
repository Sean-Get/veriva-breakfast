"use client";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { api, useStore } from "./store";
import { Button } from "./ui";
import { WhereToBuy } from "./where-to-buy";
import { RecipeCommunity } from "./recipe-community";
import {
  conceptRecipes,
  demoCreators,
  growthState,
  resolveGrowthRecipe,
  ingredientChanges,
  trialBundles,
  trialPortions,
  trialShopping,
  makeCreatorKit,
  mealFits,
  type GrowthMeal,
  type GrowthPending,
  type Customisation,
  type CreatorKit,
  type CookingRun,
} from "@/lib/growth";
import { workspace } from "@/lib/breakfast";
import { products } from "@/lib/catalog";
import "./growth.css";

const defaults: Customisation = {
  equipment: "any",
  temperature: "any",
  sweetness: "gentle",
  texture: "creamy",
  servings: 1,
  avoid: "",
};
function url(path: string, r: GrowthMeal) {
  const q = new URLSearchParams({ recipe: r.id });
  if (r.shareId) q.set("share", r.shareId);
  return `${path}?${q}`;
}
function useGrowth() {
  const { refresh, notify, ready } = useStore();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const lock = useRef(false);
  async function run(body: Record<string, unknown>) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      const result = await api("/api/growth", body);
      await refresh();
      return result;
    } catch (e) {
      setError((e as Error).message);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return { run, busy: busy || !ready, error, notify };
}
function useMeal() {
  const params = useSearchParams(),
    { data, ready } = useStore(),
    id = params.get("recipe") || "berry-oats",
    share = params.get("share"),
    runId = params.get("run");
  const [shared, setShared] = useState<GrowthMeal | null>(null),
    [error, setError] = useState("");
  useEffect(() => {
    let live = true;
    setShared(null);
    setError("");
    if (share)
      api(`/api/growth?share=${encodeURIComponent(share)}`)
        .then((r) => {
          if (live) setShared({ ...r.meal, shareId: r.id });
        })
        .catch((e) => {
          if (live) setError(e.message);
        });
    return () => {
      live = false;
    };
  }, [share]);
  return {
    meal: runId
      ? growthState(data.state).cooking.find((c) => c.id === runId)?.meal
      : share
        ? shared
        : resolveGrowthRecipe(data.state, id),
    ready,
    error:
      ready && !share && !runId && !resolveGrowthRecipe(data.state, id)
        ? "This recipe is no longer available. Choose another breakfast."
        : error,
  };
}
function Note({ text }: { text: string }) {
  return text ? (
    <p role="alert" className="growth-error">
      {text}
    </p>
  ) : null;
}
function GrowthNav() {
  return (
    <nav className="growth-nav" aria-label="Breakfast journeys">
      <Link href="/discover">Discover & remix</Link>
      <Link href="/ideas">Video ideas</Link>
      <Link href="/creations">My creations</Link>
      <Link href="/studio">Create & share</Link>
      <Link href="/my-breakfast">My breakfast</Link>
      <Link href="/trials">Three ways to try</Link>
      <Link href="/campaign">Campaign view</Link>
    </nav>
  );
}
function Shell({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <main className="main growth-main">
      <GrowthNav />
      <div className="growth-heading">
        <span className="date-label">{eyebrow}</span>
        <h1>{title}</h1>
      </div>
      {children}
    </main>
  );
}
function MealSummary({
  meal,
  compact = false,
}: {
  meal: GrowthMeal;
  compact?: boolean;
}) {
  return (
    <article className={`growth-meal ${compact ? "compact" : ""}`}>
      <img
        src={meal.image}
        alt={`${meal.name} serving inspiration`}
        width="600"
        height="400"
      />
      <div>
        <span className="date-label">
          {meal.concept
            ? "CONCEPT KITCHEN · NOT TASTE-TESTED"
            : meal.parentId
              ? "YOUR RECIPE VARIATION"
              : "BREAKFAST INSPIRATION"}
        </span>
        <h2>{meal.name}</h2>
        <p>{meal.description}</p>
        <p className="small-note">
          {meal.activeMinutes} min active · {meal.waitingMinutes} min waiting ·{" "}
          {meal.servings} serving{meal.servings > 1 ? "s" : ""} · Inspired by{" "}
          {meal.creator}
        </p>
        <details>
          <summary>Ingredients, method & labels</summary>
          <ul>
            {meal.ingredients.map((i, n) => (
              <li key={n}>
                {i.amount} {i.unit} {i.name}
              </li>
            ))}
          </ul>
          <ol>
            {meal.steps.map((step, n) => (
              <li key={n}>{step}</li>
            ))}
          </ol>
          <p className="small-note">
            Declared catalogue allergens:{" "}
            {meal.allergens.join(", ") || "none declared"}. Check actual labels,
            including soy, sesame and cross-contact where relevant. Images are
            illustrative; nutrition is not recalculated here.
          </p>
        </details>
      </div>
    </article>
  );
}
export function GrowthEntry({ recipeId }: { recipeId: string }) {
  return (
    <section className="growth-entry">
      <span className="date-label">FROM SOMEONE'S IDEA TO YOUR OWN BOWL</span>
      <h3>A breakfast you can make your own.</h3>
      <p>
        Adapt the method, cook with measured help, or turn this idea into
        something to share.
      </p>
      <div className="growth-actions">
        <Link href={`/lab?recipe=${encodeURIComponent(recipeId)}`}>
          Make It Mine →
        </Link>
        <Link href={`/cook?recipe=${encodeURIComponent(recipeId)}`}>
          Cooking mode →
        </Link>
        <Link href={`/studio?recipe=${encodeURIComponent(recipeId)}`}>
          Create & share →
        </Link>
        <Link href={`/ideas?recipe=${encodeURIComponent(recipeId)}`}>
          Film this breakfast →
        </Link>
      </div>
    </section>
  );
}
export function GrowthHome() {
  return (
    <section className="growth-home">
      <div>
        <span className="date-label">A RECIPE IS JUST THE BEGINNING</span>
        <h2>
          Someone's inspiration.
          <br />
          Your kind of morning.
        </h2>
        <p>
          Explore a creator's idea, adapt it to your kitchen, and share what you
          discover.
        </p>
        <Link href="/discover">Find your next breakfast →</Link>
      </div>
      <div className="growth-scenarios">
        <Link href="/discover?scene=quick">
          A quick start<span>Small steps, familiar ingredients</span>
        </Link>
        <Link href="/discover?scene=warm">
          Something warm<span>Gentle cooking and comforting bowls</span>
        </Link>
        <Link href="/discover?scene=ahead">
          Tomorrow, prepared<span>Make ahead with real waiting time</span>
        </Link>
        <Link href="/discover?scene=brunch">
          A slower morning<span>Breakfast on your own schedule</span>
        </Link>
      </div>
    </section>
  );
}
export function DiscoverPage() {
  const { data } = useStore(),
    params = useSearchParams();
  const [scene, setScene] = useState(params.get("scene") || "all");
  const items = conceptRecipes.filter(
    (r) =>
      scene === "all" ||
      (scene === "quick" && r.activeMinutes <= 4) ||
      (scene === "warm" && r.waitingMinutes === 0 && !r.id.includes("mango")) ||
      (scene === "ahead" && r.waitingMinutes > 0) ||
      (scene === "brunch" &&
        ["concept-savory", "concept-apple"].includes(r.id)),
  );
  return (
    <Shell
      eyebrow="THE CREATOR RECIPE TABLE"
      title="An idea worth making your own."
    >
      <p className="growth-intro">
        Recipes for different kitchens, tastes and times of day. The concept
        kitchen explores locally familiar flavours; actual cooking and taste
        trials are still needed.
      </p>
      <div className="growth-tabs" role="group" aria-label="Breakfast scene">
        {[
          ["all", "All mornings"],
          ["quick", "Quick start"],
          ["warm", "Warm bowls"],
          ["ahead", "Prepare ahead"],
          ["brunch", "Late brunch"],
        ].map(([key, label]) => (
          <button
            key={key}
            aria-pressed={scene === key}
            onClick={() => setScene(key)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="growth-grid">
        {items.map((r) => (
          <article className="growth-card" key={r.id}>
            <img
              src={r.image}
              alt={`${r.name} serving inspiration`}
              width="500"
              height="330"
              loading="lazy"
            />
            <div>
              <span className="source-badge">CONCEPT RECIPE</span>
              <h2>{r.name}</h2>
              <p>{r.description}</p>
              <p className="small-note">
                {r.activeMinutes} min active · {r.waitingMinutes} min waiting
              </p>
              {!mealFits(r, data.state) && (
                <p className="small-note">
                  Adapt to your current dietary preferences before cooking.
                </p>
              )}
              <div className="growth-actions">
                <Link href={`/lab?recipe=${r.id}`}>Make It Mine →</Link>
                <Link href={`/studio?recipe=${r.id}`}>Create a story →</Link>
              </div>
            </div>
          </article>
        ))}
      </div>
      <section className="growth-panel">
        <span className="date-label">SAMPLE CREATORS · FICTIONAL PERSONAS</span>
        <h2>From the breakfast table.</h2>
        <div className="growth-grid three">
          {demoCreators.map((c) => (
            <article key={c.id}>
              <div className="creator-avatar">{c.name[0]}</div>
              <h3>{c.name}</h3>
              <p>{c.story}</p>
              <Link href={`/share/${c.id}`}>
                Explore this creator's recipe →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </Shell>
  );
}
function ProposalReview({
  proposal,
  busy,
  onSave,
}: {
  proposal: GrowthPending;
  busy: boolean;
  onSave: () => void;
}) {
  const changes = ingredientChanges(proposal.before, proposal.meal);
  return (
    <section className="growth-panel" aria-label="Review personalised recipe">
      <span className="date-label">
        REVIEW BEFORE SAVING · {proposal.reason}
      </span>
      <h2>{proposal.meal.name}</h2>
      <div className="growth-comparison">
        <div>
          <h3>Original</h3>
          <p>{proposal.before.name}</p>
          <p>
            {proposal.before.activeMinutes} min active ·{" "}
            {proposal.before.waitingMinutes} min waiting ·{" "}
            {proposal.before.servings} serving(s)
          </p>
        </div>
        <div>
          <h3>Your version</h3>
          <p>{proposal.meal.description}</p>
          <p>
            {proposal.meal.activeMinutes} min active ·{" "}
            {proposal.meal.waitingMinutes} min waiting ·{" "}
            {proposal.meal.servings} serving(s)
          </p>
        </div>
      </div>
      <table className="growth-table">
        <caption>Actual ingredient changes</caption>
        <thead>
          <tr>
            <th>Ingredient</th>
            <th>Original</th>
            <th>Your version</th>
          </tr>
        </thead>
        <tbody>
          {changes.length ? (
            changes.map((c, i) => (
              <tr key={i}>
                <td>{c.name}</td>
                <td>{c.from}</td>
                <td>{c.to}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={3}>
                No ingredient quantities changed. Review the preparation changes
                below.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <ol>
        {proposal.meal.steps.map((s, i) => (
          <li key={i}>{s}</li>
        ))}
      </ol>
      <Button disabled={busy} onClick={onSave}>
        {busy ? "Saving…" : "Save my version"}
      </Button>
      <p className="small-note">
        Saves a separate personal recipe with its origin. Your original stays
        available.
      </p>
    </section>
  );
}
export function RecipeLab() {
  const returnIdea=useSearchParams().get('returnIdea');
  const { meal, error: loadError } = useMeal(),
    { data } = useStore(),
    { run, busy, error } = useGrowth();
  const [choices, setChoices] = useState<Customisation>(defaults),
    [engine, setEngine] = useState("guided"),
    [proposal, setProposal] = useState<GrowthPending | null>(null),
    [saved, setSaved] = useState("");
  const set = <K extends keyof Customisation>(
    key: K,
    value: Customisation[K],
  ) => {
    setChoices((c) => ({ ...c, [key]: value }));
    setProposal(null);
    setSaved("");
  };
  useEffect(() => {
    setProposal(null);
    setSaved("");
    setChoices(defaults);
  }, [meal?.id]);
  return (
    <Shell eyebrow="MAKE IT MINE" title="Same inspiration. Your own version.">
      <Note text={loadError} />
      {meal ? (
        <>
          <MealSummary meal={meal} />
          <section className="growth-panel">
            <h2>Tell us about your kitchen.</h2>
            <fieldset className="growth-form" disabled={busy}>
              <label>
                Equipment
                <select
                  value={choices.equipment}
                  onChange={(e) =>
                    set(
                      "equipment",
                      e.target.value as Customisation["equipment"],
                    )
                  }
                >
                  <option value="any">Any equipment</option>
                  <option value="stove">Stove</option>
                  <option value="microwave">Microwave</option>
                  <option value="kettle">Kettle</option>
                  <option value="no-cook">No cooking</option>
                </select>
              </label>
              <label>
                Temperature
                <select
                  value={choices.temperature}
                  onChange={(e) =>
                    set(
                      "temperature",
                      e.target.value as Customisation["temperature"],
                    )
                  }
                >
                  <option value="any">Keep original</option>
                  <option value="warm">Warm</option>
                  <option value="cold">Cold</option>
                </select>
              </label>
              <label>
                Sweetness
                <select
                  value={choices.sweetness}
                  onChange={(e) =>
                    set(
                      "sweetness",
                      e.target.value as Customisation["sweetness"],
                    )
                  }
                >
                  <option value="gentle">Gentle sweetness</option>
                  <option value="regular">Keep original sweetness</option>
                  <option value="fruit-only">
                    Fruit only · no added sweetener
                  </option>
                </select>
              </label>
              <label>
                Texture
                <select
                  value={choices.texture}
                  onChange={(e) =>
                    set("texture", e.target.value as Customisation["texture"])
                  }
                >
                  <option value="creamy">Keep original texture</option>
                  <option value="thicker">Thicker</option>
                  <option value="looser">Looser</option>
                </select>
              </label>
              <label>
                Servings
                <select
                  value={choices.servings}
                  onChange={(e) => set("servings", Number(e.target.value))}
                >
                  {[1, 2, 3, 4].map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Avoid ingredients
                <input
                  maxLength={100}
                  value={choices.avoid}
                  onChange={(e) => set("avoid", e.target.value)}
                  placeholder="Separate names with commas; AI adaptation required"
                />
              </label>
              <label>
                Adaptation method
                <select
                  value={engine}
                  onChange={(e) => {
                    setEngine(e.target.value);
                    setProposal(null);
                  }}
                >
                  <option value="guided">
                    Guided · measured adjustments, no AI network needed
                  </option>
                  <option value="ai">
                    AI · substitutions and new preparation
                  </option>
                </select>
              </label>
            </fieldset>
            <p className="small-note">
              Your saved profile also applies:{" "}
              {data.state.profile.diet.join(", ") ||
                "no dietary exclusions selected"}{" "}
              · {data.state.profile.minutes} min active limit. Guided adaptation
              handles supported quantity/method changes; use AI for
              substitutions.
            </p>
            <p className="small-note">
              AI requests send this recipe, choices, recent cooking feedback and
              authorised profile context to DeepSeek.
            </p>
            <Button
              disabled={busy}
              onClick={async () => {
                setSaved("");
                const r = await run({
                  action: "personalise",
                  recipeId: meal.id,
                  shareId: meal.shareId,
                  constraints: choices,
                  engine,
                });
                if (r) setProposal(r.proposal);
              }}
            >
              {busy ? "Adapting your breakfast…" : "Create my version"}
            </Button>
            <Note text={error} />
          </section>
          {proposal && (
            <ProposalReview
              proposal={proposal}
              busy={busy}
              onSave={async () => {
                const r = await run({ action: "apply", id: proposal.id });
                if (r) {
                  setSaved(r.recipeId);
                  setProposal(null);
                }
              }}
            />
          )}
          {saved && (
            <section className="growth-panel" role="status">
              <h2>Your version is saved.</h2>
              <p>The recipe and its origin are in My Breakfast.</p>
              <div className="growth-actions">
                <Link href={`/cook?recipe=${saved}`}>Cook my version →</Link>
                <Link href={`/ideas?recipe=${encodeURIComponent(saved)}&idea=${encodeURIComponent(returnIdea||'make-it-mine')}`}>Film this saved version →</Link>
                <Link href={`/studio?recipe=${saved}`}>
                  Share my variation →
                </Link>
                <Link href="/my-breakfast">My breakfast →</Link>
              </div>
            </section>
          )}
          <Lineage meal={meal} />
          {meal.concept && <RecipeCommunity recipeId={meal.originId} />}
        </>
      ) : (
        !loadError && <p>Loading breakfast…</p>
      )}
    </Shell>
  );
}
function Lineage({ meal }: { meal: GrowthMeal }) {
  const { data } = useStore(),
    versions = growthState(data.state).versions.filter(
      (v) =>
        v.originId === meal.originId &&
        workspace(data.state).recipes.some((r) => r.id === v.recipeId),
    );
  return (
    <section className="growth-panel">
      <span className="date-label">RECIPE RELAY</span>
      <h2>Every variation has a beginning.</h2>
      <p>
        Original idea: {meal.originId} · {meal.originCreator || meal.creator}
      </p>
      {meal.parentId && <p>Inspired by an earlier recipe version.</p>}
      <div className="growth-lineage">
        {meal.shareId || meal.attributionShare ? (
          <Link href={`/share/${meal.shareId || meal.attributionShare}`}>
            Published source snapshot
          </Link>
        ) : resolveGrowthRecipe(data.state, meal.originId) ? (
          <Link href={`/lab?recipe=${encodeURIComponent(meal.originId)}`}>
            Original idea
          </Link>
        ) : (
          <span>Origin {meal.originId}</span>
        )}
        {versions.map((v) => (
          <Link key={v.recipeId} href={`/lab?recipe=${v.recipeId}`}>
            ↳{" "}
            {
              workspace(data.state).recipes.find((r) => r.id === v.recipeId)
                ?.name
            }
          </Link>
        ))}
      </div>
      <p className="small-note">
        Your private versions appear here. A version becomes publicly accessible
        only after you publish its food-only snapshot.
      </p>
    </section>
  );
}
async function downloadPoster(meal: GrowthMeal, shareId?: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 1000;
  canvas.height = 2200;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw Error("Image export is unavailable.");
  ctx.fillStyle = "#f6f7ee";
  ctx.fillRect(0, 0, 1000, 2200);
  const im = new Image();
  im.src = meal.image;
  await im.decode();
  ctx.save();
  ctx.beginPath();
  ctx.rect(40, 110, 920, 500);
  ctx.clip();
  const scale = Math.max(920 / im.width, 500 / im.height);
  ctx.drawImage(
    im,
    500 - (im.width * scale) / 2,
    360 - (im.height * scale) / 2,
    im.width * scale,
    im.height * scale,
  );
  ctx.restore();
  ctx.fillStyle = "#31573e";
  ctx.font = "bold 38px Arial";
  ctx.fillText("veriva.  /  Make it yours", 50, 70);
  ctx.font = "bold 47px Georgia";
  let y = 685;
  const wrap = (text: string, size: number, line: number, maxWidth = 900) => {
    ctx.font = `${size}px Arial`;
    let current = "";
    for (const word of text.split(" ")) {
      if (ctx.measureText(current + " " + word).width > maxWidth && current) {
        ctx.fillText(current, 50, y);
        y += line;
        current = word;
      } else current += (current ? " " : "") + word;
    }
    if (current) {
      ctx.fillText(current, 50, y);
      y += line;
    }
  };
  wrap(meal.name, 44, 55);
  wrap(
    `${meal.activeMinutes} min active + ${meal.waitingMinutes} min waiting · ${meal.servings} serving(s)`,
    25,
    38,
  );
  y += 15;
  wrap(
    meal.ingredients.map((i) => `${i.amount} ${i.unit} ${i.name}`).join(" / "),
    24,
    35,
  );
  y += 25;
  wrap(
    `By ${meal.creator}. Make It Mine to adapt the equipment, sweetness and texture.`,
    25,
    38,
  );
  y = Math.max(y + 20, 1160);
  wrap(
    "Serving image is illustrative. Follow the written recipe and check actual ingredient labels.",
    20,
    30,
  );
  const local = ["127.0.0.1", "localhost", "[::1]"].includes(
    window.location.hostname,
  );
  wrap(
    shareId
      ? local
        ? `Local classroom share code: ${shareId}`
        : `${window.location.origin}/share/${shareId}`
      : "Create your own version in VERIVA.",
    20,
    30,
  );
  if (local)
    wrap(
      "Local preview · public hosting is needed for cross-device sharing.",
      20,
      30,
    );
  const poster = document.createElement("canvas");
  poster.width = 1000;
  poster.height = Math.min(2200, Math.max(1400, y + 45));
  poster.getContext("2d")!.drawImage(canvas, 0, 0);
  const blob = await new Promise<Blob>((resolve, reject) =>
    poster.toBlob(
      (b) => (b ? resolve(b) : reject(Error("PNG export failed."))),
      "image/png",
    ),
  );
  const a = document.createElement("a"),
    objectUrl = URL.createObjectURL(blob);
  a.href = objectUrl;
  a.download = `VERIVA-${meal.id.slice(0, 20)}-recipe.png`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}
function downloadText(text: string) {
  const b = new Blob([text], { type: "text/plain;charset=utf-8" }),
    u = URL.createObjectURL(b),
    a = document.createElement("a");
  a.href = u;
  a.download = "VERIVA-creator-kit.txt";
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
}
export function CreatorStudio() {
  const { meal, error: loadError } = useMeal(),
    { data } = useStore(),
    { run, busy, error } = useGrowth();
  const [scene, setScene] = useState("quick breakfast"),
    [style, setStyle] = useState("tutorial"),
    [language, setLanguage] = useState<"en" | "zh">("en"),
    [kit, setKit] = useState<CreatorKit | null>(null),
    [name, setName] = useState(""),
    [reviewed, setReviewed] = useState(false),
    [share, setShare] = useState<{ id: string; meal: GrowthMeal } | null>(null),
    [exportError, setExportError] = useState("");
  const current =
    kit || (meal ? makeCreatorKit(meal, scene, style, language) : null);
  useEffect(() => {
    setKit(
      growthState(data.state).kitDrafts.find((k) => k.mealId === meal?.id)
        ?.kit || null,
    );
    setShare(null);
    setReviewed(false);
  }, [meal?.id]);
  return (
    <Shell
      eyebrow="CREATE & SHARE"
      title="A breakfast story, ready to become real."
    >
      <p className="growth-intro">
        <Link href="/ideas">Start with a video idea →</Link> ·{" "}
        <Link href="/creations">Open my creative projects →</Link>
      </p>
      <Note text={loadError} />
      {meal && current ? (
        <>
          <MealSummary meal={meal} compact />
          <section className="growth-panel">
            <h2>Your creative brief.</h2>
            <fieldset className="growth-form" disabled={busy}>
              <label>
                Scene
                <select
                  value={scene}
                  onChange={(e) => {
                    setScene(e.target.value);
                    setKit(null);
                  }}
                >
                  <option value="quick breakfast">Quick breakfast</option>
                  <option value="late brunch">Late brunch</option>
                  <option value="prepare ahead">Prepare ahead</option>
                </select>
              </label>
              <label>
                Story style
                <select
                  value={style}
                  onChange={(e) => {
                    setStyle(e.target.value);
                    setKit(null);
                  }}
                >
                  <option value="tutorial">Tutorial</option>
                  <option value="diary">Morning diary</option>
                  <option value="product experience">Product experience</option>
                </select>
              </label>
              <label>
                Content language
                <select
                  value={language}
                  onChange={(e) => {
                    setLanguage(e.target.value as "en" | "zh");
                    setKit(null);
                  }}
                >
                  <option value="en">English</option>
                  <option value="zh">Chinese caption · English recipe</option>
                </select>
              </label>
            </fieldset>
            <div className="growth-actions">
              {growthState(data.state).kitDrafts.some(
                (k) => k.mealId === meal.id,
              ) && (
                <Button
                  variant="secondary"
                  onClick={() =>
                    setKit(
                      growthState(data.state).kitDrafts.find(
                        (k) => k.mealId === meal.id,
                      )!.kit,
                    )
                  }
                >
                  Load saved content kit
                </Button>
              )}
              <Button
                disabled={busy}
                onClick={async () => {
                  const r = await run({
                    action: "kit",
                    recipeId: meal.id,
                    shareId: meal.shareId,
                    scene,
                    style,
                    language,
                  });
                  if (r) setKit(r.kit);
                }}
              >
                Save recipe-linked content kit
              </Button>
              <Button
                variant="secondary"
                disabled={busy}
                onClick={async () => {
                  const r = await run({
                    action: "kit",
                    recipeId: meal.id,
                    shareId: meal.shareId,
                    scene,
                    style,
                    language,
                    refine: true,
                  });
                  if (r) setKit(r.kit);
                }}
              >
                {busy ? "Working…" : "Refine hook & caption with AI"}
              </Button>
            </div>
            <Note text={error} />
          </section>
          <section className="growth-panel">
            <span className="date-label">{current.method}</span>
            <h2>{current.hook}</h2>
            <div className="growth-shots">
              {current.shots.map((shot, i) => (
                <article key={i}>
                  <span>{shot.frame}</span>
                  <p>{shot.action}</p>
                  <small>{shot.voiceover}</small>
                </article>
              ))}
            </div>
            <h3>Before you film</h3>
            <ul>
              {current.preparation.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
            <label>
              Editable publishing caption
              <textarea
                rows={5}
                maxLength={1800}
                value={current.caption}
                onChange={(e) =>
                  setKit({ ...current, caption: e.target.value })
                }
              />
            </label>
            <p>{current.invitation}</p>
            <div className="growth-actions">
              <Button
                disabled={busy}
                onClick={() =>
                  run({ action: "kit-save", recipeId: meal.id, kit: current })
                }
              >
                Save edited content kit
              </Button>
              <Button
                variant="secondary"
                onClick={() =>
                  downloadText(
                    [
                      current.hook,
                      ...current.shots.map(
                        (s) => `${s.frame}\n${s.action}\n${s.voiceover}`,
                      ),
                      ...current.preparation,
                      current.caption,
                      current.invitation,
                    ].join("\n\n"),
                  )
                }
              >
                Download content kit TXT
              </Button>
            </div>
          </section>
          <section className="growth-panel">
            <h2>Share the food, keep the personal details private.</h2>
            <p>
              The public card contains this recipe, ingredient quantities,
              steps, origin and your public name. It contains no health record,
              pantry, private feedback or chat.
            </p>
            <label>
              Public creator name
              <input
                maxLength={40}
                placeholder={data.state.profile.name}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </label>
            <label className="growth-check">
              <input
                type="checkbox"
                checked={reviewed}
                onChange={(e) => setReviewed(e.target.checked)}
              />
              I have reviewed the recipe above and want to publish this
              food-only snapshot.
            </label>
            <div className="growth-actions">
              <Button
                disabled={busy || !reviewed}
                onClick={async () => {
                  const r = await run({
                    action: "publish",
                    recipeId: meal.id,
                    shareId: meal.shareId,
                    creator: name.trim() || data.state.profile.name,
                  });
                  if (r) setShare(r.share);
                }}
              >
                Publish recipe card
              </Button>
              <Button
                variant="secondary"
                onClick={async () => {
                  try {
                    setExportError("");
                    await downloadPoster(
                      { ...meal, creator: name.trim() || meal.creator },
                      share?.id,
                    );
                  } catch (e) {
                    setExportError((e as Error).message);
                  }
                }}
              >
                Download recipe card PNG
              </Button>
            </div>
            <Note text={exportError} />
            {share && (
              <div className="growth-share-result" role="status">
                <h3>Your public food snapshot is ready.</h3>
                <Link href={`/share/${share.id}?preview=1`}>
                  Preview as a visitor →
                </Link>
                <p className="small-note">Share code: {share.id}</p>
                <button
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(
                        `${window.location.origin}/share/${share.id}`,
                      );
                    } catch {
                      setExportError(
                        "Clipboard is unavailable. Open the preview and copy its address.",
                      );
                    }
                  }}
                >
                  Copy share address
                </button>
                <p className="small-note">
                  On localhost this address opens only on this computer. Public
                  hosting is needed for cross-device distribution. Preview keeps
                  your account signed in but hides its private data.
                </p>
              </div>
            )}
          </section>
        </>
      ) : (
        !loadError && <p>Loading creator studio…</p>
      )}
    </Shell>
  );
}
export function CookingMode() {
  const { meal, error: loadError } = useMeal(),
    { data } = useStore(),
    { run, busy, error } = useGrowth();
  const runParam = useSearchParams().get("run");
  const [aiProposal, setAiProposal] = useState<GrowthPending | null>(null),
    [missing, setMissing] = useState("");
  const [id, setId] = useState(""),
    [currentStep, setCurrentStep] = useState(0),
    [fix, setFix] = useState<any>(null),
    [rating, setRating] = useState(4),
    [note, setNote] = useState(""),
    [saved, setSaved] = useState("");
  const g = growthState(data.state),
    session =
      g.cooking.find((c) => c.id === id) ||
      g.cooking.find((c) => c.id === runParam) ||
      g.cooking.find((c) => c.meal.id === meal?.id && !c.finishedAt);
  return (
    <Shell eyebrow="COOKING MODE" title="One step at a time.">
      <Note text={loadError} />
      {meal && (
        <>
          {!session ? (
            <>
              <MealSummary meal={meal} />
              <Button
                disabled={busy}
                onClick={async () => {
                  const r = await run({
                    action: "cook-start",
                    recipeId: meal.id,
                    shareId: meal.shareId,
                  });
                  if (r) {
                    setId(r.run.id);
                    setCurrentStep(0);
                  }
                }}
              >
                Start cooking this recipe
              </Button>
            </>
          ) : (
            <>
              <section className="growth-panel">
                <span className="date-label">{session.meal.name}</span>
                <h2>
                  {session.completed.length} of {session.meal.steps.length}{" "}
                  steps complete
                </h2>
                <progress
                  max={session.meal.steps.length}
                  value={session.completed.length}
                  aria-label="Cooking progress"
                />
                <p>
                  {session.meal.activeMinutes} min active ·{" "}
                  {session.meal.waitingMinutes} min waiting. Follow required
                  cooking and chilling time.
                </p>
                <details>
                  <summary>Current recipe quantities</summary>
                  <ul>
                    {session.meal.ingredients.map((i, n) => (
                      <li key={n}>
                        {i.amount} {i.unit} {i.name}
                      </li>
                    ))}
                  </ul>
                </details>
                <div className="growth-step-list">
                  {session.meal.steps.map((step, n) => (
                    <article
                      key={n}
                      className={currentStep === n ? "current" : ""}
                    >
                      <button
                        className="growth-step-number"
                        aria-label={`Focus cooking step ${n + 1}`}
                        aria-pressed={currentStep === n}
                        onClick={() => {
                          setCurrentStep(n);
                          setFix(null);
                        }}
                      >
                        {String(n + 1).padStart(2, "0")}
                      </button>
                      <div>
                        <p>{step}</p>
                        <label className="growth-check">
                          <input
                            type="checkbox"
                            disabled={busy || !!session.finishedAt}
                            checked={session.completed.includes(n)}
                            onChange={() =>
                              run({
                                action: "cook-step",
                                id: session.id,
                                step: n,
                              })
                            }
                          />
                          Step {n + 1} complete
                        </label>
                      </div>
                    </article>
                  ))}
                </div>
              </section>
              <section className="growth-panel">
                <h2>Help me fix this.</h2>
                <p>
                  Working on step {currentStep + 1}. Measured guidance uses the
                  current recipe; it is not visual inspection of your food.
                </p>
                <div className="growth-tabs">
                  {[
                    ["thick", "Too thick"],
                    ["watery", "Too watery"],
                    ["bland", "Too bland"],
                    ["sweet", "Too sweet"],
                    ["missing", "Missing an ingredient"],
                  ].map(([kind, label]) => (
                    <button
                      disabled={busy || !!session.finishedAt}
                      key={kind}
                      onClick={async () => {
                        const r = await run({
                          action: "rescue",
                          id: session.id,
                          kind,
                          step: currentStep,
                        });
                        if (r) {
                          setFix(r);
                          setSaved("");
                        }
                      }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {fix && (
                  <div className="growth-fix" role="status">
                    <strong>{fix.fix.method}</strong>
                    <p>{fix.fix.message}</p>
                    <div className="growth-actions">
                      {fix.proposal.temporary && !session.finishedAt && (
                        <Button
                          disabled={busy}
                          onClick={async () => {
                            const r = await run({
                              action: "rescue-now",
                              id: session.id,
                              proposalId: fix.proposal.id,
                            });
                            if (r)
                              setSaved(
                                "Temporary fix recorded for this cooking session.",
                              );
                          }}
                        >
                          Use this fix now
                        </Button>
                      )}
                      <Button
                        variant="secondary"
                        disabled={busy}
                        onClick={async () => {
                          const r = await run({
                            action: "apply",
                            id: fix.proposal.id,
                          });
                          if (r) {
                            setSaved(
                              "Saved as a separate next-batch version in My Breakfast.",
                            );
                            setFix(null);
                          }
                        }}
                      >
                        Save for next time
                      </Button>
                    </div>
                    {fix.fix.kind === "missing" && (
                      <label>
                        Missing ingredient names
                        <input
                          value={missing}
                          maxLength={100}
                          onChange={(e) => setMissing(e.target.value)}
                          placeholder="Separate names with commas"
                        />
                      </label>
                    )}
                    <Button
                      variant="secondary"
                      disabled={busy}
                      onClick={async () => {
                        const r = await run({
                          action: "rescue-ai",
                          id: session.id,
                          kind: fix.fix.kind,
                          step: currentStep,
                          missing,
                        });
                        if (r) setAiProposal(r.proposal);
                      }}
                    >
                      {busy
                        ? "Refining with AI…"
                        : "Ask AI for a next-batch revision"}
                    </Button>
                    <Link href={url("/lab", session.meal)}>
                      Make a measured substitution in Make It Mine →
                    </Link>
                  </div>
                )}
                {saved && <p role="status">{saved}</p>}
              </section>
              {aiProposal && (
                <ProposalReview
                  proposal={aiProposal}
                  busy={busy}
                  onSave={async () => {
                    const r = await run({ action: "apply", id: aiProposal.id });
                    if (r) {
                      setSaved("AI next-batch version saved in My Breakfast.");
                      setAiProposal(null);
                    }
                  }}
                />
              )}
              <section className="growth-panel">
                <h2>
                  {session.finishedAt
                    ? "Your breakfast is recorded."
                    : "How did your bowl turn out?"}
                </h2>
                {session.finishedAt ? (
                  <>
                    <p>
                      Self-reported completion · {session.rating}/5 ·{" "}
                      {session.note}
                    </p>
                    <Link href="/my-breakfast">
                      See your breakfast history →
                    </Link>
                    <Button
                      disabled={busy}
                      onClick={async () => {
                        const own = resolveGrowthRecipe(
                          data.state,
                          session.meal.id,
                        );
                        const r = await run({
                          action: "cook-start",
                          recipeId: session.meal.id,
                          shareId: own ? undefined : session.sourceShare,
                        });
                        if (r) {
                          setId(r.run.id);
                          setCurrentStep(0);
                          setFix(null);
                        }
                      }}
                    >
                      Cook another batch
                    </Button>
                  </>
                ) : (
                  <>
                    <label>
                      Your rating
                      <select
                        value={rating}
                        onChange={(e) => setRating(Number(e.target.value))}
                      >
                        {[1, 2, 3, 4, 5].map((n) => (
                          <option key={n} value={n}>
                            {n} / 5
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Private cooking note
                      <textarea
                        maxLength={300}
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="What would you change next time?"
                      />
                    </label>
                    <Button
                      disabled={
                        busy ||
                        session.completed.length !== session.meal.steps.length
                      }
                      onClick={() =>
                        run({
                          action: "cook-finish",
                          id: session.id,
                          rating,
                          note,
                        })
                      }
                    >
                      Record my finished breakfast
                    </Button>
                    <p className="small-note">
                      Complete the steps first. This records your own report,
                      not independently verified cooking.
                    </p>
                  </>
                )}
              </section>
            </>
          )}
          <Note text={error} />
        </>
      )}
    </Shell>
  );
}
export function PublicSharePage({ id }: { id: string }) {
  const { ready } = useStore(),
    params = useSearchParams();
  const [share, setShare] = useState<any>(null),
    [error, setError] = useState(""),
    [family, setFamily] = useState<any[]>([]);
  useEffect(() => {
    let active = true;
    setShare(null);
    api(`/api/growth?share=${encodeURIComponent(id)}`)
      .then((r) => {
        if (active) {
          setShare(r);
          setError("");
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      });
    return () => {
      active = false;
    };
  }, [id]);
  useEffect(() => {
    if (share && ready && !params.get("preview"))
      api("/api/growth", {
        action: "event",
        kind: "visit",
        subject: share.meal.originId,
        shareId: id,
      }).catch(() => {});
  }, [id, share, ready, params]);
  return (
    <Shell
      eyebrow={
        share?.demonstration
          ? "FICTIONAL CREATOR · CLASSROOM STORY"
          : "PUBLIC FOOD SNAPSHOT"
      }
      title={
        share ? `${share.creator}'s breakfast idea.` : "A recipe worth sharing."
      }
    >
      <Note text={error} />
      {share && (
        <>
          <MealSummary meal={{ ...share.meal, shareId: id }} />
          <section className="growth-panel">
            <h2>Make this idea fit your morning.</h2>
            <p>
              Equipment, sweetness, texture and portions can change. The
              original idea stays credited.
            </p>
            <div className="growth-actions">
              <Button asChild>
                <Link href={url("/lab", { ...share.meal, shareId: id })}>
                  Make It Mine
                </Link>
              </Button>
              <Link href={url("/cook", { ...share.meal, shareId: id })}>
                Cook the original →
              </Link>
              <Link href={url("/studio", { ...share.meal, shareId: id })}>
                Remix & share →
              </Link>
            </div>
          </section>
          <section className="growth-panel">
            <h2>Recipe relay</h2>
            <p>
              Original idea credited to{" "}
              {share.meal.originCreator || share.creator}. This is{" "}
              {share.meal.parentId
                ? "a published variation"
                : "a starting recipe"}
              .
            </p>
            <p>
              This published version is a fixed food-only snapshot. Private
              profile changes do not rewrite it.
            </p>
            <button
              onClick={async () => {
                try {
                  const r = await api(
                    `/api/growth?family=${encodeURIComponent(share.meal.originId)}`,
                  );
                  setFamily(r.shares || []);
                } catch (e) {
                  setError((e as Error).message);
                }
              }}
            >
              Explore published variations
            </button>
            <div className="growth-lineage">
              {family.map((s) => (
                <Link key={s.id} href={`/share/${s.id}`}>
                  {s.creator} · {s.meal.name}
                </Link>
              ))}
            </div>
          </section>
          <p>
            <a
              href="/shop#find-buy"
              onClick={() =>
                api("/api/growth", {
                  action: "event",
                  kind: "buy-click",
                  subject: share.meal.originId,
                  shareId: id,
                }).catch(() => {})
              }
            >
              Find ingredients & buying options →
            </a>
          </p>
          <RecipeCommunity recipeId={`share:${id}`} />
          <Link href="/shop#find-buy">Find ingredients in the shop →</Link>
        </>
      )}
    </Shell>
  );
}
export function MyBreakfast() {
  const { data } = useStore(),
    g = growthState(data.state),
    recipes = workspace(data.state).recipes;
  return (
    <Shell eyebrow="MY BREAKFAST" title="The versions that feel like you.">
      <section className="growth-panel">
        <h2>My creations</h2>
        <p>Your video ideas, saved storyboards and filming checklists.</p>
        <Link href="/creations">Continue a creative project →</Link>
      </section>
      <div className="growth-grid">
        {g.versions
          .filter((v) => recipes.some((r) => r.id === v.recipeId))
          .map((v) => (
            <article className="growth-card" key={v.recipeId}>
              <img
                src={v.image}
                alt="Breakfast serving inspiration"
                width="500"
                height="300"
              />
              <div>
                <h2>{recipes.find((r) => r.id === v.recipeId)?.name}</h2>
                <p>Inspired by {v.originCreator || v.creator}</p>
                <div className="growth-actions">
                  <Link href={`/cook?recipe=${v.recipeId}`}>Cook again →</Link>
                  <Link href={`/lab?recipe=${v.recipeId}`}>
                    Try another variation →
                  </Link>
                  <Link href={`/studio?recipe=${v.recipeId}`}>Share →</Link>
                </div>
              </div>
            </article>
          ))}
      </div>
      {!g.versions.length && (
        <section className="growth-panel">
          <h2>Your first variation starts with a little inspiration.</h2>
          <Link href="/discover">Find a recipe to make yours →</Link>
        </section>
      )}
      <section className="growth-panel">
        <h2>My cooking history</h2>
        {g.cooking.length ? (
          g.cooking.map((c) => (
            <article className="growth-history" key={c.id}>
              <h3>{c.meal.name}</h3>
              <p>
                {c.finishedAt
                  ? `Finished ${new Date(c.finishedAt).toLocaleDateString("en")} · ${c.rating}/5`
                  : `In progress · ${c.completed.length}/${c.meal.steps.length} steps`}
              </p>
              <p>{c.note}</p>
              <small>
                {c.fixes.length} cooking adjustment(s) · Private self-reported
                record
              </small>
              <Link href={`/cook?run=${c.id}`}>Review cooking record →</Link>
            </article>
          ))
        ) : (
          <p>
            No cooking sessions yet. Start a recipe and record what you
            discover.
          </p>
        )}
      </section>
      <section className="growth-panel">
        <h2>Your content shelf</h2>
        {g.kitDrafts.map((k) => (
          <article key={k.mealId} className="growth-history">
            <h3>{k.kit.title}</h3>
            <p>{k.kit.caption}</p>
            <Link href={`/studio?recipe=${k.mealId}`}>
              Open creator studio →
            </Link>
          </article>
        ))}
        <Link href="/workspace">Open memories, pantry and weekly planner →</Link>
      </section>
    </Shell>
  );
}
export function TrialPage() {
  const { data } = useStore(),
    { run, busy, error } = useGrowth();
  const [pack, setPack] = useState(350),
    [portion, setPortion] = useState(50),
    [selected, setSelected] = useState(trialBundles[0].id),
    [order, setOrder] = useState<any>(null);
  const requestId = useRef("");
  const b = trialBundles.find((b) => b.id === selected)!;
  const meals = b.ids
      .map((id) => resolveGrowthRecipe(data.state, id)!)
      .filter(Boolean),
    pantry = workspace(data.state).pantry;
  const [have, setHave] = useState<string[]>([]);
  const ingredients = [
    ...new Set(meals.flatMap((r) => r.ingredients.map((i) => i.name))),
  ];
  return (
    <Shell
      eyebrow="THREE WAYS TO TRY"
      title="One cupboard staple. Three different mornings."
    >
      <p className="growth-intro">
        Explore a proposed tasting journey before committing to the same bowl
        every day. Bundle availability, prices and supply are not live merchant
        offers.
      </p>
      <div className="growth-tabs">
        {trialBundles.map((bundle) => (
          <button
            key={bundle.id}
            aria-pressed={selected === bundle.id}
            onClick={() => {
              setSelected(bundle.id);
              setOrder(null);
              requestId.current = "";
              setHave([]);
            }}
          >
            {bundle.name}
          </button>
        ))}
      </div>
      <p>{b.description}</p>
      <div className="growth-grid three">
        {meals.map((m, i) => (
          <article className="growth-card" key={m.id}>
            <img
              src={m.image}
              alt="Illustrative recipe serving"
              width="500"
              height="300"
            />
            <div>
              <span className="date-label">IDEA {i + 1}</span>
              <h2>{m.name}</h2>
              <p>
                {m.activeMinutes} min active · {m.waitingMinutes} min waiting
              </p>
              {!mealFits(m, data.state) && (
                <p className="small-note">
                  Needs adaptation to your current profile.
                </p>
              )}
              <Link href={url("/lab", m)}>Make this idea mine →</Link>
            </div>
          </article>
        ))}
      </div>
      <section className="growth-panel">
        <h2>What I already have.</h2>
        <p>
          Saved pantry:{" "}
          {pantry.length
            ? pantry.map((i) => `${i.name} (${i.quantity})`).join(", ")
            : "No pantry items saved yet."}
        </p>
        <p>
          Check ingredients you already have. This checklist is an explicit
          confirmation, not an automatic deduction of compatible quantities.
        </p>
        <div className="growth-check-grid">
          {ingredients.map((name) => (
            <label key={name} className="growth-check">
              <input
                type="checkbox"
                checked={have.includes(name)}
                onChange={() =>
                  setHave((v) =>
                    v.includes(name)
                      ? v.filter((n) => n !== name)
                      : [...v, name],
                  )
                }
              />
              {name}
            </label>
          ))}
        </div>
        <h3>Measured missing list</h3>
        <p>
          Combines the profile-compatible recipes and subtracts measured pantry
          matches with compatible units.
        </p>
        <ul>
          {trialShopping(
            data.state,
            meals.filter((m) => mealFits(m, data.state)),
          )
            .filter((i) => !have.includes(i.name))
            .map((i) => (
              <li key={i.id}>
                {i.amount} {i.unit} {i.name}
              </li>
            ))}
        </ul>
        <Button
          disabled={busy}
          onClick={async () => {
            const r = await run({ action: "trial-shopping", bundle: b.id });
            if (r) setOrder({ id: r.message, status: "list" });
          }}
        >
          Replace Planner list with measured missing items
        </Button>
        <p className="small-note">
          The saved measured pantry, rather than the manual name checklist,
          determines the imported quantities. This replaces your Planner
          shopping list and can be undone there.
        </p>
        <h3>What I still need</h3>
        <p>
          {ingredients.filter((i) => !have.includes(i)).join(", ") ||
            "All ingredients checked as available. Confirm the actual quantities before cooking."}
        </p>
        <Link href="/workspace">
          Use the measured pantry & shopping list in Planner →
        </Link>
      </section>
      <section className="growth-panel">
        <h2>What could your pack make?</h2>
        <div className="growth-form">
          <label>
            Pack size confirmed by you (g)
            <input
              type="number"
              min={1}
              max={5000}
              value={pack}
              onChange={(e) => setPack(Number(e.target.value))}
            />
          </label>
          <label>
            Oats per serving (g)
            <input
              type="number"
              min={1}
              max={500}
              value={portion}
              onChange={(e) => setPortion(Number(e.target.value))}
            />
          </label>
        </div>
        <p className="growth-big-number">
          {trialPortions(pack, portion)} <span>estimated oat portions</span>
        </p>
        <p className="small-note">
          Calculation: confirmed pack grams ÷ oats per portion, rounded down.
          Other ingredients and individual portions still need checking.
        </p>
        <div className="growth-actions">
          <Button
            disabled={busy}
            onClick={async () => {
              requestId.current ||= crypto.randomUUID();
              const r = await run({
                action: "trial-order",
                bundle: b.id,
                requestId: requestId.current,
              });
              if (r) setOrder(r.order);
            }}
          >
            Create classroom trial order
          </Button>
          <Link href={`/products/${b.productId}`}>
            Explore the pantry product →
          </Link>
        </div>
        <Note text={error} />
        {order && (
          <div role="status">
            <h3>
              {order.status === "list"
                ? "Planner shopping list updated."
                : "Classroom demo order recorded."}
            </h3>
            <p>
              {order.id}{" "}
              {order.status !== "list" &&
                "· No payment, reservation or delivery."}
            </p>
          </div>
        )}
      </section>
      <section className="growth-panel">
        <h2>My classroom trial orders</h2>
        {growthState(data.state).trialOrders.length ? (
          growthState(data.state)
            .trialOrders.slice(0, 8)
            .map((o) => (
              <p key={o.id}>
                {trialBundles.find((b) => b.id === o.bundle)?.name} ·{" "}
                {new Date(o.createdAt).toLocaleDateString("en")} · {o.status}
              </p>
            ))
        ) : (
          <p>No classroom trial orders yet.</p>
        )}
      </section>
      <Link href={`/shop?product=${encodeURIComponent(b.productId)}#find-buy`}>Find products & nearby shops →</Link>
    </Shell>
  );
}
export function CampaignPage() {
  const { ready } = useStore();
  const [mode, setMode] = useState("observed"),
    [report, setReport] = useState<any>(null),
    [error, setError] = useState("");
  const load = () =>
    api("/api/growth")
      .then((r) => {
        setReport(r.campaign);
        setError("");
      })
      .catch((e) => setError(e.message));
  useEffect(() => {
    if (ready) load();
  }, [ready]);
  const definitions = [
    ["visit", "Share visits"],
    ["personalise", "Personalised versions proposed"],
    ["cooking-start", "Cooking started"],
    ["cooked", "Finished meals reported"],
    ["buy-click", "Buying interest clicks"],
    ["demo-order", "Classroom trial orders"],
  ];
  const fixture = [38, 19, 12, 8, 7, 3];
  return (
    <Shell
      eyebrow="CAMPAIGN VIEW"
      title="From inspiration to a breakfast actually tried."
    >
      <div className="growth-tabs">
        <button
          aria-pressed={mode === "observed"}
          onClick={() => setMode("observed")}
        >
          Observed local actions
        </button>
        <button aria-pressed={mode === "demo"} onClick={() => setMode("demo")}>
          Illustrative campaign
        </button>
        <button onClick={load}>Refresh results</button>
      </div>
      <p>
        {mode === "demo"
          ? "DEMONSTRATION DATA · Fictional numbers for explaining the journey; not campaign results."
          : report?.scope || "Loading your local activity…"}
      </p>
      <div className="growth-metrics">
        {definitions.map(([key, label], i) => (
          <article key={key}>
            <strong>
              {mode === "demo"
                ? fixture[i]
                : report?.counts?.find((r: any) => r.kind === key)?.count || 0}
            </strong>
            <span>{label}</span>
          </article>
        ))}
      </div>
      <section className="growth-panel">
        <h2>Read these numbers correctly.</h2>
        <p>
          Observed counts are deduplicated by visitor, action, source and day.
          Your own preview of a published share does not count as an acquired
          visitor. Self-reported cooking is not independently verified, a buying
          click is not a sale, and classroom orders are simulated.
        </p>
        <p>
          People reporting completed breakfasts on more than one day in the last
          seven days:{" "}
          <strong>{mode === "demo" ? 2 : report?.returningCooks || 0}</strong>
          {mode === "demo" ? " · illustrative" : " · observed local records"}
        </p>
        <p>
          These local records do not include social-platform impressions,
          external retailer conversions or activity from another independent
          copy of the app.
        </p>
      </section>
      <section className="growth-panel">
        <h2>Your published recipe sources</h2>
        {report?.shares?.length ? (
          report.shares.map((s: any) => (
            <p key={s.id}>
              <Link href={`/share/${s.id}`}>
                {s.creator} · {s.name || "Recipe story"} →
              </Link>
            </p>
          ))
        ) : (
          <p>
            Publish a food-only recipe card in Creator Studio. Its visitor
            journey can then be observed on this running app.
          </p>
        )}
        <Link href="/studio">Create a recipe story →</Link>
      </section>
      <section className="growth-panel">
        <h2>Validate with real people.</h2>
        <p>
          Suggested pilot: three creators and seven potential consumers. Observe
          independent content export, personalisation, actual cooking and
          reasons to try or return. Participants, taste trials and brand
          partnerships are not pre-filled as completed research.
        </p>
      </section>
      <Note text={error} />
    </Shell>
  );
}
