"use client";
import Link from "next/link";
import {
  ArrowUpRightIcon,
  BookOpenIcon,
  SparkleIcon,
} from "@phosphor-icons/react";
import { recipes } from "@/lib/catalog";
import { workspace } from "@/lib/breakfast";
import { useStore } from "./store";

export function RecipeCollectionEntry() {
  const { data } = useStore();
  const favourites = recipes.filter((r) => data.state.favorites.includes(r.id));
  const personal = workspace(data.state).recipes.length;
  const previews = (favourites.length ? favourites : recipes).slice(0, 3);
  return (
    <section
      className="recipe-collection-entry"
      aria-label="Your breakfast collection"
    >
      <Link href="/my-recipes" className="collection-door">
        <div className="collection-door-copy">
          <span className="eyebrow">
            <BookOpenIcon size={18} /> YOUR PERSONAL COOKBOOK
          </span>
          <h2>
            Good mornings,
            <br />
            <em>worth keeping.</em>
          </h2>
          <p>
            Your favourites, your little adjustments, and the recipes that feel
            like you.
          </p>
          <span className="collection-door-action">
            Open My recipes <ArrowUpRightIcon size={23} />
          </span>
          <small>
            {favourites.length} favourites <span>·</span> {personal} personal
            recipes
          </small>
        </div>
        <div className="collection-photo-stack" aria-hidden="true">
          {previews.map((r) => (
            <img
              key={r.id}
              src={r.image}
              alt=""
              width={240}
              height={300}
              loading="lazy"
            />
          ))}
        </div>
      </Link>
      <Link href="/expert" className="collection-expert-door">
        <SparkleIcon size={29} weight="light" />
        <span className="eyebrow">A LITTLE INSPIRATION</span>
        <h3>
          What feels right
          <br />
          <em>this morning?</em>
        </h3>
        <p>Let Oatie turn your preferences into a fresh breakfast idea.</p>
        <span>
          Meet your AI expert <ArrowUpRightIcon size={21} />
        </span>
      </Link>
    </section>
  );
}
