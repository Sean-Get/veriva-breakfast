"use client";
import Link from "next/link";
import { useState } from "react";
import { recipes } from "@/lib/catalog";
import { rankRecipes } from "@/lib/recommendation";
import { useStore } from "./store";
import { Button } from "./ui";

export function ChatRecipeCards({ ids, onDiscuss }: {ids: string[]; onDiscuss: (id: string) => void}) {
  const {data, mutate, notify} = useStore();
  const [pending, setPending] = useState<string | null>(null);
  const [error, setError] = useState("");
  const eligible = new Set(rankRecipes(data.state.profile, data.state.feedback).map((r) => r.recipe.id));
  async function save(id: string) {
    setPending(id);setError("");
    try {
      await mutate({action:"save-recipe", recipeId:id});
      notify("Added to your recipes. Find it in You.");
    } catch (e) {setError((e as Error).message);}
    finally {setPending(null);}
  }
  return <div className="chat-recipe-cards" aria-label="Recipes from this reply">
    {[...new Set(ids)].map((id) => {
      const recipe=recipes.find((r) => r.id === id);
      if (!recipe) return null;
      const saved=data.state.favorites.includes(id);
      const allowed=eligible.has(id);
      return <article className="chat-recipe-card" key={id}>
        <img src={recipe.image} alt={recipe.name} width={72} height={72} loading="lazy" />
        <div><h3>{recipe.name}</h3><p>{recipe.minutes} min · {recipe.subtitle}</p>
          <div className="chat-recipe-actions">
            <Button variant="secondary" disabled={saved || !allowed || pending !== null}
              onClick={() => save(id)}>{pending===id ? "Saving…" : saved ? "Saved to my recipes" : "Add to my recipes"}</Button>
            <Link href={`/recipes/${id}`}>View recipe →</Link>
            <button type="button" onClick={() => onDiscuss(id)}>Discuss this recipe</button>
            {saved && <Link href="/you">My recipes →</Link>}
          </div>
          {!allowed && <p className="small-note">This recipe no longer fits your dietary preferences.</p>}
        </div>
      </article>;
    })}
    {error && <p role="alert">{error}</p>}
  </div>;
}

export function ChatCapabilities() {
  return <details className="chat-capabilities">
    <summary>What can I do here?</summary>
    <p>Say “create a new recipe”, “plan my week”, “remember I prefer warm breakfasts” or “create a shopping list”. Review the proposal, then apply it. Manage memories, pantry, personal recipes, weekly plans and Undo in <Link href="/workspace">your breakfast workspace</Link>.</p>
    <p>Ask for a breakfast recommendation, then save its card or say “add it to my recipes”. Saved recipes appear in You.</p>
    <p>Tell me “too sweet”, “too bland”, “too thick” or “too thin”. Review and save the adjustment card to update ingredients and the method.</p>
    <p>Use <Link href="/profile">Preferences</Link> and <Link href="/health">Health records</Link> to edit your details and AI consent. Use <Link href="/shop">Shop</Link> for your basket and demo checkout.</p>
  </details>;
}
