"use client";
import Link from "next/link";
import { useState } from "react";
import {
  SparkleIcon,
  ArrowRightIcon,
  ArrowUpRightIcon,
  CheckIcon,
  BookOpenIcon,
  ChatCircleDotsIcon,
  ShieldCheckIcon,
} from "@phosphor-icons/react";
import { useStore, api } from "./store";
import { Button } from "./ui";
import { recipes, goalNames, dietNames } from "@/lib/catalog";
import { recipeMethods } from "@/lib/recipe-methods";
import { isRevisionCurrent } from "@/lib/personalisation";
import { nutritionResources } from "@/lib/nutrition-resources";
import type { Message } from "@/lib/types";
export function PersonalAIEntry() {
  const { data } = useStore();
  return (
    <section className="personal-ai-entry">
      <div className="personal-ai-symbol">
        <ChatCircleDotsIcon size={30} />
      </div>
      <div>
        <span className="date-label">YOUR BREAKFAST COMPANION</span>
        <h2>A little help, when you need it.</h2>
        <p>Ideas, small questions and a breakfast that gets to know you.</p>
        <small>
          {data.state.messages.length} saved messages ·{" "}
          {
            (data.state.revisions || []).filter((r) =>
              isRevisionCurrent(r, data.state),
            ).length
          }{" "}
          current recipe adjustments
        </small>
      </div>
      <Link className="quiet-discover" href="/chat">
        Let's talk breakfast <ArrowRightIcon size={18} />
      </Link>
    </section>
  );
}
export function SavedMethodList() {
  const { data } = useStore();
  const saved = recipes.filter((r) => data.state.favorites.includes(r.id)),
    revised = recipes.filter(
      (r) =>
        !data.state.favorites.includes(r.id) &&
        (data.state.revisions || []).some(
          (v) => v.recipeId === r.id && isRevisionCurrent(v, data.state),
        ),
    );
  return (
    <div className="saved-method-list">
      {[...saved, ...revised].length ? (
        [...saved, ...revised].map((r) => {
          const revision = (data.state.revisions || []).find(
            (v) => v.recipeId === r.id && isRevisionCurrent(v, data.state),
          );
          return (
            <article key={r.id}>
              <Link
                href={`/recipes/${r.id}#method`}
                className="saved-method-photo"
              >
                <img
                  src={r.image}
                  alt={r.name}
                  width={160}
                  height={160}
                  loading="lazy"
                />
              </Link>
              <div>
                <span className="date-label">
                  {saved.some((v) => v.id === r.id)
                    ? "SAVED RECIPE"
                    : "YOUR AI ADJUSTMENT"}
                </span>
                <h3>
                  <Link href={`/recipes/${r.id}#method`}>{r.name}</Link>
                </h3>
                <p>
                  {revision
                    ? revision.summary
                    : `${recipeMethods[r.id].steps.length} detailed steps · ${recipeMethods[r.id].waiting}`}
                </p>
                <div>
                  <Link href={`/recipes/${r.id}#method`}>
                    See the method <ArrowRightIcon size={15} />
                  </Link>
                  <Link href={`/chat?recipe=${r.id}`}>
                    Make it yours with AI <SparkleIcon size={15} />
                  </Link>
                </div>
              </div>
            </article>
          );
        })
      ) : (
        <p>Save a recipe or an AI adjustment to find it here.</p>
      )}
    </div>
  );
}
export function ChatRecordContext() {
  const { data } = useStore(),
    s = data.state,
    h = s.profile.health;
  return (
    <details className="chat-record-context">
      <summary>
        <ShieldCheckIcon size={18} />
        What is my AI using?
      </summary>
      <dl>
        <div>
          <dt>Name</dt>
          <dd>{s.profile.name === "Friend" ? "Not set" : s.profile.name}</dd>
        </div>
        <div>
          <dt>Breakfast goals</dt>
          <dd>{s.profile.goals.map((g) => goalNames[g]).join(" · ")}</dd>
        </div>
        <div>
          <dt>Dietary exclusions</dt>
          <dd>
            {s.profile.diet.map((d) => dietNames[d]).join(" · ") || "None set"}
          </dd>
        </div>
        <div>
          <dt>Preparation time</dt>
          <dd>{s.profile.minutes} minutes</dd>
        </div>
        <div>
          <dt>Recent feedback</dt>
          <dd>{s.feedback.length} saved notes</dd>
        </div>
      </dl>
      {h?.useForAI ? (
        <div className="chat-health-context">
          <strong>Your consented health records</strong>
          <p>
            Age {h.age ?? "Not set"} · Height {h.heightCm ?? "Not set"} cm ·
            Weight {h.weightKg ?? "Not set"} kg
          </p>
          <p>{h.notes || "No additional notes."}</p>
        </div>
      ) : (
        <p>
          Health records are not included in AI requests without your consent.
        </p>
      )}
      <Link href="/health">
        Edit records & consent <ArrowUpRightIcon size={15} />
      </Link>
    </details>
  );
}
export function NutritionReferences() {
  return (
    <details className="nutrition-references">
      <summary>
        <BookOpenIcon size={18} />
        Reference library · WHO / NHS
      </summary>
      <p>
        Public reference material used for general food guidance. This is an AI
        conversation, with no live web search or clinician consultation.
      </p>
      {nutritionResources.map((r) => (
        <a key={r.id} href={r.url} target="_blank" rel="noreferrer">
          <small>{r.organisation}</small>
          <strong>
            {r.title}
            <ArrowUpRightIcon size={14} />
          </strong>
          <span>{r.summary}</span>
        </a>
      ))}
      <small>Reviewed 25 October 2026 · Open a title to read the source.</small>
    </details>
  );
}
export function ChatAdjustmentCard({
  proposal,
}: {
  proposal: NonNullable<Message["proposal"]>;
}) {
  const { data, refresh, notify } = useStore();
  const [pending, setPending] = useState(false),
    [error, setError] = useState("");
  const recipe = recipes.find((r) => r.id === proposal.recipeId);
  if (!recipe) return null;
  const latest = data.state.feedback.find((f) => f.recipeId === recipe.id),
    revision = (data.state.revisions || []).find(
      (r) => r.recipeId === recipe.id && isRevisionCurrent(r, data.state),
    );
  const applied = !!revision && latest?.note === proposal.note;
  async function apply() {
    setPending(true);
    setError("");
    try {
      const result = await api("/api/chat/adjust", proposal);
      await refresh();
      if (!result.updated)
        throw new Error(
          result.state.aiUpdate?.message ||
            "Your feedback is saved, but the AI adjustment is not ready. Please retry.",
        );
      notify("Recipe adjustment saved. Find it in your recipes.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  return (
    <div className="chat-adjustment-card">
      <span className="date-label">
        {applied ? "SAVED TO YOUR BREAKFAST" : "RECIPE ADJUSTMENT REQUEST"}
      </span>
      <h3>
        <SparkleIcon size={20} />
        {recipe.name}
      </h3>
      <p>{applied ? revision!.summary : proposal.note}</p>
      {applied ? (
        <div className="chat-adjustment-actions">
          <span>
            <CheckIcon size={15} />
            Saved
          </span>
          <Link href={`/recipes/${recipe.id}#method`}>
            See the updated method <ArrowRightIcon size={16} />
          </Link>
          <Link href="/you">
            Your recipes <ArrowUpRightIcon size={15} />
          </Link>
        </div>
      ) : (
        <>
          <small>
            Save to generate and store the actual ingredient and method changes.
          </small>
          <Button type="button" disabled={pending} onClick={apply}>
            {pending
              ? "Adjusting & saving…"
              : error
                ? "Retry & save adjustment"
                : "Save this recipe adjustment"}
            <ArrowRightIcon size={16} />
          </Button>
        </>
      )}
      {error && (
        <p className="error-text" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
