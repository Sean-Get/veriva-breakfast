"use client";
import { useState, useEffect, type FormEvent } from "react";
import { api, useStore } from "./store";
import { Button } from "./ui";
import { products } from "@/lib/catalog";
import type { ProductReview } from "@/lib/product-reviews";
import { CommunityAvatar } from "./community-media";
import { SelectionTabs } from "./motion";
const exampleReviews = [
  {
    id: "demo-positive",
    name: "Mia · fictional example",
    persona: "Mia",
    rating: 5,
    text: "A lovely cupboard staple. I enjoy preparing a small portion with fruit on busy mornings.",
  },
  {
    id: "demo-critical",
    name: "Leo · fictional example",
    persona: "Leo",
    rating: 2,
    text: "The texture was thicker than I expected. I would try more liquid next time; the price would also matter to me.",
  },
];
type ReviewFeed = {
  reviews: ProductReview[];
  stats: {
    total: number;
    average: number | null;
    positive: number;
    mixed: number;
    critical: number;
  };
  total: number;
  page: number;
  pages: number;
};
export function ProductReviews({ productId }: { productId: string }) {
  const { data, ready } = useStore();
  const [result, setResult] = useState<{
    key: string;
    feed: ReviewFeed;
  } | null>(null);
  const [filter, setFilter] = useState("All"),
    [page, setPage] = useState(1),
    [version, setVersion] = useState(0);
  const [loadError, setLoadError] = useState(""),
    [postError, setPostError] = useState(""),
    [saved, setSaved] = useState(false),
    [pending, setPending] = useState(false);
  const [name, setName] = useState(""),
    [nameEdited, setNameEdited] = useState(false),
    [rating, setRating] = useState("5"),
    [text, setText] = useState("");
  const requestKey = JSON.stringify([productId, filter, page, version]);
  const feed = result?.key === requestKey ? result.feed : null;
  useEffect(() => {
    if (!nameEdited && ready) setName(data.state.profile.name);
  }, [ready, data.state.profile.name, nameEdited]);
  useEffect(() => {
    let active = true;
    setLoadError("");
    api(
      `/api/product-reviews?product=${encodeURIComponent(productId)}&filter=${filter}&page=${page}`,
    )
      .then((feed) => {
        if (active) setResult({ key: requestKey, feed });
      })
      .catch((e) => {
        if (active) setLoadError(e.message);
      });
    return () => {
      active = false;
    };
  }, [productId, filter, page, version, requestKey]);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setPostError("");
    setSaved(false);
    try {
      await api("/api/product-reviews", {
        productId,
        name,
        rating: Number(rating),
        text,
      });
      setText("");
      setSaved(true);
      setFilter("All");
      setPage(1);
      setVersion((v) => v + 1);
    } catch (e) {
      setPostError((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  const countFor = (f: string) =>
    !feed
      ? ""
      : f === "All"
        ? feed.stats.total
        : f === "Positive"
          ? feed.stats.positive
          : f === "Mixed"
            ? feed.stats.mixed
            : feed.stats.critical;
  return (
    <section className="reviews-section" id="product-reviews">
      <span className="date-label">HONEST EXPERIENCES</span>
      <h2>Product reviews</h2>
      <p>
        {feed
          ? `${feed.stats.total} submitted review${feed.stats.total === 1 ? "" : "s"}${feed.stats.average !== null ? ` · ★ ${feed.stats.average.toFixed(1)} / 5` : " · Be the first to share your experience."}`
          : loadError
            ? "Reviews are temporarily unavailable."
            : "Loading product experiences…"}
      </p>
      <SelectionTabs
        label="Review ratings"
        items={["All", "Positive", "Mixed", "Critical"].map((value) => ({
          value,
          label: value + (feed ? ` (${countFor(value)})` : ""),
        }))}
        selected={filter}
        onChange={(value) => {
          setFilter(value);
          setPage(1);
        }}
      />
      <div
        className="review-list selection-results"
        key={`${filter}:${page}`}
        aria-busy={!feed && !loadError}
      >
        {feed?.reviews.map((r) => (
          <article key={r.id}>
            <header className="review-person">
              <CommunityAvatar name={r.name} />
              <strong>
                {r.name} <span>{r.rating}/5</span>
              </strong>
            </header>
            <p>{r.text}</p>
            <small>{new Date(r.createdAt).toLocaleDateString("en-GB")}</small>
          </article>
        ))}
        {feed && !feed.reviews.length && (
          <p>No submitted reviews in this category.</p>
        )}
        {loadError && (
          <div role="alert">
            <p className="error-text">{loadError}</p>
            <Button
              variant="secondary"
              onClick={() => setVersion((v) => v + 1)}
            >
              Retry reviews
            </Button>
          </div>
        )}
      </div>
      {feed && feed.pages > 1 && (
        <div className="review-pagination">
          <Button
            size="small"
            variant="secondary"
            disabled={feed.page <= 1}
            onClick={() => setPage(feed.page - 1)}
          >
            Previous
          </Button>
          <span>
            Page {feed.page} of {feed.pages} · {feed.total}{" "}
            {filter.toLowerCase()} reviews
          </span>
          <Button
            size="small"
            variant="secondary"
            disabled={feed.page >= feed.pages}
            onClick={() => setPage(feed.page + 1)}
          >
            Next
          </Button>
        </div>
      )}
      <details>
        <summary>Classroom examples · fictional, excluded from ratings</summary>
        {exampleReviews.map((r) => (
          <article className="example-review" key={r.id}>
            <header className="review-person">
              <CommunityAvatar name={r.persona} sample />
              <strong>
                {r.name} · {r.rating}/5
              </strong>
            </header>
            <p>{r.text}</p>
          </article>
        ))}
      </details>
      <form className="form-stack review-form" onSubmit={submit}>
        <h3>Share your product experience</h3>
        <p>
          Your chosen name and review will be public. This is a classroom
          product demo, without verified purchases.
        </p>
        <label>
          Public name
          <input
            name="name"
            value={name}
            onChange={(e) => {
              setNameEdited(true);
              setName(e.target.value);
            }}
            required
            maxLength={40}
          />
        </label>
        <label>
          Rating
          <select
            name="rating"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
          >
            {[5, 4, 3, 2, 1].map((n) => (
              <option key={n} value={n}>
                {n} / 5
              </option>
            ))}
          </select>
        </label>
        <label>
          Your experience
          <textarea
            name="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            minLength={5}
            maxLength={1200}
            required
            rows={3}
          />
        </label>
        <small>{text.length} / 1200 characters</small>
        <Button
          disabled={
            !ready ||
            pending ||
            name.trim().length === 0 ||
            text.trim().length < 5
          }
        >
          {pending ? "Saving…" : "Post review"}
        </Button>
        {saved && (
          <p role="status">
            Your review is saved. Showing all reviews so you can find it.
          </p>
        )}
        {postError && (
          <p role="alert" className="error-text">
            {postError}
          </p>
        )}
      </form>
    </section>
  );
}
export function AdminProductReviews() {
  const [reviews, setReviews] = useState<ProductReview[]>([]),
    [error, setError] = useState(""),
    [version, setVersion] = useState(0),
    [pending, setPending] = useState("");
  useEffect(() => {
    let active = true;
    api("/api/product-reviews?admin=1")
      .then((r) => {
        if (active) {
          setReviews(r.reviews);
          setError("");
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      });
    return () => {
      active = false;
    };
  }, [version]);
  async function moderate(r: ProductReview) {
    setPending(r.id);
    try {
      await api("/api/product-reviews", {
        action: "moderate",
        id: r.id,
        hidden: !r.hidden,
      });
      setVersion((v) => v + 1);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPending("");
    }
  }
  return (
    <section className="reviews-section admin-review-panel">
      <h2>商品评论审核</h2>
      <p>
        最近 200
        条真实提交的评论；课堂示例不混入统计。隐藏可恢复，好评与差评均保留。
      </p>
      <Button variant="secondary" onClick={() => setVersion((v) => v + 1)}>
        刷新评论
      </Button>
      {error && <p role="alert">{error}</p>}
      {!reviews.length && <p>暂无提交的评论。</p>}
      {reviews.map((r) => (
        <article className="moderation-review" key={r.id}>
          <strong>
            {products.find((p) => p.id === r.productId)?.name} · {r.rating}/5 ·{" "}
            {r.hidden ? "已隐藏" : "公开"}
          </strong>
          <p>
            {r.name} · {r.text}
          </p>
          <Button
            size="small"
            variant="secondary"
            disabled={!!pending}
            onClick={() => moderate(r)}
          >
            {r.hidden ? "恢复显示" : "隐藏评论"}
          </Button>
        </article>
      ))}
    </section>
  );
}
