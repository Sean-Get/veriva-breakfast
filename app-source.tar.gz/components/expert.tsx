"use client";
import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import { useStore } from "./store";
import { useDailyExpert } from "./use-daily-expert";
import { rankRecipes } from "@/lib/recommendation";
import { Button } from "./ui";
import { recipes, dietNames, goalNames } from "@/lib/catalog";
import { workspace, recipeAllowed } from "@/lib/breakfast";
import { CookingPhoto } from "./recipe-cooking";

export function FloatingExpert() {
  const path = usePathname();
  if (path.startsWith("/admin") || path === "/chat") return null;
  return (
    <Link
      className="floating-expert"
      href={path === "/expert" ? "/chat" : "/expert"}
      aria-label={
        path === "/expert"
          ? "Chat with Oatie"
          : "Open Oatie, your AI breakfast expert"
      }
    >
      <img
        src="/images/oatie-assistant-v1.webp"
        alt=""
        width={92}
        height={92}
      />
      <span>
        <strong>Ask Oatie</strong>
        <small>AI breakfast expert</small>
      </span>
    </Link>
  );
}
export function ExpertPage() {
  const { data, ready, mutate, notify } = useStore();
  const { pick, pending, error, generate, retry } = useDailyExpert();
  const [saving, setSaving] = useState(false),
    [saveError, setSaveError] = useState("");
  const isSaved =
    !!pick?.recipeId && data.state.favorites.includes(pick.recipeId);
  async function save() {
    if (!pick?.recipeId || isSaved) return;
    setSaving(true);
    setSaveError("");
    try {
      await mutate({ action: "save-recipe", recipeId: pick.recipeId });
      notify("Saved to My recipes.");
    } catch (e) {
      setSaveError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }
  const recipe = recipes.find((r) => r.id === pick?.recipeId),
    profile = data.state.profile;
  return (
    <main className="main expert-page">
      <section className="expert-heading">
        <div>
          <span className="date-label">YOUR BREAKFAST, CONNECTED</span>
          <h1>
            A little expert.
            <br />A better morning.
          </h1>
          <p>
            Meet Oatie. Talk through a breakfast idea, then bring your
            preferences and recent feedback together in today's recommendation.
          </p>
          <div className="expert-actions">
            <Button asChild>
              <Link href="/chat">Talk to Oatie →</Link>
            </Button>
            <Button asChild variant="secondary">
              <Link href="/health">Update my preferences</Link>
            </Button>
          </div>
        </div>
        <img
          src="/images/oatie-assistant-v1.webp"
          alt="Oatie, a friendly oat companion with a green leaf"
          width={320}
          height={320}
        />
      </section>
      <section className="expert-context">
        <h2>What shapes your breakfast</h2>
        <div className="expert-facts">
          <p>
            <strong>Your goals</strong>
            {profile.goals.map((g) => goalNames[g]).join(", ")}
          </p>
          <p>
            <strong>Your morning</strong>
            {profile.minutes} minutes ·{" "}
            {profile.diet.map((d) => dietNames[d] || d).join(", ") ||
              "No dietary exclusions selected"}
          </p>
          <p>
            <strong>Your feedback & conversation</strong>
            {data.state.feedback.length} taste notes ·{" "}
            {data.state.messages.filter((m) => m.role === "user").length}{" "}
            messages
          </p>
          <p>
            <strong>Health records</strong>
            {profile.health?.useForAI ? "Enabled by you" : "Not shared with AI"}
          </p>
        </div>
        <p className="small-note">
          AI uses your recent conversation as context when you request a new
          pick. This is personalised guidance, not a model trained specifically
          on you.
        </p>
      </section>
      <section className="daily-pick" aria-busy={pending || (!pick && !error)}>
        <div>
          {recipe && (
            <CookingPhoto recipeId={recipe.id} panel={2} alt={recipe.name} />
          )}
        </div>
        <div>
          <span className="date-label">
            TODAY · {pick?.day || "…"} · {pick?.source || "Loading"}
          </span>
          <h2>
            {recipe?.name ||
              (pick
                ? "Let's find a suitable breakfast."
                : "Finding your breakfast…")}
          </h2>
          <p>{pick?.rationale}</p>
          {pending && (
            <p role="status" className="ai-request-status">
              Bringing your preferences and recent conversation together…
            </p>
          )}
          {pick?.updatedAt && (
            <small>
              AI pick updated{" "}
              {new Date(pick.updatedAt).toLocaleTimeString("en-GB", {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </small>
          )}
          <div className="expert-actions">
            <Button onClick={generate} disabled={!ready || pending}>
              {pending ? "Oatie is thinking…" : "Ask AI for today's pick"}
            </Button>
            {recipe && (
              <>
                <Button asChild variant="secondary">
                  <Link href={`/recipes/${recipe.id}`}>
                    Recipe & cooking steps
                  </Link>
                </Button>
                <Button
                  variant="secondary"
                  disabled={saving || isSaved || pending}
                  onClick={save}
                >
                  {isSaved
                    ? "Saved to My recipes ✓"
                    : saving
                      ? "Saving…"
                      : "Save to My recipes"}
                </Button>
              </>
            )}
          </div>
          <p className="small-note">
            Profile matches work without AI. The AI button also considers your
            recent dialogue and saved memories. Suggestions update after you ask
            again.
          </p>
          {error && (
            <div role="alert">
              <p className="error-text">{error}</p>
              {!pick && (
                <Button variant="secondary" onClick={retry}>
                  Retry breakfast match
                </Button>
              )}
            </div>
          )}
          {saveError && (
            <p role="alert" className="error-text">
              {saveError}
            </p>
          )}
        </div>
      </section>
      <div className="expert-starters">
        <h2>Start with a little question</h2>
        <p>Choose a starting point, edit it, then send it to Oatie.</p>
        <div className="expert-actions">
          {[
            "I would like a warm breakfast today.",
            "Can I prepare breakfast the night before?",
            "I want a less sweet breakfast.",
          ].map((prompt) => (
            <Link
              className="chip"
              key={prompt}
              href={`/chat?prompt=${encodeURIComponent(prompt)}`}
            >
              {prompt}
            </Link>
          ))}
        </div>
      </div>
      <div className="module-links">
        <Link href="/my-recipes">My recipes →</Link>
        <Link href="/workspace">Memories, pantry & weekly workspace →</Link>
      </div>
    </main>
  );
}
export function MyRecipesPage() {
  const { data, ready, mutate, notify, busy } = useStore(),
    w = workspace(data.state);
  const [query, setQuery] = useState(""),
    [kind, setKind] = useState("All"),
    [fit, setFit] = useState(false);
  const eligible = new Set(
    rankRecipes(data.state.profile, data.state.feedback).map(
      (r) => r.recipe.id,
    ),
  );
  const matches = (name: string, ingredients: { name: string }[]) =>
    `${name} ${ingredients.map((i) => i.name).join(" ")}`
      .toLowerCase()
      .includes(query.trim().toLowerCase());
  const favourites = recipes.filter((r) => data.state.favorites.includes(r.id));
  const saved = favourites.filter(
    (r) => matches(r.name, r.ingredients) && (!fit || eligible.has(r.id)),
  );
  const personal = w.recipes.filter(
    (r) =>
      matches(r.name, r.ingredients) && (!fit || recipeAllowed(r, data.state)),
  );
  async function remove(id: string) {
    try {
      await mutate({ action: "favorite", recipeId: id });
      notify(
        "Removed from favourites. You can save it again from its recipe page.",
      );
    } catch (e) {
      notify((e as Error).message);
    }
  }
  const count =
    (kind === "Personal recipes" ? 0 : saved.length) +
    (kind === "Favourites" ? 0 : personal.length);
  return (
    <main className="main">
      <div className="page-title">
        <span className="date-label">YOUR OWN COLLECTION</span>
        <h1>My recipes</h1>
        <p>Your favourites and saved personal recipes, together.</p>
      </div>
      <div className="module-links">
        <Link href="/recipes">Browse recipes →</Link>
        <Link href="/expert">Ask Oatie →</Link>
        <Link href="/workspace">Manage personal recipes →</Link>
      </div>
      <div className="collection-controls">
        <label>
          Search my recipes
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="A name or an ingredient…"
          />
        </label>
        <div className="category-row">
          {["All", "Favourites", "Personal recipes"].map((k) => (
            <button
              className={`chip ${kind === k ? "selected" : ""}`}
              key={k}
              aria-pressed={kind === k}
              onClick={() => setKind(k)}
            >
              {k}
            </button>
          ))}
        </div>
        <label className="fit-choice">
          <input
            type="checkbox"
            checked={fit}
            onChange={(e) => setFit(e.target.checked)}
          />
          Fits my current preferences
        </label>
      </div>
      <p role="status">
        {ready
          ? `${count} matching recipe${count === 1 ? "" : "s"}`
          : "Loading your collection…"}
      </p>
      {kind !== "Personal recipes" && (
        <>
          <h2>Saved favourites · {favourites.length}</h2>
          <div className="my-recipe-grid">
            {saved.map((r) => (
              <article key={r.id}>
                <Link href={`/recipes/${r.id}`}>
                  <CookingPhoto recipeId={r.id} panel={2} alt={r.name} />
                  <h3>{r.name}</h3>
                </Link>
                <p>
                  {r.minutes} minutes · {r.subtitle}
                </p>
                {!eligible.has(r.id) && (
                  <p className="recipe-fit-note">
                    Review your current time or dietary exclusions before
                    preparing this recipe.
                  </p>
                )}
                <div className="collection-card-actions">
                  <Link href={`/shop?recipe=${r.id}#shopping-list`}>
                    Find ingredients →
                  </Link>
                  <button
                    disabled={busy}
                    onClick={() => remove(r.id)}
                    aria-label={`Remove ${r.name} from favourites`}
                  >
                    Remove favourite
                  </button>
                </div>
              </article>
            ))}
          </div>
        </>
      )}
      {kind !== "Favourites" && (
        <>
          <h2>Personal recipes · {w.recipes.length}</h2>
          <div className="my-recipe-grid">
            {personal.map((r) => (
              <article key={r.id} className="personal-recipe-tile">
                <span className="date-label">
                  {r.source} · {r.activeMinutes} MIN
                </span>
                <Link href={`/my-recipes/${r.id}`}>
                  <h3>{r.name}</h3>
                </Link>
                <p>{r.description}</p>
                {!recipeAllowed(r, data.state) && (
                  <p className="recipe-fit-note">
                    Review needed: this no longer fits your current preferences.
                  </p>
                )}
                <div className="collection-card-actions">
                  <Link
                    href={`/shop?recipe=${encodeURIComponent(r.id)}#shopping-list`}
                  >
                    Find ingredients →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </>
      )}
      {ready && !count && (
        <div className="empty-state">
          <h2>A little room for inspiration.</h2>
          <p>
            {query || fit
              ? "Try another ingredient or clear your filters."
              : "Save a recipe you love, or ask Oatie for a personal idea."}
          </p>
          {query || fit || kind !== "All" ? (
            <Button
              variant="secondary"
              onClick={() => {
                setQuery("");
                setFit(false);
                setKind("All");
              }}
            >
              Clear filters
            </Button>
          ) : (
            <Button asChild>
              <Link href="/recipes">Find a breakfast →</Link>
            </Button>
          )}
        </div>
      )}
    </main>
  );
}
