"use client";
import Link from "next/link";
import { useEffect, useState, useRef, type FormEvent } from "react";
import {
  UsersIcon,
  LeafIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  ArrowClockwiseIcon,
  MagnifyingGlassIcon,
  SignOutIcon,
  ShieldCheckIcon,
  BookOpenIcon,
  UserIcon,
} from "@phosphor-icons/react";
import { Button } from "./ui";
import { TrafficPanel } from "./traffic";
import { AdminProductReviews } from "./product-reviews";
import { goalNames, dietNames } from "@/lib/catalog";
import type { AdminUser } from "@/lib/admin";
type Data = {
  summary: { total: number; registered: number; guests: number };
  users: AdminUser[];
  count: number;
  page: number;
  pageSize: number;
  generatedAt: string;
};
export function AdminPage() {
  const [data, setData] = useState<Data | null>(null),
    [locked, setLocked] = useState(true),
    [pending, setPending] = useState(false),
    [error, setError] = useState("");
  const [q, setQ] = useState(""),
    [query, setQuery] = useState(""),
    [type, setType] = useState("all"),
    [page, setPage] = useState(1);
  const version = useRef(0);
  async function load() {
    const id = ++version.current;
    setPending(true);
    setError("");
    try {
      const r = await fetch(
        `/api/admin?q=${encodeURIComponent(query)}&type=${type}&page=${page}`,
        { cache: "no-store" },
      );
      const body = await r.json();
      if (id !== version.current) return;
      if (r.status === 401) {
        setLocked(true);
        setData(null);
        return;
      }
      if (!r.ok) throw new Error(body.error);
      setData(body);
      setLocked(false);
    } catch (e) {
      if (id === version.current) setError((e as Error).message);
    } finally {
      if (id === version.current) setPending(false);
    }
  }
  useEffect(() => {
    void load();
    return () => {
      version.current++;
    };
  }, [query, type, page]); // eslint-disable-line react-hooks/exhaustive-deps
  async function login(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setPending(true);
    setError("");
    try {
      const password = new FormData(form).get("password");
      const r = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", password }),
      });
      const body = await r.json();
      if (!r.ok) throw new Error(body.error);
      form.reset();
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  async function logout() {
    setPending(true);
    try {
      const r = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "logout" }),
      });
      if (!r.ok) throw new Error("退出失败，请重试。");
      version.current++;
      setData(null);
      setLocked(true);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPending(false);
    }
  }
  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <Link className="brand" href="/">
          <span className="brand-symbol">
            <LeafIcon size={22} weight="fill" />
          </span>
          veriva<span className="brand-dot">.</span>
        </Link>
        <span className="admin-space">项目管理工作台</span>
        <div className="admin-nav-active">
          <UsersIcon size={20} />
          用户概览
        </div>
        <Link href="/expert"><BookOpenIcon size={20} />AI Expert</Link>
        <Link href="/">
          <ArrowLeftIcon size={20} />
          返回用户端
        </Link>
        <div className="admin-sidebar-note">
          <ShieldCheckIcon size={25} />
          <strong>课程演示后台</strong>
          <p>独立访问验证 · 只读用户信息</p>
        </div>
      </aside>
      <main className="admin-main" id="content">
        <header className="admin-topbar">
          <span>VERIVA / 管理后台 / 用户概览</span>
          {!locked ? (
            <Button
              size="small"
              variant="secondary"
              disabled={pending}
              onClick={logout}
            >
              <SignOutIcon size={16} />
              退出后台
            </Button>
          ) : (
            <span className="status-pill">受保护的访问</span>
          )}
        </header>
        {locked ? (
          <section className="admin-login">
            <div className="admin-login-symbol">
              <ShieldCheckIcon size={35} />
            </div>
            <span className="date-label">TEAM WORKSPACE</span>
            <h1>
              看见每一位
              <br />
              早餐体验者。
            </h1>
            <p>
              登录后查看已注册用户与访客的基本资料、早餐偏好及功能使用情况。
            </p>
            <form onSubmit={login} className="form-stack">
              <label>
                管理口令
                <input
                  name="password"
                  type="password"
                  required
                  autoComplete="current-password"
                  placeholder="输入本机配置的管理口令"
                  maxLength={200}
                />
              </label>
              {error ? (
                <p className="error-text" role="alert">
                  {error}
                </p>
              ) : null}
              <Button disabled={pending}>
                {pending ? "验证中…" : "进入管理后台"}
                <ArrowRightIcon size={18} />
              </Button>
            </form>
            <p className="small-note">
              首次访问：本机 output
              文件夹中的「后台访问说明.txt」保存了管理口令。交付包中请自行配置口令。
            </p>
          </section>
        ) : (
          <>
            <div className="admin-title">
              <div>
                <span className="date-label">PEOPLE & MORNING RITUALS</span>
                <h1>
                  用户概览<span>.</span>
                </h1>
                <p>真实保存的用户记录，让小组演示有据可查。</p>
              </div>
              <Button variant="secondary" onClick={load} disabled={pending}>
                <ArrowClockwiseIcon
                  size={17}
                  className={pending ? "spin" : ""}
                />
                刷新数据
              </Button>
            </div>
            <TrafficPanel />
            <div className="admin-metrics">
              <article>
                <UsersIcon size={25} />
                <span>全部用户与访客</span>
                <strong>{data?.summary.total ?? "—"}</strong>
                <small>当前数据库中的全部记录</small>
              </article>
              <article>
                <UserIcon size={25} />
                <span>已注册用户</span>
                <strong>{data?.summary.registered ?? "—"}</strong>
                <small>已创建邮箱账号</small>
              </article>
              <article>
                <LeafIcon size={25} />
                <span>访客记录</span>
                <strong>{data?.summary.guests ?? "—"}</strong>
                <small>包含匿名体验与测试会话</small>
              </article>
            </div>
            <section className="admin-directory">
              <div className="admin-directory-heading">
                <h2>
                  用户目录 <small>{data?.count ?? 0} 条符合条件</small>
                </h2>
                <span className="status-pill">只读视图</span>
              </div>
              <div className="admin-tools">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setPage(1);
                    setQuery(q.trim());
                  }}
                >
                  <MagnifyingGlassIcon size={19} />
                  <input
                    aria-label="搜索用户"
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="搜索昵称或邮箱…"
                    maxLength={100}
                  />
                  <Button size="small" variant="secondary" disabled={pending}>
                    搜索
                  </Button>
                </form>
                <label>
                  <span className="sr-only">用户类型</span>
                  <select
                    aria-label="用户类型"
                    value={type}
                    onChange={(e) => {
                      setType(e.target.value);
                      setPage(1);
                    }}
                  >
                    <option value="all">全部类型</option>
                    <option value="registered">已注册</option>
                    <option value="guest">访客</option>
                  </select>
                </label>
              </div>
              {error ? (
                <p role="alert" className="error-text">
                  {error}
                </p>
              ) : null}
              <div className="admin-table-wrap" aria-busy={pending}>
                <table className="admin-table">
                  <caption className="sr-only">
                    用户基本信息与早餐功能使用统计
                  </caption>
                  <thead>
                    <tr>
                      <th scope="col">用户</th>
                      <th scope="col">类型 / 建档</th>
                      <th scope="col">早餐偏好</th>
                      <th scope="col">使用情况</th>
                      <th scope="col">创建时间</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.users.map((user) => (
                      <tr key={user.id}>
                        <td>
                          <div className="admin-person">
                            <span>{user.name.slice(0, 1).toUpperCase()}</span>
                            <div>
                              <strong>{user.name}</strong>
                              <small>{user.email || "未绑定邮箱 · 访客"}</small>
                              <code title={user.id}>{user.id.slice(0, 8)}</code>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span
                            className={`status-pill ${user.guest ? "" : "registered"}`}
                          >
                            {user.guest ? "访客" : "已注册"}
                          </span>
                          <small>
                            {user.onboarded ? "已完成偏好设置" : "待设置偏好"}
                          </small>
                        </td>
                        <td>
                          <strong>
                            {user.goals
                              .map(
                                (g) =>
                                  goalNames[g as keyof typeof goalNames] || g,
                              )
                              .join(" · ")}
                          </strong>
                          <small>
                            {user.diet
                              .map((d) => dietNames[d] || d)
                              .join(" · ") || "未设置饮食排除"}
                          </small>
                          <small>
                            {user.minutes} 分钟 ·{" "}
                            {{
                              light: "轻度活动",
                              moderate: "中等活动",
                              active: "经常运动",
                            }[user.activity] || user.activity}
                          </small>
                        </td>
                        <td>
                          <span>
                            {user.favorites} 收藏 · {user.feedback} 反馈
                          </span>
                          <small>
                            {user.messages} 条对话 · {user.revisions} 食谱修订
                          </small>
                          <small>{user.orders} 笔演示订单</small>
                        </td>
                        <td>
                          <time
                            dateTime={new Date(user.createdAt).toISOString()}
                          >
                            {new Date(user.createdAt).toLocaleDateString(
                              "zh-CN",
                            )}
                          </time>
                          <small>
                            {new Date(user.createdAt).toLocaleTimeString(
                              "zh-CN",
                              { hour: "2-digit", minute: "2-digit" },
                            )}
                          </small>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {data && !data.users.length ? (
                  <div className="admin-empty">
                    <MagnifyingGlassIcon size={30} />
                    <h3>没有匹配的用户</h3>
                    <p>换一个昵称、邮箱，或切换用户类型再试试。</p>
                  </div>
                ) : null}
              </div>
              <div className="admin-pagination">
                <span>
                  {pending
                    ? "正在更新…"
                    : data
                      ? `更新于 ${new Date(data.generatedAt).toLocaleTimeString("zh-CN")}`
                      : ""}
                </span>
                <div>
                  <Button
                    variant="secondary"
                    size="small"
                    disabled={pending || !data || data.page <= 1}
                    onClick={() => setPage((data?.page || 1) - 1)}
                  >
                    <ArrowLeftIcon size={16} />
                    上一页
                  </Button>
                  <span>
                    {data?.page || 1} /{" "}
                    {Math.max(1, Math.ceil((data?.count || 0) / 15))}
                  </span>
                  <Button
                    variant="secondary"
                    size="small"
                    disabled={
                      pending ||
                      !data ||
                      data.page * data.pageSize >= data.count
                    }
                    onClick={() => setPage((data?.page || 1) + 1)}
                  >
                    下一页
                    <ArrowRightIcon size={16} />
                  </Button>
                </div>
              </div>
            </section>
            <AdminProductReviews />
            <p className="admin-data-note">
              数据来自当前运行目录的本地数据库。测试产生的访客也会计入统计；此页面只展示基本资料及计数，不展示密码、健康记录内容或聊天正文。
            </p>
          </>
        )}
      </main>
    </div>
  );
}
