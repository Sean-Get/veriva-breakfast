"use client";
import Link from "next/link";
import { useRef, useState, type KeyboardEvent } from "react";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  ArrowsOutIcon,
} from "@phosphor-icons/react";
import { factoryScenes } from "@/lib/factory-story";
import { Button, Modal } from "./ui";

export function FactoryFacts() {
  return (
    <section className="factory-facts" aria-label="About the real factory">
      <article>
        <span>THE PLACE</span>
        <strong>Langkampfen, Tyrol</strong>
        <p>The brand's own production facility in Austria.</p>
      </article>
      <article>
        <span>THE INGREDIENTS</span>
        <strong>Organic at the beginning</strong>
        <p>Raw ingredients sourced from organic farming.</p>
      </article>
      <article>
        <span>THE PEOPLE</span>
        <strong>Mixed, packed, dispatched</strong>
        <p>The brand describes a process with hands-on work.</p>
      </article>
      <small>
        Brand-published information ·{" "}
        <a
          href="https://www.verival.at/en/pages/ueber-uns"
          target="_blank"
          rel="noreferrer"
        >
          Read the official story ↗
        </a>
      </small>
    </section>
  );
}

export function FactoryJourney() {
  const stages = factoryScenes.slice(1),
    hero = factoryScenes[0];
  const [selected, setSelected] = useState(0),
    [enlarged, setEnlarged] = useState<number | null>(null);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]),
    scene = stages[selected];
  function keyDown(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % stages.length;
    else if (event.key === "ArrowLeft")
      next = (index + stages.length - 1) % stages.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = stages.length - 1;
    else return;
    event.preventDefault();
    setSelected(next);
    tabs.current[next]?.focus();
  }
  const expanded = enlarged === null ? null : factoryScenes[enlarged];
  return (
    <>
      <section
        className="factory-journey"
        id="factory-process"
        aria-labelledby="factory-journey-title"
      >
        <div className="factory-journey-intro">
          <div>
            <span className="date-label">IMAGINE THE JOURNEY</span>
            <h2 id="factory-journey-title">{hero.title}</h2>
          </div>
          <p>{hero.description}</p>
        </div>
        <figure className="factory-workshop-view">
          <button
            onClick={() => setEnlarged(0)}
            aria-label="Enlarge illustrated workshop"
          >
            <img
              src={hero.image}
              alt={hero.alt}
              width={1600}
              height={900}
              loading="lazy"
            />
            <span className="factory-ai-label">AI-generated illustration</span>
            <span className="expand-photo">
              <ArrowsOutIcon size={18} />
              Take a closer look
            </span>
          </button>
          <figcaption>
            Five imagined scenes for this classroom story. These images do not
            show Verival's actual rooms, machinery or operating procedures.
          </figcaption>
        </figure>
        <div
          className="factory-stage-tabs"
          role="tablist"
          aria-label="Explore the breakfast production journey"
        >
          {stages.map((s, i) => (
            <button
              key={s.id}
              ref={(el) => {
                tabs.current[i] = el;
              }}
              role="tab"
              id={`factory-tab-${s.id}`}
              aria-controls="factory-scene-panel"
              aria-selected={selected === i}
              tabIndex={selected === i ? 0 : -1}
              onClick={() => setSelected(i)}
              onKeyDown={(e) => keyDown(e, i)}
            >
              <span>0{i + 1}</span>
              <strong>{s.label}</strong>
            </button>
          ))}
        </div>
        <div
          className="factory-stage-panel"
          role="tabpanel"
          id="factory-scene-panel"
          aria-labelledby={`factory-tab-${scene.id}`}
          tabIndex={0}
        >
          <button
            className="factory-stage-photo"
            onClick={() => setEnlarged(selected + 1)}
            aria-label={`Enlarge illustrated scene: ${scene.label}`}
          >
            <img
              key={scene.image}
              src={scene.image}
              alt={scene.alt}
              width={1200}
              height={800}
              loading="lazy"
            />
            <span className="factory-ai-label">AI-generated illustration</span>
            <span className="expand-photo">
              <ArrowsOutIcon size={18} />
              View scene
            </span>
          </button>
          <div className="factory-stage-copy">
            <span className="date-label">
              0{selected + 1} / {scene.label}
            </span>
            <h3>{scene.title}</h3>
            <p>{scene.description}</p>
            <h4>What to look for</h4>
            <ul>
              {"details" in scene &&
                scene.details.map((d) => <li key={d}>{d}</li>)}
            </ul>
            {"source" in scene && (
              <div className="factory-brand-note">
                <strong>From the brand's own story</strong>
                <p>{scene.sourceNote}</p>
                <a href={scene.source} target="_blank" rel="noreferrer">
                  Read the official source ↗
                </a>
              </div>
            )}
            <div className="factory-stage-controls">
              <Button
                size="small"
                variant="secondary"
                disabled={selected === 0}
                onClick={() => setSelected((i) => i - 1)}
              >
                <ArrowLeftIcon size={16} />
                Previous
              </Button>
              <span>
                {selected + 1} of {stages.length}
              </span>
              <Button
                size="small"
                variant="secondary"
                disabled={selected === stages.length - 1}
                onClick={() => setSelected((i) => i + 1)}
              >
                Next
                <ArrowRightIcon size={16} />
              </Button>
            </div>
          </div>
        </div>
      </section>
      <section className="factory-questions" id="factory-questions">
        <div>
          <span className="date-label">A FEW THINGS TO KNOW</span>
          <h2>
            A closer look,
            <br />a clearer story.
          </h2>
          <p>
            The real brand information and the imagined scenes each have their
            own place here.
          </p>
        </div>
        <div>
          <details>
            <summary>Where is the real factory?</summary>
            <p>
              Verival identifies Langkampfen in Tyrol, Austria, as the home of
              its own breakfast production and packing facility.{" "}
              <a
                href="https://www.verival.at/en/pages/ueber-uns"
                target="_blank"
                rel="noreferrer"
              >
                Official brand story ↗
              </a>
            </p>
          </details>
          <details>
            <summary>How does Verival describe its process?</summary>
            <p>
              The brand describes selecting raw ingredients and mixing, filling,
              packing and dispatching products with hands-on work. The
              illustrated journey explains these themes without documenting a
              specific production line.{" "}
              <a
                href="https://www.verival.at/en/pages/zutaten"
                target="_blank"
                rel="noreferrer"
              >
                Official ingredient story ↗
              </a>
            </p>
          </details>
          <details>
            <summary>Which photographs are real?</summary>
            <p>
              The first gallery and the source cards below contain official
              brand photographs. The five new workshop and process scenes are
              AI-generated illustrations, labelled on each image.
            </p>
          </details>
          <details>
            <summary>Can I visit the shop?</summary>
            <p>
              The brand lists a shop in its production building in Langkampfen.
              Check its official page for current visiting information. This APP
              does not offer factory-tour bookings.{" "}
              <a
                href="https://www.verival.at/en/pages/ueber-uns"
                target="_blank"
                rel="noreferrer"
              >
                Check with the brand ↗
              </a>
            </p>
          </details>
        </div>
      </section>
      <section className="factory-kitchen-invite">
        <div>
          <span className="date-label">YOUR PART OF THE STORY</span>
          <h2>
            From the workshop.
            <br />
            To your own little ritual.
          </h2>
          <p>
            Find a recipe, choose your ingredients, and make tomorrow's
            breakfast your own.
          </p>
        </div>
        <div>
          <Button asChild>
            <Link href="/recipes">
              Find a breakfast recipe
              <ArrowRightIcon size={17} />
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href="/shop">Explore the pantry</Link>
          </Button>
        </div>
      </section>
      <Modal
        open={expanded !== null}
        onOpenChange={(open) => {
          if (!open) setEnlarged(null);
        }}
        title={expanded?.title || "Workshop scene"}
        description="AI-generated classroom illustration, not a photograph of the actual Verival factory."
        className="photo-lightbox"
      >
        {expanded && (
          <img
            className="factory-expanded-scene"
            src={expanded.image}
            alt={expanded.alt}
            width={1600}
            height={1000}
          />
        )}
        <p className="small-note">
          Illustrative scene · Generated for this student project.
        </p>
      </Modal>
    </>
  );
}
