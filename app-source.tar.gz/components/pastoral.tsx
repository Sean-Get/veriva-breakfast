"use client";
import Link from "next/link";
import {
  ArrowRightIcon,
  ArrowUpRightIcon,
  FactoryIcon,
  HeartIcon,
  LeafIcon,
  PauseIcon,
  PlayIcon,
  SparkleIcon,
  SunIcon,
} from "@phosphor-icons/react";
import { m, useMotionValue, useScroll, useSpring } from "motion/react";
import { useRef, type PointerEvent as ReactPointerEvent } from "react";
import { useNatureMotion } from "./motion";

export function PastoralExperience() {
  const { off: motionOff, reduced, toggle } = useNatureMotion();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, {
    stiffness: 130,
    damping: 28,
    mass: 0.3,
  });
  return (
    <>
      {!motionOff && (
        <m.div
          aria-hidden="true"
          className="pastoral-scroll-progress"
          style={{ scaleX: progress }}
        />
      )}
      <div className="pastoral-atmosphere" aria-hidden="true">
        <div className="pastoral-paper" />
      </div>
      <button
        type="button"
        className="nature-motion-toggle"
        aria-label={
          reduced
            ? "Nature animation is reduced by your system preference"
            : motionOff
              ? "Play nature animation"
              : "Pause nature animation"
        }
        aria-pressed={motionOff}
        disabled={reduced === true}
        onClick={toggle}
        title={
          reduced ? "Reduced by your system preference" : "Nature animation"
        }
      >
        {motionOff ? <PlayIcon size={15} /> : <PauseIcon size={15} />}
        <LeafIcon size={16} weight="fill" />
        <span>
          {reduced
            ? "Motion reduced"
            : motionOff
              ? "Play nature"
              : "Pause nature"}
        </span>
      </button>
    </>
  );
}

export function PastoralHomeHero() {
  const hero = useRef<HTMLElement>(null);
  const { off } = useNatureMotion();
  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);
  const x = useSpring(pointerX, { stiffness: 70, damping: 25 });
  const y = useSpring(pointerY, { stiffness: 70, damping: 25 });

  function moveLight(event: ReactPointerEvent<HTMLElement>) {
    if (
      off ||
      event.pointerType === "touch" ||
      document.documentElement.dataset.pastoralMotion === "off"
    )
      return;
    const bounds = event.currentTarget.getBoundingClientRect();
    pointerX.set(((event.clientX - bounds.left) / bounds.width - 0.5) * -12);
    pointerY.set(((event.clientY - bounds.top) / bounds.height - 0.5) * -8);
  }

  function resetLight() {
    pointerX.set(0);
    pointerY.set(0);
  }

  return (
    <>
      <section
        ref={hero}
        className="quiet-hero pastoral-hero"
        aria-labelledby="quiet-title"
        onPointerMove={moveLight}
        onPointerLeave={resetLight}
      >
        <m.div
          className="pastoral-hero-photo"
          style={{ x: off ? 0 : x, y: off ? 0 : y }}
        >
          <img
            src="/images/quiet-morning.webp"
            alt="A warm berry oat bowl in gentle morning light"
            width={1536}
            height={1024}
            fetchPriority="high"
          />
        </m.div>
        <div className="pastoral-hero-light" aria-hidden="true" />
        <div className="quiet-hero-copy">
          <span className="quiet-wordmark">
            <LeafIcon size={17} weight="fill" /> THE ART OF A GOOD MORNING
          </span>
          <h1 id="quiet-title">
            A little good,
            <br />
            <em>every morning.</em>
          </h1>
          <p>
            Slow down. Take a spoonful.
            <br />
            Find a breakfast that feels like you.
          </p>
          <div className="pastoral-hero-actions">
            <Link href="/recipes" className="button button-primary">
              Find your breakfast <ArrowRightIcon size={17} />
            </Link>
            <Link href="/expert" className="pastoral-text-link">
              A little help from AI <ArrowUpRightIcon size={15} />
            </Link>
          </div>
        </div>
        <div className="pastoral-hero-note">
          <SunIcon size={18} weight="fill" />
          <span>Grown from simple things</span>
        </div>
      </section>
      <nav className="pastoral-values" aria-label="Explore Veriva">
        <Link href="/expert">
          <span className="pastoral-value-icon">
            <SparkleIcon size={23} />
          </span>
          <span>
            <strong>Personalised breakfast</strong>
            <small>Made around your morning</small>
          </span>
          <ArrowUpRightIcon size={17} />
        </Link>
        <Link href="/health">
          <span className="pastoral-value-icon">
            <HeartIcon size={23} />
          </span>
          <span>
            <strong>Health insights</strong>
            <small>Your records, your choice</small>
          </span>
          <ArrowUpRightIcon size={17} />
        </Link>
        <Link href="/factory">
          <span className="pastoral-value-icon">
            <FactoryIcon size={23} />
          </span>
          <span>
            <strong>Factory transparency</strong>
            <small>Follow breakfast to its roots</small>
          </span>
          <ArrowUpRightIcon size={17} />
        </Link>
      </nav>
    </>
  );
}
