"use client";
import { useEffect, useRef, useState } from "react";
import { api, useStore } from "./store";
export type DailyPick = {
  day: string;
  recipeId: string | null;
  rationale: string;
  source: string;
  updatedAt: string | null;
};
const dayKey = () =>
  new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
export function useDailyExpert() {
  const { data, ready, refresh } = useStore();
  const [day, setDay] = useState(dayKey),
    [reload, setReload] = useState(0);
  const [result, setResult] = useState<{
    scope: string;
    pick: DailyPick;
  } | null>(null);
  const [error, setError] = useState(""),
    [pending, setPending] = useState(false);
  const fingerprint = JSON.stringify([
    data.user.id,
    data.state.profile,
    data.state.feedback,
    data.state.messages,
    data.state.breakfast?.memories,
    data.state.breakfast?.pantry,
  ]);
  const scope = day + fingerprint,
    currentScope = useRef(scope),
    sequence = useRef(0),
    isPending = useRef(pending);
  currentScope.current = scope;
  isPending.current = pending;
  useEffect(() => {
    const timer = setInterval(() => setDay(dayKey()), 30000);
    let disposed = false,
      lastFocus = 0;
    async function onFocus() {
      if (
        document.visibilityState === "hidden" ||
        !ready ||
        isPending.current ||
        Date.now() - lastFocus < 3000
      )
        return;
      lastFocus = Date.now();
      try {
        await refresh();
        if (!disposed) {
          setDay(dayKey());
          setReload((v) => v + 1);
        }
      } catch {
        if (!disposed)
          setError("Could not refresh your profile. Reconnect and retry.");
      }
    }
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      disposed = true;
      clearInterval(timer);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, [ready, refresh]);
  useEffect(() => {
    if (!ready) return;
    const id = ++sequence.current;
    setError("");
    setPending(false);
    api("/api/expert")
      .then((pick) => {
        if (id === sequence.current && scope === currentScope.current)
          setResult({ scope, pick });
      })
      .catch((e) => {
        if (id === sequence.current) setError(e.message);
      });
    return () => {
      sequence.current++;
    };
  }, [ready, scope, reload]);
  async function generate() {
    if (!ready || isPending.current) return;
    const id = ++sequence.current,
      requestedScope = currentScope.current;
    isPending.current = true;
    setPending(true);
    setError("");
    try {
      const pick = await api("/api/expert", { action: "recommend" });
      if (id === sequence.current && requestedScope === currentScope.current)
        setResult({ scope: requestedScope, pick });
    } catch (e) {
      if (id === sequence.current) setError((e as Error).message);
    } finally {
      if (id === sequence.current) {
        isPending.current = false;
        setPending(false);
      }
    }
  }
  return {
    pick: result?.scope === scope ? result.pick : null,
    pending,
    error,
    generate,
    retry: () => setReload((v) => v + 1),
  };
}
