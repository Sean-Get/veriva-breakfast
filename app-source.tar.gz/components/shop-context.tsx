"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import type { ShopContext } from "@/lib/shop-context";
export function ShoppingContext({ context }: { context: ShopContext }) {
  const [checked, setChecked] = useState<number[]>([]);
  useEffect(() => {
    if (context.title && window.location.hash === "#shopping-list")
      document
        .getElementById("shopping-list")
        ?.scrollIntoView({ behavior: "instant", block: "start" });
  }, [context.key, context.title]);
  if (context.missing)
    return (
      <section className="shopping-context" role="status">
        <p>
          This breakfast is no longer available in your collection. Browse the
          pantry or choose another saved recipe.
        </p>
        <Link href="/my-recipes">My recipes →</Link>
      </section>
    );
  if (!context.title) return null;
  return (
    <section className="shopping-context" id="shopping-list">
      <span className="date-label">SHOPPING FOR</span>
      <h2>{context.title}</h2>
      <div className="module-links">
        {context.recipeHref && (
          <Link href={context.recipeHref}>Back to the recipe →</Link>
        )}
        <a href="#find-buy">Map & buying options ↓</a>
        <Link href="/shop">Clear breakfast selection</Link>
      </div>
      {!!context.ingredients.length && (
        <>
          <h3>Check your ingredients</h3>
          <p>
            Tick what you already have. This checklist stays for this visit and
            does not change your pantry records.
          </p>
          <div className="shopping-ingredient-list">
            {context.ingredients.map((i, index) => (
              <label key={`${i.name}-${index}`}>
                <input
                  type="checkbox"
                  checked={checked.includes(index)}
                  onChange={(e) =>
                    setChecked((current) =>
                      e.target.checked
                        ? [...current, index]
                        : current.filter((n) => n !== index),
                    )
                  }
                />
                <span>{i.name}</span>
                <strong>{i.amount}</strong>
              </label>
            ))}
          </div>
          <p role="status">
            {checked.length} of {context.ingredients.length} already in your
            kitchen
          </p>
        </>
      )}
    </section>
  );
}
