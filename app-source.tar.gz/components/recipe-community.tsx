"use client";
import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { ChatCircleDotsIcon, ArrowRightIcon } from "@phosphor-icons/react";
import {
  exampleStories,
  generalCommunityTopic,
} from "@/lib/community-examples";
import { recipes } from "@/lib/catalog";
import type { CommunityPost } from "@/lib/types";
import { useStore, api } from "./store";
import { Button } from "./ui";
import { Reveal } from "./motion";
import { CommunityAvatar, CommunityBreakfastPhoto } from "./community-media";
type Feed = {
  posts: CommunityPost[];
  total: number;
  page: number;
  pages: number;
};
export function RecipeCommunity({ recipeId }: { recipeId?: string }) {
  const { data, mutate, busy, setAuthOpen, notify } = useStore();
  const [feed, setFeed] = useState<Feed | null>(null),
    [page, setPage] = useState(1),
    [version, setVersion] = useState(0),
    [text, setText] = useState(""),
    [topic, setTopic] = useState(recipeId || generalCommunityTopic),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [more, setMore] = useState(false);
  useEffect(() => {
    let active = true;
    setLoading(true);
    api(
      `/api/community?recipe=${encodeURIComponent(recipeId || "")}&page=${page}`,
    )
      .then((result) => {
        if (active) {
          setFeed(result);
          setError("");
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [recipeId, page, version]);
  async function share(e: FormEvent) {
    e.preventDefault();
    if (data.user.guest) {
      setAuthOpen(true);
      return;
    }
    try {
      setError("");
      await mutate({ action: "share", recipeId: recipeId || topic, text });
      setText("");
      setPage(1);
      setVersion((v) => v + 1);
      notify("Your breakfast note is shared.");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const samples = recipeId
    ? exampleStories.filter((s) => s.recipeId === recipeId)
    : [
        ...exampleStories.filter((s) => s.recipeId === generalCommunityTopic),
        ...exampleStories.filter((s) => s.recipeId !== generalCommunityTopic),
      ];
  const shown = more ? samples : samples.slice(0, recipeId ? 2 : 4);
  return (
    <section
      className="recipe-community"
      id={recipeId ? "recipe-conversation" : "breakfast-table"}
      aria-labelledby={
        recipeId ? "recipe-conversation-title" : "breakfast-table-title"
      }
    >
      <div className="community-window-heading">
        <span>
          <ChatCircleDotsIcon size={20} />
          THE BREAKFAST TABLE
        </span>
        <h2
          id={recipeId ? "recipe-conversation-title" : "breakfast-table-title"}
        >
          {recipeId
            ? "Cooking tips & experiences"
            : "Breakfast experience exchange."}
        </h2>
        <p>
          {recipeId
            ? "A place for your questions, little discoveries and personal twists on this bowl."
            : "Your favourite way with oats, a new breakfast idea, or something completely your own. Pull up a chair."}
        </p>
      </div>
      <div className="community-window-grid">
        <div className="community-stories">
          <div className="community-example-label">
            Sample conversations{" "}
            <span>
              Fictional personas · AI-generated portraits and breakfast photos.
            </span>
          </div>
          <div className="community-story-grid">
            {shown.map((story) => (
              <Reveal key={story.id}>
                <article className="breakfast-story example-story">
                  <header>
                    <CommunityAvatar name={story.name} sample />
                    <div>
                      <strong>{story.name}</strong>
                      <small>Sample story · Fictional persona</small>
                    </div>
                  </header>
                  <h3>{story.title}</h3>
                  <p>{story.text}</p>
                  <CommunityBreakfastPhoto storyId={story.id} />
                  {!recipeId && (
                    <Link
                      href={
                        story.recipeId === generalCommunityTopic
                          ? "#breakfast-table"
                          : `/recipes/${story.recipeId}#recipe-conversation`
                      }
                      className="subtle-link"
                    >
                      {recipes.find((r) => r.id === story.recipeId)?.name ||
                        "A breakfast of their own"}
                      <ArrowRightIcon size={14} />
                    </Link>
                  )}
                </article>
              </Reveal>
            ))}
          </div>
          {!recipeId && (
            <button
              className="quiet-discover more-stories"
              type="button"
              onClick={() => setMore((v) => !v)}
            >
              {more ? "Show fewer sample stories" : "More breakfast stories"}
              <ArrowRightIcon size={16} />
            </button>
          )}
          <div className="real-conversation">
            <h3>From people using VERIVA</h3>
            {loading ? (
              <p role="status">Loading notes…</p>
            ) : feed?.posts.length ? (
              feed.posts.map((post) => (
                <article className="breakfast-story real-story" key={post.id}>
                  <header>
                    <CommunityAvatar name={post.name} />
                    <div>
                      <strong>{post.name}</strong>
                      <small>
                        Community note ·{" "}
                        <time dateTime={post.createdAt}>
                          {new Date(post.createdAt).toLocaleDateString("en-GB")}
                        </time>
                      </small>
                    </div>
                  </header>
                  <p>{post.text}</p>
                  {!recipeId && (
                    <Link
                      className="subtle-link"
                      href={
                        post.recipeId === generalCommunityTopic
                          ? "#breakfast-table"
                          : `/recipes/${post.recipeId}#recipe-conversation`
                      }
                    >
                      {recipes.find((r) => r.id === post.recipeId)?.name ||
                        "An original breakfast idea"}
                    </Link>
                  )}
                </article>
              ))
            ) : (
              <p className="community-real-empty">
                No community notes here yet. Yours could be the first.
              </p>
            )}
            {feed && feed.pages > 1 && (
              <div className="feed-pagination">
                <Button
                  variant="secondary"
                  size="small"
                  disabled={loading || page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  Previous
                </Button>
                <span>
                  {feed.page} / {feed.pages}
                </span>
                <Button
                  variant="secondary"
                  size="small"
                  disabled={loading || page >= feed.pages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            )}
          </div>
        </div>
        <form className="community-write form-stack" onSubmit={share}>
          <h3>Share your morning.</h3>
          <p>
            A small tip, a question, or a breakfast you love. Everyone starts
            somewhere.
          </p>
          {!recipeId && (
            <label>
              What is your note about?
              <select value={topic} onChange={(e) => setTopic(e.target.value)}>
                <option value={generalCommunityTopic}>
                  My own breakfast idea
                </option>
                {recipes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </label>
          )}
          <label>
            Your breakfast note
            <textarea
              rows={5}
              minLength={3}
              maxLength={300}
              required
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="I like to make mine with…"
            />
          </label>
          {error && (
            <p role="alert" className="error-text">
              {error}
            </p>
          )}
          <Button disabled={busy}>
            {data.user.guest
              ? "Sign in to share"
              : busy
                ? "Sharing…"
                : "Share your note"}
            <ArrowRightIcon size={16} />
          </Button>
          {data.user.guest && (
            <small>Your note stays here while you sign in.</small>
          )}
          <button
            className="text-button"
            type="button"
            onClick={() => setVersion((v) => v + 1)}
          >
            Refresh community notes
          </button>
        </form>
      </div>
    </section>
  );
}
