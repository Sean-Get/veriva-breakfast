"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, useStore } from "./store";
import {
  ideaTemplates,
  briefSchema,
  ideaCompatibility,
  buildCreativeProject,
  projectText,
  type CreativeBrief,
  type CreativeProject,
} from "@/lib/creator-ideas";
import {
  conceptRecipes,
  resolveGrowthRecipe,
  mealFits,
  type GrowthMeal,
} from "@/lib/growth";
import { recipes, products } from "@/lib/catalog";
import { workspace } from "@/lib/breakfast";
import { creatorVisuals } from "@/lib/creator-visuals";
import "./creator-ideas.css";

type Overview = {
  projects: CreativeProject[];
  bookmarks: string[];
  events: { kind: string; count: number }[];
};
function useProjects() {
  const { ready } = useStore();
  const [value, setValue] = useState<Overview>({
      projects: [],
      bookmarks: [],
      events: [],
    }),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const reload = useCallback(async () => {
    try {
      const next: Overview = await api("/api/creator-projects");
      setValue(next);
      setError("");
      return next;
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    if (ready) void reload();
  }, [ready, reload]);
  async function run(body: Record<string, unknown>) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      const r = await api("/api/creator-projects", body);
      await reload();
      return r;
    } catch (e) {
      setError((e as Error).message);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return { value, error, loading, busy, run, reload };
}
function Frame({
  title,
  eyebrow = "THE CREATOR WORKTABLE",
  children,
}: {
  title: string;
  eyebrow?: string;
  children: React.ReactNode;
}) {
  return (
    <main className="main ideas-main">
      <nav className="ideas-nav" aria-label="Creator workspace">
        <Link href="/ideas">Video ideas</Link>
        <Link href="/discover">Recipes & remixes</Link>
        <Link href="/creations">My creations</Link>
        <Link href="/studio">Classic studio</Link>
      </nav>
      <header className="ideas-heading">
        <span className="date-label">{eyebrow}</span>
        <h1>{title}</h1>
      </header>
      {children}
    </main>
  );
}
function ErrorNote({ text }: { text: string }) {
  return text ? (
    <p className="ideas-error" role="alert">
      {text}
    </p>
  ) : null;
}
function mealQuery(meal: GrowthMeal) {
  const q = new URLSearchParams({ recipe: meal.id });
  if (meal.shareId) q.set("share", meal.shareId);
  return q.toString();
}
export function IdeaHome() {
  return (
    <section className="ideas-home">
      <div>
        <span className="date-label">FOR YOUR NEXT STORY</span>
        <h2>Something worth filming.</h2>
        <p>A breakfast, a little inspiration, your own way of telling it.</p>
        <Link href="/ideas">Browse video ideas →</Link>
      </div>
      <div className="ideas-home-picks">
        {ideaTemplates
          .filter((t) => ["quiet-morning", "texture"].includes(t.id))
          .map((t) => (
            <Link key={t.id} href={`/ideas?idea=${t.id}`}>
              <img
                src={creatorVisuals[t.id].src}
                alt={creatorVisuals[t.id].alt}
                width={1200}
                height={800}
                loading="lazy"
              />
              <h3>{t.title}</h3>
              <p>{t.angle}</p>
            </Link>
          ))}
      </div>
    </section>
  );
}
export function IdeasPage() {
  const params = useSearchParams(),
    router = useRouter(),
    { data, ready } = useStore(),
    projects = useProjects();
  const [selected, setSelected] = useState(params.get("idea") || ""),
    [recipeId, setRecipeId] = useState(params.get("recipe") || "berry-oats"),
    [companionId, setCompanionId] = useState("concept-apple"),
    [filter, setFilter] = useState("all"),
    [savedOnly, setSavedOnly] = useState(false),
    [brief, setBrief] = useState<CreativeBrief>(briefSchema.parse({})),
    [shared, setShared] = useState<GrowthMeal | null>(null),
    [shareError, setShareError] = useState("");
  const share = params.get("share");
  useEffect(() => {
    let live = true;
    if (share)
      api(`/api/growth?share=${encodeURIComponent(share)}`)
        .then((r) => {
          if (live) {
            setShared({ ...r.meal, shareId: r.id });
            setRecipeId(r.meal.id);
          }
        })
        .catch((e) => {
          if (live) setShareError(e.message);
        });
    return () => {
      live = false;
    };
  }, [share]);
  const meals = [
    ...recipes.map((r) => resolveGrowthRecipe(data.state, r.id)!),
    ...conceptRecipes,
    ...workspace(data.state).recipes.map((r) =>
      resolveGrowthRecipe(data.state, r.id)!,
    ),
  ].filter(Boolean);
  const meal =
      shared && recipeId === shared.id
        ? shared
        : meals.find((r) => r.id === recipeId),
    companion = meals.find((r) => r.id === companionId),
    idea = ideaTemplates.find((t) => t.id === selected);
  const reason =
      meal && idea
        ? ideaCompatibility(
            meal,
            idea.id,
            brief,
            idea.id === "two-ways" ? companion : undefined,
          )
        : "",
    dietReason =
      meal && !mealFits(meal, data.state)
        ? "This recipe does not match your current food preferences. Adapt it in Make It Mine before creating a filming project."
        : idea?.id === "two-ways" &&
            companion &&
            !mealFits(companion, data.state)
          ? "The second recipe needs adapting to your food preferences."
          : "";
  let preview: CreativeProject | undefined;
  if (meal && idea && !reason && !dietReason)
    preview = buildCreativeProject(
      meal,
      idea.id,
      brief,
      idea.id === "two-ways" ? companion : undefined,
    );
  function choose(id: string) {
    setSelected(id);
    const t = ideaTemplates.find((t) => t.id === id)!;
    if (!params.get("recipe") && !share) setRecipeId(t.recipe);
    void projects.run({ action: "event", kind: "idea-open", subject: id });
  }
  return (
    <Frame title="A little idea. A story of your own.">
      <p className="ideas-lead">
        Choose a story, connect a real recipe, then make a filming plan you can
        actually use. AI-generated scenes illustrate filming ideas; follow your
        selected recipe.
      </p>
      <div className="ideas-filters" role="group" aria-label="Video idea style">
        {["all", "diary", "tutorial", "texture", "remix"].map((f) => (
          <button
            key={f}
            aria-pressed={filter === f}
            onClick={() => setFilter(f)}
          >
            {f === "all" ? "All ideas" : f[0].toUpperCase() + f.slice(1)}
          </button>
        ))}
        <button
          aria-pressed={savedOnly}
          onClick={() => setSavedOnly(!savedOnly)}
        >
          Saved ideas
        </button>
      </div>
      <div className="ideas-grid">
        {ideaTemplates
          .filter(
            (t) =>
              (filter === "all" || t.category === filter) &&
              (!savedOnly || projects.value.bookmarks.includes(t.id)),
          )
          .map((t) => {
            return (
              <article
                className={`idea-card ${selected === t.id ? "is-selected" : ""}`}
                key={t.id}
              >
                <img
                  src={creatorVisuals[t.id].src}
                  alt={creatorVisuals[t.id].alt}
                  width={1200}
                  height={800}
                  loading="lazy"
                />
                <div className="idea-card-body">
                  <span className="date-label">{t.category}</span>
                  <h2>{t.title}</h2>
                  <p>{t.angle}</p>
                  <small>Phone-friendly · 15 / 30 / 60 sec video</small>
                  <div className="ideas-actions">
                    <a href="#idea-brief" onClick={() => choose(t.id)}>
                      View idea →
                    </a>
                    <button
                      aria-label={`${projects.value.bookmarks.includes(t.id) ? "Unsave" : "Save"} ${t.title}`}
                      aria-pressed={projects.value.bookmarks.includes(t.id)}
                      disabled={projects.busy || !ready}
                      onClick={() =>
                        projects.run({
                          action: "bookmark",
                          ideaId: t.id,
                          on: !projects.value.bookmarks.includes(t.id),
                        })
                      }
                    >
                      {projects.value.bookmarks.includes(t.id)
                        ? "Saved"
                        : "Save idea"}
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
      </div>
      {savedOnly && !projects.value.bookmarks.length && (
        <p>No saved ideas yet. Save a card to find it here later.</p>
      )}
      <ErrorNote text={projects.error || shareError} />
      {selected && !idea && (
        <ErrorNote text="That idea is unavailable. Choose a card above." />
      )}
      {idea && (
        <section className="idea-brief" id="idea-brief">
          <span className="date-label">YOUR CREATIVE BRIEF</span>
          <h2>{idea.title}</h2>
          <p>{idea.visual}</p>
          <figure className="idea-mood-reference">
            <img
              src={creatorVisuals[idea.id].src}
              alt={creatorVisuals[idea.id].alt}
              width={1200}
              height={800}
              loading="lazy"
            />
            <figcaption>
              AI-generated mood reference for this story. Your selected recipe
              and actual result may look different.
            </figcaption>
          </figure>
          <fieldset disabled={projects.busy || !ready} className="ideas-form">
            <label>
              Recipe
              <select
                value={recipeId}
                onChange={(e) => setRecipeId(e.target.value)}
              >
                {shared && (
                  <option value={shared.id}>
                    {shared.name} · shared snapshot
                  </option>
                )}
                {meals
                  .filter((m) => m.id !== shared?.id)
                  .map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
              </select>
            </label>
            {idea.id === "two-ways" && (
              <label>
                Second recipe
                <select
                  value={companionId}
                  onChange={(e) => setCompanionId(e.target.value)}
                >
                  {meals.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
            <label>
              Filming setup
              <select
                value={brief.setup}
                onChange={(e) =>
                  setBrief({
                    ...brief,
                    setup: e.target.value as CreativeBrief["setup"],
                  })
                }
              >
                <option value="phone">Phone only</option>
                <option value="tripod">Phone + tripod</option>
              </select>
            </label>
            <label>
              Setting
              <select
                value={brief.setting}
                onChange={(e) =>
                  setBrief({
                    ...brief,
                    setting: e.target.value as CreativeBrief["setting"],
                  })
                }
              >
                {["dorm desk", "home kitchen", "café-style table"].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label>
              Kitchen equipment
              <select
                value={brief.equipment}
                onChange={(e) =>
                  setBrief({
                    ...brief,
                    equipment: e.target.value as CreativeBrief["equipment"],
                  })
                }
              >
                {["any", "no-cook", "microwave", "stove", "kettle"].map((s) => (
                  <option key={s} value={s}>
                    {s === "any" ? "Use the recipe equipment" : s}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Target video length
              <select
                value={brief.seconds}
                onChange={(e) =>
                  setBrief({
                    ...brief,
                    seconds: Number(e.target.value) as 15 | 30 | 60,
                  })
                }
              >
                {[15, 30, 60].map((n) => (
                  <option key={n} value={n}>
                    {n} seconds
                  </option>
                ))}
              </select>
            </label>
            <label>
              Caption language
              <select
                value={brief.language}
                onChange={(e) =>
                  setBrief({
                    ...brief,
                    language: e.target.value as "en" | "zh",
                  })
                }
              >
                <option value="en">English</option>
                <option value="zh">Chinese captions · English method</option>
              </select>
            </label>
            {idea.id === "series" && (
              <>
                <label>
                  Series title
                  <input
                    maxLength={70}
                    value={brief.seriesTitle}
                    onChange={(e) =>
                      setBrief({ ...brief, seriesTitle: e.target.value })
                    }
                    placeholder="My breakfast mornings"
                  />
                </label>
                <label>
                  Episode number
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={brief.episode}
                    onChange={(e) =>
                      setBrief({ ...brief, episode: Number(e.target.value) })
                    }
                  />
                </label>
              </>
            )}
            <label className="ideas-full">
              Your creative direction
              <textarea
                maxLength={300}
                value={brief.note}
                onChange={(e) => setBrief({ ...brief, note: e.target.value })}
                placeholder="e.g. A calm dorm morning, close details and no talking."
              />
            </label>
          </fieldset>
          {meal && (
            <p className="ideas-timing">
              <strong>{meal.activeMinutes} min active</strong>
              <span>{meal.waitingMinutes} min waiting</span>
              <span>{brief.seconds} sec video target</span>
            </p>
          )}
          <ErrorNote text={reason || dietReason} />
          {(reason || dietReason) && meal && (
            <Link href={`/lab?${mealQuery(meal)}&returnIdea=${idea.id}`}>
              Adapt this recipe in Make It Mine →
            </Link>
          )}
          {preview && (
            <>
              <h3>A preview of your filming plan</h3>
              <ol className="ideas-preview">
                {preview.shots.map((s) => (
                  <li key={s.id}>
                    <strong>
                      {s.title} · {s.seconds}s
                    </strong>
                    <p>{s.action}</p>
                    <small>{s.angle}</small>
                  </li>
                ))}
              </ol>
              <p className="ideas-note">
                A shot list supports your filming. Follow the complete recipe,
                including every cooking and waiting stage.{" "}
                {meal?.concept
                  ? "This is a concept recipe; actual cooking and taste testing are still needed."
                  : ""}
              </p>
              <button
                className="ideas-primary"
                disabled={projects.busy}
                onClick={async () => {
                  const r = await projects.run({
                    action: "create",
                    requestId: crypto.randomUUID(),
                    ideaId: idea.id,
                    recipeId: meal!.id,
                    shareId: meal!.shareId,
                    companionId:
                      idea.id === "two-ways" ? companionId : undefined,
                    brief,
                    legacy: params.get("import") === "1",
                  });
                  if (r) router.push(`/studio?project=${r.project.id}`);
                }}
              >
                {projects.busy ? "Creating…" : "Start this idea →"}
              </button>
            </>
          )}
        </section>
      )}
    </Frame>
  );
}

function download(blob: Blob, name: string) {
  const u = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = u;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 30000);
}
async function storyboard(p: CreativeProject) {
  const lines = projectText(p).split("\n"),
    canvas = document.createElement("canvas"),
    ctx = canvas.getContext("2d");
  if (!ctx)
    throw Error("Canvas export is unavailable. Download the TXT plan instead.");
  canvas.width = 1100;
  ctx.font = "24px Arial";
  const wrapped: string[] = [];
  for (const line of lines) {
    let row = "";
    for (const word of Array.from(line)) {
      if (ctx.measureText(row + word).width > 950) {
        wrapped.push(row);
        row = word;
      } else row += word;
    }
    wrapped.push(row);
  }
  const perPage = 100;
  for (let page = 0; page < Math.ceil(wrapped.length / perPage); page++) {
    const slice = wrapped.slice(page * perPage, (page + 1) * perPage);
    canvas.height = 180 + slice.length * 34;
    ctx.fillStyle = "#f7f5ed";
    ctx.fillRect(0, 0, 1100, canvas.height);
    ctx.fillStyle = "#294536";
    ctx.font = "bold 32px Arial";
    ctx.fillText(`VERIVA · FILMING PLAN · ${page + 1}`, 70, 75);
    ctx.font = "24px Arial";
    slice.forEach((l, i) => ctx.fillText(l, 70, 145 + i * 34));
    const blob = await new Promise<Blob | null>((r) =>
      canvas.toBlob(r, "image/png"),
    );
    if (!blob)
      throw Error("PNG export failed. Your project is saved; try TXT.");
    download(blob, `VERIVA-storyboard-${p.id}-${page + 1}.png`);
  }
}

export function CreatorProjectPage({ shoot = false }: { shoot?: boolean }) {
  const params = useSearchParams(),
    router = useRouter(),
    projects = useProjects(),
    { notify } = useStore(),
    id = params.get("project");
  const [draft, setDraft] = useState<CreativeProject | null>(null),
    [suggestion, setSuggestion] = useState<CreativeProject | null>(null),
    [index, setIndex] = useState(0),
    [exportError, setExportError] = useState(""),
    [aiNote, setAiNote] = useState("");
  const saved = projects.value.projects.find((p) => p.id === id),
    dirty =
      !!draft && !!saved && JSON.stringify(draft) !== JSON.stringify(saved);
  useEffect(() => {
    setDraft(saved ? structuredClone(saved) : null);
    setSuggestion(null);
    setIndex(0);
  }, [id, !!saved]);
  useEffect(() => {
    if (!dirty) return;
    const unload = (e: BeforeUnloadEvent) => e.preventDefault();
    const click = (e: MouseEvent) => {
      const a = (e.target as Element)?.closest?.("a");
      if (a?.download) return;
      if (
        a?.href &&
        !a.href.endsWith("#") &&
        !window.confirm("Leave this page without saving your project edits?")
      ) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    window.addEventListener("beforeunload", unload);
    document.addEventListener("click", click, true);
    return () => {
      window.removeEventListener("beforeunload", unload);
      document.removeEventListener("click", click, true);
    };
  }, [dirty]);
  const p = draft;
  async function save() {
    if (!p) return;
    const r = await projects.run({
      action: "update",
      id: p.id,
      revision: p.revision,
      content: {
        title: p.title,
        hook: p.hook,
        caption: p.caption,
        shots: p.shots,
      },
    });
    if (r) {
      setDraft(r.project);
      setSuggestion(null);
      notify("Project saved.");
    }
    return r;
  }
  async function mark(status: "pending" | "captured" | "skipped") {
    if (!p) return;
    const r = await projects.run({
      action: "progress",
      id: p.id,
      revision: p.revision,
      index,
      status,
    });
    if (r) setDraft(r.project);
  }
  const shot = p?.shots[index];
  return (
    <Frame
      title={shoot ? "One shot at a time." : "Make this story your own."}
      eyebrow={shoot ? "SHOOT MODE" : "CREATOR STUDIO"}
    >
      <ErrorNote text={projects.error || exportError} />
      {projects.loading ? (
        <p>Loading your saved projects…</p>
      ) : !p ? (
        <p>
          This project is unavailable.{" "}
          <Link href="/ideas">Choose a new idea →</Link>
        </p>
      ) : (
        <>
          <div className="project-summary">
            <img
              src={p.meal.image}
              alt="Illustrative serving inspiration"
              width={220}
              height={160}
            />
            <div>
              <span className="date-label">
                {ideaTemplates.find((t) => t.id === p.ideaId)?.title}
              </span>
              <h2>{p.meal.name}</h2>
              <p>
                {p.meal.activeMinutes} min active · {p.meal.waitingMinutes} min
                waiting · {p.brief.seconds}s video
              </p>
              <p>
                {p.brief.setting} ·{" "}
                {p.brief.setup === "phone" ? "Phone only" : "Phone + tripod"}
              </p>
              <small>
                Recipe snapshot saved with this project. Later recipe changes do
                not rewrite it.
              </small>
            </div>
          </div>
          <details className="ideas-recipe">
            <summary>Complete recipe, ingredients & preparation</summary>
            {[p.meal, ...(p.companion ? [p.companion] : [])].map((m) => (
              <div key={m.id}>
                <h3>{m.name}</h3>
                <p>
                  {m.servings} serving(s) · {m.activeMinutes} min active +{" "}
                  {m.waitingMinutes} min waiting
                </p>
                <ul>
                  {m.ingredients.map((v, i) => (
                    <li key={i}>
                      {v.amount} {v.unit} {v.name}
                    </li>
                  ))}
                </ul>
                <ol>
                  {m.steps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
                <p>
                  Inspired by {m.originCreator || m.creator}.{" "}
                  {m.concept
                    ? "Concept recipe; taste testing is still needed."
                    : ""}
                </p>
              </div>
            ))}
            <ul>
              {p.preparation.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </details>
          {shoot && shot ? (
            <section className="shoot-panel">
              <span className="date-label">
                SHOT {index + 1} OF {p.shots.length} · {p.progress[index]}
              </span>
              <h2>{shot.title}</h2>
              <p className="shoot-action">{shot.action}</p>
              <p>
                <strong>Camera:</strong> {shot.angle}
              </p>
              <p>
                <strong>Suggested length:</strong> {shot.seconds} seconds
              </p>
              <blockquote>{shot.caption}</blockquote>
              <div className="ideas-actions">
                <button
                  className="ideas-primary"
                  disabled={projects.busy}
                  onClick={() => mark("captured")}
                >
                  Shot captured
                </button>
                <button
                  disabled={projects.busy}
                  onClick={() => mark("skipped")}
                >
                  Skip for now
                </button>
                <button
                  disabled={projects.busy}
                  onClick={() => mark("pending")}
                >
                  Reset shot
                </button>
              </div>
              <div className="ideas-actions">
                <button
                  disabled={index === 0}
                  onClick={() => setIndex(index - 1)}
                >
                  ← Previous
                </button>
                <button
                  disabled={index === p.shots.length - 1}
                  onClick={() => setIndex(index + 1)}
                >
                  Next shot →
                </button>
              </div>
              <p>
                {p.progress.filter((s) => s === "captured").length} captured ·{" "}
                {p.progress.filter((s) => s === "skipped").length} skipped ·
                self-reported checklist
              </p>
              <p className="ideas-note">
                Use your phone camera to record. This mode does not record video
                or mark the recipe as cooked.
              </p>
              <Link href={`/studio?project=${p.id}`}>
                Back to project & exports →
              </Link>
            </section>
          ) : (
            <>
              <section className="idea-brief">
                <div className="ideas-actions">
                  <strong role="status">
                    {dirty ? "Unsaved edits" : "Saved project"} · revision{" "}
                    {p.revision}
                  </strong>
                  <button
                    disabled={projects.busy}
                    onClick={async () => {
                      if (
                        !dirty ||
                        window.confirm("Discard your unsaved edits and reload?")
                      ) {
                        const latest = await projects.reload();
                        if (latest)
                          setDraft(
                            latest.projects.find((q) => q.id === id) || null,
                          );
                      }
                    }}
                  >
                    Reload saved version
                  </button>
                </div>
                <fieldset disabled={projects.busy} className="ideas-form">
                  <label className="ideas-full">
                    Project title
                    <input
                      maxLength={120}
                      value={p.title}
                      onChange={(e) =>
                        setDraft({ ...p, title: e.target.value })
                      }
                    />
                  </label>
                  <label className="ideas-full">
                    Opening hook
                    <textarea
                      maxLength={300}
                      value={p.hook}
                      onChange={(e) => setDraft({ ...p, hook: e.target.value })}
                    />
                  </label>
                </fieldset>
                <h3>Your storyboard</h3>
                <div className="project-shots">
                  {p.shots.map((s, i) => (
                    <article key={s.id}>
                      <span className="date-label">
                        SHOT {i + 1} · {p.progress[i]}
                      </span>
                      <h3>{s.title}</h3>
                      <div className="ideas-actions">
                        <button
                          aria-label={`Move shot ${i + 1} earlier`}
                          disabled={projects.busy || i === 0}
                          onClick={() => {
                            const shots = [...p.shots];
                            [shots[i - 1], shots[i]] = [shots[i], shots[i - 1]];
                            setDraft({
                              ...p,
                              shots,
                              progress: shots.map(
                                (v) =>
                                  p.progress[
                                    p.shots.findIndex((t) => t.id === v.id)
                                  ],
                              ),
                            });
                          }}
                        >
                          ↑ Earlier
                        </button>
                        <button
                          aria-label={`Move shot ${i + 1} later`}
                          disabled={projects.busy || i === p.shots.length - 1}
                          onClick={() => {
                            const shots = [...p.shots];
                            [shots[i + 1], shots[i]] = [shots[i], shots[i + 1]];
                            setDraft({
                              ...p,
                              shots,
                              progress: shots.map(
                                (v) =>
                                  p.progress[
                                    p.shots.findIndex((t) => t.id === v.id)
                                  ],
                              ),
                            });
                          }}
                        >
                          ↓ Later
                        </button>
                        <button
                          aria-label={`Remove shot ${i + 1}`}
                          disabled={projects.busy || p.shots.length <= 3}
                          onClick={() => {
                            const shots = p.shots.filter((_, n) => n !== i);
                            for (let n = 0; n < s.seconds; n++)
                              shots[n % shots.length] = {
                                ...shots[n % shots.length],
                                seconds: shots[n % shots.length].seconds + 1,
                              };
                            setDraft({
                              ...p,
                              shots,
                              progress: p.progress.filter((_, n) => n !== i),
                            });
                          }}
                        >
                          Remove shot
                        </button>
                      </div>
                      <p>{s.action}</p>
                      <fieldset disabled={projects.busy}>
                        <label>
                          Camera angle
                          <input
                            maxLength={180}
                            value={s.angle}
                            onChange={(e) =>
                              setDraft({
                                ...p,
                                shots: p.shots.map((v, n) =>
                                  n === i ? { ...v, angle: e.target.value } : v,
                                ),
                              })
                            }
                          />
                        </label>
                        <label>
                          Suggested seconds
                          <input
                            type="number"
                            min={1}
                            max={60}
                            value={s.seconds}
                            onChange={(e) =>
                              setDraft({
                                ...p,
                                shots: p.shots.map((v, n) =>
                                  n === i
                                    ? { ...v, seconds: Number(e.target.value) }
                                    : v,
                                ),
                              })
                            }
                          />
                        </label>
                        <label>
                          On-screen caption
                          <textarea
                            maxLength={300}
                            value={s.caption}
                            onChange={(e) =>
                              setDraft({
                                ...p,
                                shots: p.shots.map((v, n) =>
                                  n === i
                                    ? { ...v, caption: e.target.value }
                                    : v,
                                ),
                              })
                            }
                          />
                        </label>
                      </fieldset>
                    </article>
                  ))}
                </div>
                <p>
                  Shot budget:{" "}
                  <strong>
                    {p.shots.reduce((n, s) => n + s.seconds, 0)} /{" "}
                    {p.brief.seconds} seconds
                  </strong>
                  . Cooking and waiting time stay unchanged.
                </p>
                <label>
                  Publishing caption
                  <textarea
                    rows={5}
                    maxLength={1800}
                    disabled={projects.busy}
                    value={p.caption}
                    onChange={(e) =>
                      setDraft({ ...p, caption: e.target.value })
                    }
                  />
                </label>
                <div className="ideas-actions">
                  <button
                    className="ideas-primary"
                    disabled={projects.busy}
                    onClick={save}
                  >
                    Save project
                  </button>
                  <button
                    disabled={projects.busy || dirty}
                    onClick={() => router.push(`/shoot?project=${p.id}`)}
                  >
                    Start filming checklist →
                  </button>
                  <button
                    disabled={projects.busy || dirty}
                    onClick={async () => {
                      const r = await projects.run({
                        action: "duplicate",
                        id: p.id,
                        revision: p.revision,
                        requestId: crypto.randomUUID(),
                      });
                      if (r) router.push(`/studio?project=${r.project.id}`);
                    }}
                  >
                    Duplicate project
                  </button>
                </div>
                <p className="ideas-note">
                  Save edits before opening the checklist or duplicating. Change
                  ingredients in Make It Mine, then create a new filming project
                  for that version.
                </p>
              </section>
              <section className="idea-brief">
                <h2>A little help with the story.</h2>
                <p>
                  AI can suggest a hook, framing and captions using this recipe
                  and your filming brief. Recipe quantities and preparation
                  actions remain fixed.
                </p>
                <label>
                  Your direction
                  <textarea
                    maxLength={300}
                    disabled={projects.busy}
                    value={aiNote}
                    onChange={(e) => setAiNote(e.target.value)}
                    placeholder={
                      p.brief.note ||
                      "e.g. More close-ups, a quieter opening, no talking."
                    }
                  />
                </label>
                <button
                  disabled={projects.busy || dirty}
                  onClick={async () => {
                    const r = await projects.run({
                      action: "suggest",
                      id: p.id,
                      revision: p.revision,
                      note: aiNote || p.brief.note,
                    });
                    if (r) setSuggestion(r.suggestion);
                  }}
                >
                  {projects.busy ? "Working…" : "Preview AI suggestions"}
                </button>
                <p className="ideas-note">
                  Save your edits first. If AI cannot connect, the template and
                  saved project remain available.
                </p>
                {suggestion && (
                  <div className="ai-candidate">
                    <h3>Suggested opening</h3>
                    <p>{suggestion.hook}</p>
                    <h3>Suggested captions & camera</h3>
                    {suggestion.shots.map((s, i) => (
                      <p key={s.id}>
                        <strong>Shot {i + 1}:</strong> {s.angle}
                        <br />
                        {s.caption}
                      </p>
                    ))}
                    <p>{suggestion.caption}</p>
                    <div className="ideas-actions">
                      <button
                        onClick={() => {
                          setDraft({
                            ...p,
                            hook: suggestion.hook,
                            caption: suggestion.caption,
                            shots: suggestion.shots,
                          });
                          setSuggestion(null);
                        }}
                      >
                        Use suggestion as draft
                      </button>
                      <button onClick={() => setSuggestion(null)}>
                        Keep my current draft
                      </button>
                    </div>
                    <small>
                      Using a suggestion does not save it. Review and save your
                      project.
                    </small>
                  </div>
                )}
              </section>
              <section className="idea-brief">
                <h2>Take the plan with you.</h2>
                <p>
                  Exports contain your current draft, including unsaved edits.
                  They include the recipe and credits, never health records or
                  private chat.
                </p>
                <div className="ideas-actions">
                  <button
                    onClick={() => {
                      download(
                        new Blob([projectText(p)], {
                          type: "text/plain;charset=utf-8",
                        }),
                        `VERIVA-plan-${p.id}.txt`,
                      );
                      void projects.run({
                        action: "event",
                        kind: "plan-exported",
                        subject: p.id,
                      });
                    }}
                  >
                    Download filming plan TXT
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        setExportError("");
                        await storyboard(p);
                        void projects.run({
                          action: "event",
                          kind: "plan-exported",
                          subject: p.id,
                        });
                      } catch (e) {
                        setExportError((e as Error).message);
                      }
                    }}
                  >
                    Download storyboard PNG
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(p.caption);
                        notify("Caption copied.");
                      } catch {
                        setExportError(
                          "Clipboard unavailable. Select and copy the caption above.",
                        );
                      }
                    }}
                  >
                    Copy caption
                  </button>
                </div>
              </section>
              <section className="idea-brief">
                <h2>From your story to their breakfast.</h2>
                <p>
                  Keep the original creator credited. Invite viewers to try the
                  recipe and make a version of their own.
                </p>
                <div className="ideas-actions">
                  <Link
                    href={`/studio?${mealQuery({ ...p.meal, shareId: p.sourceShare })}`}
                  >
                    Open recipe sharing & poster tools →
                  </Link>
                  <Link
                    href={`/lab?${mealQuery({ ...p.meal, shareId: p.sourceShare })}`}
                  >
                    Make another recipe variation →
                  </Link>
                  {p.meal.products.map((id) => {
                    const product = products.find((v) => v.id === id);
                    return product ? (
                      <Link key={id} href={`/products/${id}`}>
                        {product.name} →
                      </Link>
                    ) : null;
                  })}
                </div>
                <p className="ideas-note">
                  Sharing tools use the currently available source recipe.
                  Review it before publishing if it changed since this project
                  was saved. This local app needs public hosting for
                  cross-device links.
                </p>
              </section>
            </>
          )}
        </>
      )}
    </Frame>
  );
}

export function MyCreations() {
  const { data } = useStore();
  const { value, error, loading, busy, run } = useProjects(),
    router = useRouter();
  return (
    <Frame title="Your stories, ready when you are.">
      <p className="ideas-lead">
        Separate projects for every idea, even when they start with the same
        breakfast.
      </p>
      <Link className="ideas-primary" href="/ideas">
        Find a new video idea →
      </Link>
      <ErrorNote text={error} />
      {!!data.state.growth?.kitDrafts?.length && (
        <details className="ideas-recipe">
          <summary>Bring a classic content kit into a new project</summary>
          <p>
            Your original kit stays unchanged. Its hook and caption will be
            imported into a new recipe-linked storyboard.
          </p>
          {data.state.growth.kitDrafts.map((k) => (
            <p key={k.mealId}>
              <Link
                href={`/ideas?recipe=${encodeURIComponent(k.mealId)}&idea=quiet-morning&import=1`}
              >
                {k.kit.title} · Import copy →
              </Link>
            </p>
          ))}
        </details>
      )}
      {loading ? (
        <p>Loading projects…</p>
      ) : !value.projects.length ? (
        <p>No projects yet. Choose a card and start your first filming plan.</p>
      ) : (
        <div className="ideas-grid creations-grid">
          {value.projects.map((p) => (
            <article className="idea-card" key={p.id}>
              <img
                src={p.meal.image}
                alt="Illustrative breakfast serving"
                width={400}
                height={260}
                loading="lazy"
              />
              <div className="idea-card-body">
                <span className="date-label">
                  {ideaTemplates.find((t) => t.id === p.ideaId)?.title}
                </span>
                <h2>{p.title}</h2>
                <p>{p.meal.name}</p>
                {p.ideaId === "series" && (
                  <p>
                    Series: {p.brief.seriesTitle || "My breakfast series"} ·
                    Episode {p.brief.episode}
                  </p>
                )}
                <p>
                  {p.progress.filter((s) => s === "captured").length} /{" "}
                  {p.shots.length} shots marked captured
                </p>
                <small>
                  Updated {new Date(p.updatedAt).toLocaleDateString("en-GB")}
                </small>
                <div className="ideas-actions">
                  <Link href={`/studio?project=${p.id}`}>
                    Continue editing →
                  </Link>
                  <Link href={`/shoot?project=${p.id}`}>Film →</Link>
                  <button
                    disabled={busy}
                    onClick={async () => {
                      if (
                        window.confirm(
                          "Delete this filming project? Your recipe stays saved.",
                        )
                      )
                        await run({
                          action: "delete",
                          id: p.id,
                          revision: p.revision,
                        });
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
      <section className="idea-brief">
        <h2>Your local creative activity</h2>
        <p>
          These are actions recorded in this workspace, not audience reach,
          verified videos or sales.
        </p>
        <div className="ideas-actions">
          {value.events.map((e) => (
            <span key={e.kind}>
              {e.kind}: {e.count}
            </span>
          ))}
        </div>
        <button onClick={() => router.push("/my-breakfast")}>
          Back to My Breakfast →
        </button>
      </section>
    </Frame>
  );
}
