"use client";
import Link from "next/link";
import { useState, type CSSProperties } from "react";
import { CheckIcon, SparkleIcon, ArrowRightIcon } from "@phosphor-icons/react";
import { recipeMethods } from "@/lib/recipe-methods";
import type { Recipe } from "@/lib/catalog";
import { Button } from "./ui";

export function CookingPhoto({
  recipeId,
  panel,
  alt,
  className = "",
}: {
  recipeId: string;
  panel: 0 | 1 | 2;
  alt: string;
  className?: string;
}) {
  return (
    <div
      className={`cooking-photo ${className}`}
      style={{ "--photo-panel": panel } as CSSProperties}
    >
      <img
        src={`/images/cooking/${recipeId}.webp`}
        alt={alt}
        loading="lazy"
        width={2172}
        height={724}
      />
    </div>
  );
}

export function CookingGuide({
  recipe,
  revisionInstructions = [],
}: {
  recipe: Recipe;
  revisionInstructions?: string[];
}) {
  const method = recipeMethods[recipe.id];
  const [completed, setCompleted] = useState<number[]>([]);
  const stages = [
    {
      name: "01 · Prepare",
      note: "Measure, wash and bring your ingredients together.",
      alt: "ingredient preparation",
    },
    {
      name: "02 · Make",
      note: "A little stirring, a gentle heat, or time to rest.",
      alt: "preparation process",
    },
    {
      name: "03 · Serve",
      note: "Add the finishing touches and enjoy your bowl.",
      alt: "finished serving",
    },
  ];
  return (
    <section
      className="cooking-guide"
      id="method"
      aria-labelledby="cooking-heading"
    >
      <div className="cooking-heading">
        <h2 id="cooking-heading">
          From the first ingredient to the final spoonful.
        </h2>
        <p>
          {method.name} · {method.equipment}
        </p>
        <p>{method.waiting}</p>
        <span role="status">
          {completed.length}/{method.steps.length} steps complete
        </span>
        <p className="asset-note">
          AI-generated images illustrate the base recipe. Your current written
          quantities and saved adjustments take priority.
        </p>
      </div>
      {revisionInstructions.length > 0 && (
        <aside className="cooking-revision">
          <h3>
            <SparkleIcon size={20} />
            Your saved method adjustment
          </h3>
          <ol>
            {revisionInstructions.map((text, i) => (
              <li key={i}>{text}</li>
            ))}
          </ol>
        </aside>
      )}
      <div className="cooking-stages">
        {stages.map((stage, index) => (
          <article className="cooking-stage" key={stage.name}>
            <CookingPhoto
              recipeId={recipe.id}
              panel={index as 0 | 1 | 2}
              alt={`${method.name} ${stage.alt}`}
            />
            <div>
              <h3>{stage.name}</h3>
              <p className="cooking-stage-note">{stage.note}</p>
              <ol start={index * 2 + 1}>
                {method.steps
                  .slice(index * 2, index * 2 + 2)
                  .map((text, offset) => {
                    const step = index * 2 + offset;
                    const done = completed.includes(step);
                    return (
                      <li key={step}>
                        <button
                          type="button"
                          className={
                            done ? "cooking-check done" : "cooking-check"
                          }
                          aria-label={`Mark detailed step ${step + 1}${done ? " incomplete" : " complete"}`}
                          aria-pressed={done}
                          onClick={() =>
                            setCompleted((current) =>
                              done
                                ? current.filter((s) => s !== step)
                                : [...current, step],
                            )
                          }
                        >
                          {done ? <CheckIcon size={17} /> : step + 1}
                        </button>
                        <p>{text}</p>
                      </li>
                    );
                  })}
              </ol>
            </div>
          </article>
        ))}
      </div>
      <div className="cooking-tips">
        <div>
          <h3>A few helpful details</h3>
          {method.tips.map((tip) => (
            <p key={tip}>{tip}</p>
          ))}
        </div>
        <div>
          <h3>At the breakfast table</h3>
          <p>{method.serving}</p>
          <Button variant="secondary" asChild>
            <Link href={`/chat?recipe=${recipe.id}`}>
              Talk through this recipe with AI <ArrowRightIcon size={17} />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
