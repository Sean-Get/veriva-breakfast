"use client";
import Link from "next/link";
import { FactoryEvidence } from "./factory-evidence";
import { useEffect, useState } from "react";
import {
  ArrowRightIcon,
  ArrowLeftIcon,
  ArrowUpRightIcon,
  ArrowsOutIcon,
  LeafIcon,
  PackageIcon,
  PlantIcon,
  MapPinIcon,
  BookOpenIcon,
  DownloadSimpleIcon,
  CheckIcon,
  SparkleIcon,
  UserIcon,
  ChatCircleDotsIcon,
  SlidersHorizontalIcon,
  ShieldCheckIcon,
} from "@phosphor-icons/react";
import { Button, Modal, cn } from "./ui";
const photographs = [
  {
    src: "/images/factory-exterior.webp",
    title: "At home in the Alps.",
    label: "The factory",
    location: "Langkampfen, Tyrol",
    alt: "Verival production building and Bio Shop surrounded by the Tyrolean mountains",
    text: "A look at Verival’s home in Langkampfen, where its breakfast products are made and packed.",
    icon: MapPinIcon,
  },
  {
    src: "/images/factory-production.webp",
    title: "Packed by people who care.",
    label: "The people",
    location: "Packing & dispatch",
    alt: "A Verival team member packing a porridge product by hand in the warehouse",
    text: "A real face behind the breakfast. The official brand photographs show the care taken in packing each order.",
    icon: PackageIcon,
  },
  {
    src: "/images/factory-fields.webp",
    title: "It starts with the ingredients.",
    label: "The ingredients",
    location: "Organic farming",
    alt: "Organic farmland featured on Verival’s official website",
    text: "The journey starts with organic ingredients. Verival describes working with small farming partners and selecting its raw materials carefully.",
    icon: PlantIcon,
  },
];
export function FactoryFeature() {
  return (
    <section
      className="factory-feature"
      aria-labelledby="factory-feature-title"
    >
      <Link
        className="factory-feature-photo"
        href="/factory"
        aria-label="Explore the factory photo story"
      >
        <img
          src={photographs[0].src}
          alt={photographs[0].alt}
          width={1000}
          height={1000}
          loading="lazy"
        />
        <span className="photo-label">
          <MapPinIcon size={15} />
          Langkampfen, Austria
        </span>
        <span className="photo-open">
          <ArrowUpRightIcon size={24} />
        </span>
      </Link>
      <div className="factory-feature-copy">
        <span className="date-label">BEHIND YOUR BREAKFAST</span>
        <h2>
          A little closer
          <br />
          to where it begins.
        </h2>
        <p>
          From the Tyrolean mountains to the people packing your porridge. Take
          a look behind the breakfast.
        </p>
        <div className="factory-feature-detail">
          <img
            src={photographs[1].src}
            alt="A member of the Verival packing team"
            width={1000}
            height={1072}
            loading="lazy"
          />
          <div>
            <LeafIcon size={22} />
            <strong>Good food has a story.</strong>
            <span>Real photographs. A closer look.</span>
          </div>
        </div>
        <Button asChild variant="dark">
          <Link href="/factory">
            Step inside the photo story
            <ArrowRightIcon size={18} />
          </Link>
        </Button>
      </div>
    </section>
  );
}
export function MorningPath() {
  return (
    <section className="morning-path" aria-label="Your breakfast journey">
      <div className="morning-path-label">
        <span className="date-label">YOUR MORNING, MADE SIMPLE</span>
        <strong>
          A small step.
          <br />A better breakfast.
        </strong>
        <Link href="/expert">
          Meet your breakfast expert
          <ArrowUpRightIcon size={15} />
        </Link>
      </div>
      {[
        {
          number: "01",
          title: "Start with you",
          text: "A few preferences make it personal.",
          href: "/profile",
          icon: UserIcon,
        },
        {
          number: "02",
          title: "Find your bowl",
          text: "Discover recipes that fit your day.",
          href: "/recipes",
          icon: BookOpenIcon,
        },
        {
          number: "03",
          title: "Make it yours",
          text: "Ask, taste, and tell us what you love.",
          href: "/chat",
          icon: SparkleIcon,
        },
      ].map((s) => (
        <Link href={s.href} key={s.number} className="morning-path-step">
          <div>
            <span>{s.number}</span>
            <s.icon size={23} />
          </div>
          <h3>{s.title}</h3>
          <p>{s.text}</p>
          <ArrowUpRightIcon className="path-arrow" size={18} />
        </Link>
      ))}
    </section>
  );
}
export function FactoryPage() {
  const [selected, setSelected] = useState(0),
    [expanded, setExpanded] = useState(false);
  const photo = photographs[selected];
  const move = (amount: number) =>
    setSelected((i) => (i + amount + photographs.length) % photographs.length);
  useEffect(() => {
    if (!expanded) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        move(-1);
      }
      if (e.key === "ArrowRight") {
        e.preventDefault();
        move(1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [expanded]);
  return (
    <main className="main factory-page">
      <Link href="/" className="back-link">
        <ArrowLeftIcon size={17} />
        Back to your morning
      </Link>
      <div className="factory-heading">
        <div>
          <span className="date-label">A PHOTO STORY FROM TYROL</span>
          <h1>
            Every bowl
            <br />
            begins somewhere<span>.</span>
          </h1>
        </div>
        <p>
          Meet the place, the people and the ingredients behind Verival’s
          breakfast. Slow down. Take a closer look.
        </p>
      </div>
      <section className="factory-gallery" aria-label="Factory photo gallery">
        <div className="factory-main-photo">
          <button
            onClick={() => setExpanded(true)}
            aria-label={`View full image: ${photo.label}`}
          >
            <img
              key={photo.src}
              src={photo.src}
              alt={photo.alt}
              width={1000}
              height={1000}
              fetchPriority="high"
            />
            <span className="photo-label">
              <photo.icon size={17} />
              {photo.location}
            </span>
            <span className="expand-photo">
              <ArrowsOutIcon size={19} />
              View full image
            </span>
          </button>
          <div className="gallery-bottom">
            <span>
              0{selected + 1} <small>/ 03</small>
            </span>
            <p>{photo.label} · Official brand photograph</p>
            <div>
              <button
                className="icon-button"
                onClick={() => move(-1)}
                aria-label="Previous photograph"
              >
                <ArrowLeftIcon size={20} />
              </button>
              <button
                className="icon-button"
                onClick={() => move(1)}
                aria-label="Next photograph"
              >
                <ArrowRightIcon size={20} />
              </button>
            </div>
          </div>
        </div>
        <aside className="factory-caption" key={selected}>
          <span className="date-label">{photo.label.toUpperCase()}</span>
          <h2>{photo.title}</h2>
          <p>{photo.text}</p>
          <div
            className="gallery-thumbnails"
            role="group"
            aria-label="Choose a photograph"
          >
            {photographs.map((p, i) => (
              <button
                className={cn(
                  "gallery-thumbnail",
                  selected === i && "selected",
                )}
                key={p.src}
                onClick={() => setSelected(i)}
                aria-pressed={selected === i}
                aria-label={`Show ${p.label.toLowerCase()}`}
              >
                <img src={p.src} alt="" width={110} height={110} />
                <span>0{i + 1}</span>
              </button>
            ))}
          </div>
          <p className="small-note">
            Tap the large photograph to see the complete image. Use the arrows
            to explore all three views.
          </p>
          <a
            className="subtle-link"
            href="https://www.verival.at/en/pages/ueber-uns"
            target="_blank"
            rel="noreferrer"
          >
            Read the official brand story
            <ArrowUpRightIcon size={17} />
          </a>
        </aside>
      </section>
      <FactoryEvidence />
      <section className="factory-source">
        <ShieldCheckIcon size={28} />
        <div>
          <h3>A transparent look, with a clear source.</h3>
          <p>
            Photographs © Verival, shown with source links for this student
            project. This is a photo gallery, not a live factory feed or an
            on-site inspection.
          </p>
        </div>
        <Link className="subtle-link" href="/story">
          More of the story
          <ArrowRightIcon size={17} />
        </Link>
      </section>
      <Modal
        open={expanded}
        onOpenChange={setExpanded}
        title={photo.title}
        description={`${selected + 1} of ${photographs.length} · Official Verival photograph. Arrow keys switch photographs; Escape closes the viewer.`}
        className="photo-lightbox"
      >
        <div className="lightbox-image">
          <img src={photo.src} alt={photo.alt} width={1000} height={1072} />
        </div>
        <div className="lightbox-controls">
          <Button variant="secondary" size="small" onClick={() => move(-1)}>
            <ArrowLeftIcon size={18} />
            Previous
          </Button>
          <a href={photo.src} target="_blank" rel="noreferrer">
            Open original
            <ArrowUpRightIcon size={16} />
          </a>
          <Button variant="secondary" size="small" onClick={() => move(1)}>
            Next
            <ArrowRightIcon size={18} />
          </Button>
        </div>
        <small className="small-note">
          © Verival · Source: official brand story
        </small>
      </Modal>
    </main>
  );
}
const steps = [
  {
    title: "先让早餐认识你",
    tag: "01 / 个人资料",
    icon: UserIcon,
    href: "/profile",
    cta: "设置我的早餐偏好",
    text: "填写昵称、目标、饮食排除、准备时间和活动水平。健康记录可选；只有勾选授权才会传给 DeepSeek。",
    tasks: [
      "完成三步问卷，可随时返回修改。",
      "可选填年龄、身高、体重和早餐备注。",
      "保存后会自动生成新的 AI 早餐推荐。",
    ],
    check: "回到首页，确认推荐理由能反映刚刚保存的目标。",
    image: "/images/overnight.webp",
  },
  {
    title: "找到今天想吃的一碗",
    tag: "02 / 推荐与食谱",
    icon: BookOpenIcon,
    href: "/recipes",
    cta: "浏览早餐食谱",
    text: "首页是你的每日起点；食谱库提供搜索、分类、收藏及符合偏好筛选。每道早餐都有用量、营养估值和制作步骤。",
    tasks: [
      "用 berry 搜索，或切换早餐分类。",
      "点击心形收藏喜欢的食谱。",
      "进入详情，勾选已准备食材和已完成步骤。",
    ],
    check: "在 You 中找到刚收藏的食谱；刷新页面后仍然保留。",
    image: "/images/breakfast-hero.webp",
  },
  {
    title: "和早餐专家聊一聊",
    tag: "03 / 个性化聊天",
    icon: ChatCircleDotsIcon,
    href: "/chat",
    cta: "打开早餐专家",
    text: "聊天会结合最新资料、授权健康记录、近期反馈和当前食谱。可以用中文或英文提问。",
    tasks: [
      "试问：“按我的目标推荐一个 5 分钟早餐。”",
      "从食谱详情点击 Make this recipe yours，讨论当前食谱。",
      "修改资料后，再问同样的问题，观察回复如何变化。",
    ],
    check: "模型依据当前保存资料回答。这里是上下文个性化，并未单独训练模型。",
    image: "/images/chia.webp",
  },
  {
    title: "告诉 AI，下一次更合口味",
    tag: "04 / 实时反馈",
    icon: SlidersHorizontalIcon,
    href: "/recipes/berry-oats",
    cta: "试试反馈调整",
    text: "在食谱详情点击 Leave feedback，选择标签或填写中文备注。提交后 AI 会修改食谱，而不只是记录评分。",
    tasks: [
      "选择 Too sweet、Too bland、Too thick 或 Too thin。",
      "等待 AI 调整完成，点击 See my revised recipe。",
      "查看用量前后对比和新步骤，再刷新确认保存。",
    ],
    check:
      "太甜会降低甜味食材用量；太稠/太稀会调整液体或基底比例；太淡会改变已有食材的处理方式。",
    image: "/images/banana.webp",
  },
  {
    title: "看看早餐从哪里来",
    tag: "05 / 工厂图片",
    icon: PlantIcon,
    href: "/factory",
    cta: "参观工厂图片展",
    text: "从首页工厂卡片进入，查看奥地利厂房、包装人员及种植图片。每张照片都可以完整放大查看。",
    tasks: [
      "点击缩略图或左右箭头切换照片。",
      "点击大图，查看没有裁切的完整照片。",
      "用左右方向键切换，用 Esc 关闭。",
    ],
    check: "图片来自 Verival 官方页面；这里展示照片，不提供实时工厂监控。",
    image: "/images/factory-exterior.webp",
  },
  {
    title: "让小组看到真实用户记录",
    tag: "06 / 管理后台",
    icon: ShieldCheckIcon,
    href: "/admin",
    cta: "打开管理后台",
    text: "管理员输入本机口令后，可以查看所有注册用户与访客的基本信息、早餐偏好和功能使用次数。",
    tasks: [
      "从本机 output/后台访问说明.txt 读取管理口令。",
      "使用昵称或邮箱搜索，并切换注册用户/访客筛选。",
      "刷新查看最新记录，演示结束后退出后台。",
    ],
    check:
      "普通用户会话不能读取后台 API；后台仅展示基本信息与统计，不展示健康备注或对话正文。",
    image: "/images/factory-production.webp",
  },
];
export function GuidePage() {
  const [step, setStep] = useState(0),
    active = steps[step];
  return (
    <main className="main guide-page">
      <Link className="back-link" href="/">
        <ArrowLeftIcon size={17} />
        回到首页
      </Link>
      <div className="guide-heading">
        <span className="date-label">A LITTLE GUIDE TO YOUR MORNINGS</span>
        <h1>
          从第一碗开始，
          <br />
          一起走一遍<span>。</span>
        </h1>
        <p>六个步骤，了解 VERIVA 的主要功能。可随时跳到想体验的部分。</p>
        <a
          className="button button-secondary"
          href="/VERIVA-用户引导手册.md"
          download
        >
          <DownloadSimpleIcon size={18} />
          下载完整使用手册
        </a>
      </div>
      <section className="guide-walkthrough" aria-label="六步使用引导">
        <nav className="guide-step-list" aria-label="引导步骤">
          {steps.map((s, i) => (
            <button
              key={s.tag}
              aria-pressed={step === i}
              className={cn(step === i && "selected")}
              onClick={() => setStep(i)}
            >
              <span>{i + 1}</span>
              <div>
                <small>{s.tag.split(" / ")[1]}</small>
                <strong>{s.title}</strong>
              </div>
              {step === i ? <ArrowRightIcon size={18} /> : null}
            </button>
          ))}
        </nav>
        <article className="guide-step-content" key={step}>
          <div className="guide-step-banner">
            <img src={active.image} alt="" width={1000} height={700} />
            <span>
              <active.icon size={25} />
              {active.tag}
            </span>
          </div>
          <div className="guide-step-body">
            <span className="date-label">STEP {step + 1} OF 6</span>
            <h2>{active.title}</h2>
            <p>{active.text}</p>
            <ol>
              {active.tasks.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ol>
            <div className="guide-check">
              <CheckIcon size={21} />
              <p>{active.check}</p>
            </div>
            <Button asChild>
              <Link href={active.href}>
                {active.cta}
                <ArrowUpRightIcon size={18} />
              </Link>
            </Button>
          </div>
        </article>
      </section>
      <div className="guide-pagination">
        <Button
          variant="secondary"
          disabled={step === 0}
          onClick={() => setStep((s) => s - 1)}
        >
          <ArrowLeftIcon size={18} />
          上一步
        </Button>
        <span>{step + 1} / 6</span>
        <Button
          variant="secondary"
          disabled={step === 5}
          onClick={() => setStep((s) => s + 1)}
        >
          下一步
          <ArrowRightIcon size={18} />
        </Button>
      </div>
      <section className="guide-extra">
        <div>
          <span className="date-label">THE REST OF YOUR MORNING</span>
          <h2>还有这些小功能。</h2>
          <p>完整手册包含启动、账号、演示流程和常见问题。</p>
        </div>
        <div>
          <details>
            <summary>商城和购物篮怎么用？</summary>
            <p>
              Shop 中可以筛选、收藏商品并加入购物篮；Basket
              中可改数量、移除商品并提交演示订单。没有真实扣款和物流服务。
            </p>
            <Link href="/shop">
              打开 Shop
              <ArrowRightIcon size={16} />
            </Link>
          </details>
          <details>
            <summary>资料保存了，但 AI 没有更新？</summary>
            <p>
              界面会保留资料并显示失败状态。检查 API
              配置、网络或调用额度后，点击提示里的重试按钮。不会把失败显示成已成功调整。
            </p>
          </details>
          <details>
            <summary>如何在课堂上快速演示？</summary>
            <p>
              先建一个演示账号，设置少糖目标；查看推荐，向 AI
              提问；对莓果燕麦提交太甜反馈，展示克数变化；最后打开工厂图片与管理后台。完整手册附有约
              5 分钟的讲解脚本。
            </p>
          </details>
          <details>
            <summary>用户数据保存在什么地方？</summary>
            <p>
              当前运行目录
              data/veriva.sqlite。源码开发和独立运行包可以使用不同数据库；管理后台只统计当前启动服务所连接的数据。交付
              ZIP 不含用户数据或管理口令。
            </p>
          </details>
        </div>
      </section>
    </main>
  );
}
