"use client";
import { usePathname } from "next/navigation";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
  type ReactNode,
} from "react";
import { defaultState, type AppData, type UserState } from "@/lib/types";
type Store = {
  data: AppData;
  ready: boolean;
  error: string;
  busy: boolean;
  refresh: () => Promise<void>;
  mutate: (body: Record<string, unknown>) => Promise<UserState>;
  notify: (text: string) => void;
  toast: string;
  authOpen: boolean;
  setAuthOpen: (v: boolean) => void;
};
const Context = createContext<Store | null>(null);
export async function api(url: string, body?: Record<string, unknown>) {
  const response = await fetch(url, {
    method: body ? "POST" : "GET",
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Please try again.");
  return result;
}
export function StoreProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [data, setData] = useState<AppData>({
    user: { id: "", name: "Friend", email: null, guest: true },
    state: defaultState(),
    aiConfigured: false,
    community: [],
  });
  const [ready, setReady] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [toast, setToast] = useState(""),
    [authOpen, setAuthOpen] = useState(false);
  const refresh = useCallback(async () => {
    let next = await api("/api/state");
    if (!next.user) {
      await api("/api/auth", { action: "guest" });
      next = await api("/api/state");
    }
    setData(next);
    setReady(true);
    setError("");
  }, []);
  const started = useRef(false);
  useEffect(() => {
    if (pathname === "/admin") return;
    if (started.current) return;
    started.current = true;
    refresh().catch((e) => {
      setError(e.message);
      setReady(true);
    });
  }, [refresh, pathname]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 4000);
    return () => clearTimeout(t);
  }, [toast]);
  const mutate = async (body: Record<string, unknown>) => {
    setBusy(true);
    try {
      const result = await api("/api/state", body);
      setData((d) => ({
        ...d,
        state: result.state,
        user: { ...d.user, name: result.state.profile.name },
      }));
      return result.state as UserState;
    } finally {
      setBusy(false);
    }
  };
  return (
    <Context
      value={{
        data,
        ready,
        error,
        busy,
        refresh,
        mutate,
        notify: setToast,
        toast,
        authOpen,
        setAuthOpen,
      }}
    >
      {children}
    </Context>
  );
}
export function useStore() {
  const s = useContext(Context);
  if (!s) throw new Error("Missing store");
  return s;
}
