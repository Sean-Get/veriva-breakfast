"use client";
import {
  LazyMotion,
  domAnimation,
  MotionConfig,
  m,
  useReducedMotion,
  AnimatePresence,
} from "motion/react";
import { useState, type ReactNode } from "react";
import { Modal } from "./ui";
export function MotionProvider({ children }: { children: ReactNode }) {
  return (
    <LazyMotion features={domAnimation} strict>
      <MotionConfig reducedMotion="user">{children}</MotionConfig>
    </LazyMotion>
  );
}
export function Reveal({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const reduced = useReducedMotion();
  return (
    <m.div
      className={className}
      initial={reduced ? false : { opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: reduced ? 0 : 0.25, ease: [0.23, 1, 0.32, 1] }}
    >
      {children}
    </m.div>
  );
}
export function AnimatedNotice({ text }: { text: string }) {
  return (
    <AnimatePresence initial={false}>
      {text && (
        <m.div
          key={text}
          className="toast"
          role="status"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
        >
          {text}
        </m.div>
      )}
    </AnimatePresence>
  );
}
export function PhotoLightbox({
  src,
  alt,
  children,
  className = "",
}: {
  src: string;
  alt: string;
  children?: ReactNode;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        className={`photo-open ${className}`}
        aria-label={`Enlarge ${alt}`}
        onClick={() => setOpen(true)}
      >
        {children || <img src={src} alt={alt} width={900} height={900} />}
        <span>View photo ↗</span>
      </button>
      <Modal
        open={open}
        onOpenChange={setOpen}
        title={alt}
        description="Illustrative breakfast photography."
        className="breakfast-lightbox"
      >
        <img src={src} alt={alt} width={1536} height={1024} />
      </Modal>
    </>
  );
}
