"use client";
import {
  LazyMotion,
  domMax,
  MotionConfig,
  m,
  useReducedMotion,
  AnimatePresence,
} from "motion/react";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useId,
  useState,
  type ReactNode,
} from "react";
import { Modal } from "./ui";
export function SelectionTabs({
  items,
  selected,
  onChange,
  label,
  trailing,
}: {
  items: { value: string; label: string }[];
  selected: string;
  onChange: (value: string) => void;
  label: string;
  trailing?: ReactNode;
}) {
  const { off } = useNatureMotion();
  const indicatorId = useId();
  return (
    <div
      className="category-row selection-tabs"
      role="group"
      aria-label={label}
    >
      {items.map((item) => (
        <m.button
          type="button"
          key={item.value}
          className={`selection-tab ${selected === item.value ? "selected" : ""}`}
          aria-pressed={selected === item.value}
          onClick={() => onChange(item.value)}
          whileTap={off ? undefined : { scale: 0.96 }}
        >
          {selected === item.value && (
            <m.span
              className="selection-tab-indicator"
              aria-hidden="true"
              layoutId={off ? undefined : indicatorId}
              transition={{ type: "spring", stiffness: 420, damping: 34 }}
            />
          )}
          <span>{item.label}</span>
        </m.button>
      ))}
      {trailing}
    </div>
  );
}
const NatureMotionContext = createContext({
  off: false,
  reduced: false,
  toggle: () => {},
});
export function useNatureMotion() {
  return useContext(NatureMotionContext);
}
export function MotionProvider({ children }: { children: ReactNode }) {
  const reduced = useReducedMotion() === true;
  const [paused, setPaused] = useState(false);
  const off = paused || reduced;
  useEffect(() => {
    try {
      setPaused(localStorage.getItem("veriva-nature-motion") === "off");
    } catch {}
  }, []);
  useEffect(() => {
    document.documentElement.dataset.pastoralMotion = off ? "off" : "on";
  }, [off]);
  function toggle() {
    if (reduced) return;
    const next = !paused;
    setPaused(next);
    try {
      localStorage.setItem("veriva-nature-motion", next ? "off" : "on");
    } catch {}
  }
  return (
    <LazyMotion features={domMax} strict>
      <NatureMotionContext.Provider value={{ off, reduced, toggle }}>
        <MotionConfig reducedMotion={off ? "always" : "user"}>
          {children}
        </MotionConfig>
      </NatureMotionContext.Provider>
    </LazyMotion>
  );
}
export function Reveal({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const { off } = useNatureMotion();
  const node = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const element = node.current;
    if (off || !element || typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    if (element.getBoundingClientRect().top < window.innerHeight) {
      setVisible(true);
      return;
    }
    setVisible(false);
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "0px 0px 40px 0px" },
    );
    observer.observe(element);
    return () => {
      observer.disconnect();
    };
  }, [off]);
  return (
    <m.div
      ref={node}
      className={className}
      initial={false}
      animate={{ opacity: off || visible ? 1 : 0, y: off || visible ? 0 : 12 }}
      transition={{ duration: off ? 0 : 0.45, ease: [0.23, 1, 0.32, 1] }}
    >
      {children}
    </m.div>
  );
}
export function AnimatedNotice({ text }: { text: string }) {
  return (
    <AnimatePresence initial={false}>
      {text && (
        <m.div
          key={text}
          className="toast"
          role="status"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
        >
          {text}
        </m.div>
      )}
    </AnimatePresence>
  );
}
export function PhotoLightbox({
  src,
  alt,
  children,
  className = "",
}: {
  src: string;
  alt: string;
  children?: ReactNode;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        className={`photo-open ${className}`}
        aria-label={`Enlarge ${alt}`}
        onClick={() => setOpen(true)}
      >
        {children || <img src={src} alt={alt} width={900} height={900} />}
        <span>View photo ↗</span>
      </button>
      <Modal
        open={open}
        onOpenChange={setOpen}
        title={alt}
        description="Illustrative breakfast photography."
        className="breakfast-lightbox"
      >
        <img src={src} alt={alt} width={1536} height={1024} />
      </Modal>
    </>
  );
}
