"use client";
import type { HealthRecord } from "@/lib/types";
export function HealthFields({
  value,
  onChange,
}: {
  value: HealthRecord;
  onChange: (v: HealthRecord) => void;
}) {
  return (
    <details className="health-fields" open>
      <summary>
        Health records <span>Optional · editable</span>
      </summary>
      <p className="small-note">
        Self-reported information for breakfast context, not a diagnosis or
        medical assessment.
      </p>
      <div className="health-inputs">
        {[
          { key: "age", label: "Age", unit: "years", min: 16, max: 110 },
          { key: "heightCm", label: "Height", unit: "cm", min: 80, max: 250 },
          { key: "weightKg", label: "Weight", unit: "kg", min: 20, max: 350 },
        ].map((f) => (
          <label key={f.key}>
            {f.label} ({f.unit})
            <input
              name={f.key}
              type="number"
              min={f.min}
              max={f.max}
              step={f.key === "age" ? 1 : 0.1}
              inputMode="decimal"
              value={value[f.key as "age" | "heightCm" | "weightKg"] ?? ""}
              onChange={(e) =>
                onChange({
                  ...value,
                  [f.key]:
                    e.target.value === "" ? null : Number(e.target.value),
                })
              }
            />
          </label>
        ))}
      </div>
      <label>
        Health & breakfast notes
        <textarea
          name="health-notes"
          rows={3}
          maxLength={500}
          value={value.notes}
          onChange={(e) => onChange({ ...value, notes: e.target.value })}
          placeholder="For example: I prefer warm breakfasts and smaller portions…"
        />
      </label>
      <label className="health-consent">
        <input
          type="checkbox"
          checked={value.useForAI}
          onChange={(e) => onChange({ ...value, useForAI: e.target.checked })}
        />
        <span>
          Use these records and their recent history for AI recommendations and
          breakfast chat. This sends them to DeepSeek. Turning this off and
          saving clears previous chat and AI recipe revisions that may contain
          these records.
        </span>
      </label>
      {!value.useForAI ? (
        <p className="small-note">
          Records are saved locally but excluded from AI requests. General
          profile preferences still personalise your breakfast.
        </p>
      ) : null}
    </details>
  );
}
