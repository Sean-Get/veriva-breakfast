"use client";
import { useRef, useState } from "react";
import { demoArea, demoPlaces, demoItems } from "@/lib/buying-demo";
import { DemoBuyingMap } from "./demo-buying-map";
import { Button } from "./ui";
import { api, useStore } from "./store";
import {
  buyingSources,
  sourceChecked,
  officialStockists,
  officialShipping,
  amapSearch,
  mapEmbed,
  osmPlace,
  directions,
  retailSearch,
  type Point,
  type Place,
} from "@/lib/buying";
import { products } from "@/lib/catalog";
import "./where-to-buy.css";
type Area = Point & { label: string };
const chineseSearch = (name: string) =>
  /chia/i.test(name)
    ? "奇亚籽"
    : /oat/i.test(name)
      ? "燕麦片"
      : /muesli|granola/i.test(name)
        ? "混合麦片"
        : /yogurt|yoghurt/i.test(name)
          ? "原味酸奶"
          : /milk|drink/i.test(name)
            ? "牛奶 燕麦饮"
            : /berr/i.test(name)
              ? "新鲜莓果"
              : /banana/i.test(name)
                ? "香蕉"
                : /apple/i.test(name)
                  ? "苹果"
                  : name;
export function WhereToBuy({
  productIds = [],
  ingredients = [],
}: {
  productIds?: string[];
  ingredients?: string[];
}) {
  const { ready } = useStore();
  const requestVersion = useRef(0);
  const [demo, setDemo] = useState(true);
  const [demoPath, setDemoPath] = useState<Place | null>(null);
  const options = [
    ...new Set([
      ...productIds
        .map((id) => products.find((p) => p.id === id)?.name || "")
        .filter(Boolean),
      ...ingredients,
    ]),
  ].slice(0, 18);
  const [item, setItem] = useState(options[0] || "Breakfast ingredients"),
    [area, setArea] = useState(demoArea.label),
    [candidates, setCandidates] = useState<Area[]>([]),
    [centre, setCentre] = useState<Area | null>(demoArea),
    [selected, setSelected] = useState<Place | null>(null),
    [places, setPlaces] = useState<Place[]>(demoPlaces(2000, "groceries")),
    [radius, setRadius] = useState(2000),
    [category, setCategory] = useState("groceries"),
    [busy, setBusy] = useState(false),
    [locating, setLocating] = useState(false),
    [error, setError] = useState(""),
    [searched, setSearched] = useState(true),
    [checkedAt, setCheckedAt] = useState("");
  const official = [...new Set(productIds)]
    .map((id) => buyingSources[id])
    .filter(Boolean);
  const currentItem = options.includes(item)
    ? item
    : options[0] || "Breakfast ingredients";
  const product = products.find((p) => p.name === currentItem);
  const query = product
    ? `VERIVAL ${product.name}`
    : chineseSearch(currentItem);
  function switchMode(nextDemo: boolean) {
    requestVersion.current++;
    setDemo(nextDemo);
    setBusy(false);
    setLocating(false);
    setError("");
    setSelected(null);
    setDemoPath(null);
    setCandidates([]);
    setCheckedAt("");
    setCentre(nextDemo ? demoArea : null);
    setArea(nextDemo ? demoArea.label : "");
    setPlaces(nextDemo ? demoPlaces(radius, category) : []);
    setSearched(nextDemo);
  }
  function filterDemo(nextRadius: number, nextCategory: string) {
    setRadius(nextRadius);
    setCategory(nextCategory);
    if (demo) {
      setPlaces(demoPlaces(nextRadius, nextCategory));
      setSelected(null);
      setDemoPath(null);
    }
  }
  async function near(point: Area) {
    const version = ++requestVersion.current;
    setBusy(true);
    setError("");
    setSelected(null);
    setPlaces([]);
    setSearched(false);
    setCentre(point);
    setCandidates([]);
    try {
      const result = await api("/api/places", {
        mode: "nearby",
        lat: point.lat,
        lon: point.lon,
        radius,
        category,
      });
      if (version !== requestVersion.current) return;
      setPlaces(result.places);
      setCheckedAt(result.checkedAt);
      setSearched(true);
    } catch (e) {
      if (version === requestVersion.current) setError((e as Error).message);
    } finally {
      if (version === requestVersion.current) setBusy(false);
    }
  }
  async function search() {
    if (demo) {
      setPlaces(demoPlaces(radius, category));
      setSearched(true);
      setSelected(null);
      setDemoPath(null);
      return;
    }
    if (busy) return;
    if (centre && (!area.trim() || area === centre.label)) {
      await near(centre);
      return;
    }
    if (area.trim().length < 2) {
      setError(
        "Enter a city, district or public landmark, or use your approximate location.",
      );
      return;
    }
    const version = ++requestVersion.current;
    setBusy(true);
    setError("");
    setPlaces([]);
    setCentre(null);
    setSelected(null);
    setSearched(false);
    try {
      const result = await api("/api/places", { mode: "area", area });
      if (version !== requestVersion.current) return;
      setCandidates(result.candidates);
      if (!result.candidates.length)
        setError(
          "No matching area found. Try a city name or continue in Amap.",
        );
    } catch (e) {
      if (version === requestVersion.current) setError((e as Error).message);
    } finally {
      if (version === requestVersion.current) setBusy(false);
    }
  }
  function locate() {
    setError("");
    if (!navigator.geolocation) {
      setError("Location is not supported here. Enter a public area instead.");
      return;
    }
    const version = ++requestVersion.current;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (version !== requestVersion.current) return;
        const point = {
          lat: Number(position.coords.latitude.toFixed(3)),
          lon: Number(position.coords.longitude.toFixed(3)),
          label: "My approximate location",
        };
        setCentre(point);
        setArea(point.label);
        setSelected(null);
        setPlaces([]);
        setCandidates([]);
        setSearched(false);
        setLocating(false);
      },
      () => {
        if (version !== requestVersion.current) return;
        setLocating(false);
        setError(
          "Location was unavailable or not allowed. You can still search by city or public area.",
        );
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 },
    );
  }
  const mapPoint = selected || centre;
  const externalMap = amapSearch(
    `${area && area !== "My approximate location" ? area + " " : ""}${query} 超市`,
    area && area !== "My approximate location" ? area : "",
  );
  return (
    <section
      id="find-buy"
      className="where-to-buy"
      aria-label="Where to find your breakfast"
    >
      <div className="buying-heading">
        <div>
          <span className="date-label">FROM INSPIRATION TO YOUR CUPBOARD</span>
          <h2>Find your breakfast, near and far.</h2>
          <p>
            Explore official online sources or find nearby food shops to ask
            about the ingredients.
          </p>
        </div>
      </div>
      <div className="buying-online" id="online-buying">
        <h3>Online buying options</h3>
        {official.length > 0 ? (
          <div className="buying-sources">
            {official.map((source, index) => (
              <article key={`${source.url}:${index}`}>
                <span className="source-badge">OFFICIAL BRAND WEBSITE</span>
                <h4>{source.name}</h4>
                <p>{source.scope}</p>
                <a href={source.url} target="_blank" rel="noreferrer">
                  View on Verival →
                </a>
                <small>
                  Source page checked {sourceChecked} · Live stock and shipping
                  not checked
                </small>
              </article>
            ))}
          </div>
        ) : (
          <p>
            These are recipe ingredients, rather than a verified ready-made
            product. Choose the exact ingredient and review the seller's label.
          </p>
        )}
        <div className="buying-check">
          <p>
            Compare the real ingredient list, allergen statement, pack size and
            seller. Check any organic certification on the actual pack. Recipe
            suitability does not transfer to a packaged product.
          </p>
          <div>
            <a href={officialStockists} target="_blank" rel="noreferrer">
              Official Verival retail partners →
            </a>
            <a href={officialShipping} target="_blank" rel="noreferrer">
              Check delivery coverage →
            </a>
          </div>
        </div>
        <label>
          Product or ingredient
          <select
            value={
              options.includes(item)
                ? item
                : options[0] || "Breakfast ingredients"
            }
            onChange={(e) => setItem(e.target.value)}
          >
            {options.length ? (
              options.map((value) => <option key={value}>{value}</option>)
            ) : (
              <option>Breakfast ingredients</option>
            )}
          </select>
        </label>
        <div className="buying-external">
          <a href={retailSearch(query, "jd")} target="_blank" rel="noreferrer">
            Search JD →
          </a>
          <a
            href={retailSearch(query, "tmall")}
            target="_blank"
            rel="noreferrer"
          >
            Search Tmall →
          </a>
        </div>
        <p className="small-note">
          Marketplace search results are not verified retailers, quality checks
          or stock confirmations. Official overseas links may not deliver to
          your area.
        </p>
      </div>
      <div className="buying-local">
        <h3>Nearby places to check</h3>
        <div className="buying-mode" role="group" aria-label="Map data mode">
          <button
            type="button"
            aria-pressed={demo}
            onClick={() => switchMode(true)}
          >
            Classroom demo
          </button>
          <button
            type="button"
            aria-pressed={!demo}
            onClick={() => switchMode(false)}
          >
            Live maps
          </button>
        </div>
        <p className="demo-mode-note">
          {demo
            ? "Classroom demo · Fictional shops and sample ingredients. This interactive map works without Internet. Online buying links above are real external searches."
            : "Live search · Mapped listings do not confirm product stock, quality or current opening status."}
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            search();
          }}
        >
          <div className="buying-fields">
            <label>
              {demo ? "Presentation area" : "City, district or public landmark"}
              <input
                readOnly={demo}
                value={area}
                maxLength={80}
                onChange={(e) => {
                  setArea(e.target.value);
                  setCandidates([]);
                }}
                placeholder="For example: Ningbo Tianyi Square"
              />
            </label>
            <label>
              Search radius
              <select
                value={radius}
                onChange={(e) => filterDemo(Number(e.target.value), category)}
              >
                <option value={2000}>2 km</option>
                <option value={5000}>5 km</option>
              </select>
            </label>
            <label>
              Shop type
              <select
                value={category}
                onChange={(e) => filterDemo(radius, e.target.value)}
              >
                <option value="groceries">Food shops & supermarkets</option>
                <option value="organic">Organic-tagged shops</option>
                <option value="fruit">Fruit & vegetable shops</option>
              </select>
            </label>
          </div>
          <div className="buying-buttons">
            <Button type="submit" disabled={!demo && (busy || !ready)}>
              {demo
                ? "Refresh demo shops"
                : busy
                  ? "Searching maps…"
                  : centre
                    ? "Find nearby shops"
                    : "Find an area"}
            </Button>
            {!demo && (
              <Button
                type="button"
                variant="secondary"
                disabled={locating || busy}
                onClick={locate}
              >
                {locating ? "Getting location…" : "Use my approximate location"}
              </Button>
            )}
            {!demo && (
              <a href={externalMap} target="_blank" rel="noreferrer">
                Continue in Amap →
              </a>
            )}
          </div>
        </form>
        {!demo && (
          <p className="small-note">
            Search sends your chosen public area or approximate coordinates to
            OpenStreetMap services. Please do not enter a private home address.
            Location is not saved to your account or sent to AI. Your browser
            asks before using device location.
          </p>
        )}
        {!!candidates.length && (
          <div className="buying-areas">
            <p>Choose the area you mean:</p>
            {candidates.map((candidate, i) => (
              <button
                key={i}
                disabled={busy}
                onClick={() => {
                  setArea(candidate.label);
                  near(candidate);
                }}
              >
                {candidate.label}
              </button>
            ))}
          </div>
        )}
        {error && (
          <p className="buying-error" role="alert">
            {error}
          </p>
        )}
        <div className="buying-map-layout">
          <div className="buying-map">
            {demo ? (
              <DemoBuyingMap
                places={places}
                selected={selected}
                route={demoPath}
                onSelect={(p) => {
                  setSelected(p);
                  if (demoPath) setDemoPath(p);
                }}
              />
            ) : mapPoint ? (
              <>
                <iframe
                  title={
                    selected
                      ? `Map: ${selected.name}`
                      : "Map around your selected area"
                  }
                  src={mapEmbed(mapPoint, Math.min(radius, 2000))}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  allowFullScreen
                />
                <p>
                  {selected ? selected.name : centre?.label} ·{" "}
                  <a href={osmPlace(mapPoint)} target="_blank" rel="noreferrer">
                    Open full map →
                  </a>
                </p>
              </>
            ) : (
              <div className="buying-map-empty">
                <span aria-hidden="true">⌖</span>
                <h4>Your next stop starts here.</h4>
                <p>
                  Choose a public area or use approximate location to load the
                  map.
                </p>
              </div>
            )}
            {!demo && (
              <small>
                Map and place data ©{" "}
                <a
                  href="https://www.openstreetmap.org/copyright"
                  target="_blank"
                  rel="noreferrer"
                >
                  OpenStreetMap contributors
                </a>{" "}
                · Nominatim / Overpass
              </small>
            )}
          </div>
          <div className="buying-places" aria-live="polite">
            {searched && (
              <p>
                {places.length} {demo ? "demo shops" : "mapped shops"} found ·
                nearest first by straight-line distance.{" "}
                {demo
                  ? "Distances are within the fictional campus."
                  : "Coverage may be incomplete."}
              </p>
            )}
            {searched && !places.length && (
              <p>
                No mapped shops were returned in this radius. Try 5 km, another
                shop type, or Amap.
              </p>
            )}
            {places.map((place, index) => (
              <article
                key={place.id}
                className={selected?.id === place.id ? "selected" : ""}
              >
                <h4>
                  {index + 1}. {place.name}
                </h4>
                <p>
                  {place.distance < 1000
                    ? `${place.distance} m`
                    : `${(place.distance / 1000).toFixed(1)} km`}{" "}
                  away · {place.category.replaceAll("_", " ")}
                </p>
                <p>{place.address || "Address not listed; check the map."}</p>
                <span className="source-badge">
                  {demo
                    ? "FICTIONAL SHOP · SAMPLE RANGE"
                    : "PRODUCT STOCK UNKNOWN"}
                </span>
                {demo && <p>{demoItems(place.id)}</p>}
                {place.openingHours && (
                  <p className="small-note">
                    Listed hours (not live): {place.openingHours}
                  </p>
                )}
                <div className="buying-place-actions">
                  <button onClick={() => setSelected(place)}>
                    Show on map
                  </button>
                  {demo && (
                    <>
                      <button
                        onClick={() => {
                          setSelected(place);
                          setDemoPath(place);
                        }}
                      >
                        Preview demo route
                      </button>
                      <button
                        onClick={() => {
                          setSelected(place);
                          document
                            .getElementById("online-buying")
                            ?.scrollIntoView({
                              behavior: window.matchMedia(
                                "(prefers-reduced-motion: reduce)",
                              ).matches
                                ? "instant"
                                : "smooth",
                              block: "start",
                            });
                        }}
                      >
                        View buying options
                      </button>
                    </>
                  )}
                  {!demo && centre && (
                    <a
                      href={directions(centre, place)}
                      target="_blank"
                      rel="noreferrer"
                    >
                      Directions →
                    </a>
                  )}
                  {!demo && (
                    <a
                      href={amapSearch(`${place.name} ${place.address}`)}
                      target="_blank"
                      rel="noreferrer"
                    >
                      Find in Amap →
                    </a>
                  )}
                  {place.website && (
                    <a href={place.website} target="_blank" rel="noreferrer">
                      Listed website →
                    </a>
                  )}
                  {place.phone && <span>Listed phone: {place.phone}</span>}
                </div>
              </article>
            ))}
            {checkedAt && (
              <small>
                Map lookup: {new Date(checkedAt).toLocaleString("en")} · Ask the
                shop before travelling.
              </small>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
