"use client";
import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { usePathname } from "next/navigation";
import {
  ArrowRightIcon,
  HeartIcon,
  ShoppingBagIcon,
  ChatCircleDotsIcon,
  PackageIcon,
} from "@phosphor-icons/react";
import { useStore, api } from "./store";
import { Button } from "./ui";
import { HealthFields } from "./health-fields";
import {
  defaultHealth,
  type HealthRecord,
  type CommunityPost,
} from "@/lib/types";
import { products, recipes } from "@/lib/catalog";
import { isProductPage } from "@/lib/navigation";

const money = (value: number) =>
  new Intl.NumberFormat("en-CN", { style: "currency", currency: "CNY" }).format(
    value,
  );
const date = (value: string) => new Date(value).toLocaleString("en-GB");

export function HealthEntry() {
  const { data } = useStore();
  const health = data.state.profile.health;
  const filled = [health?.age, health?.heightCm, health?.weightKg].filter(
    (v) => v != null,
  ).length;
  return (
    <Link className="health-entry" href="/health">
      <HeartIcon size={25} />
      <div>
        <strong>Health records</strong>
        <p>
          {filled}/3 measurements saved · AI use{" "}
          {health?.useForAI ? "enabled" : "off"}
        </p>
      </div>
      <ArrowRightIcon size={20} />
    </Link>
  );
}

export function FloatingBasket() {
  const path = usePathname();
  const { data, ready } = useStore();
  if (!ready || !isProductPage(path)) return null;
  const count = data.state.cart.reduce((sum, item) => sum + item.quantity, 0);
  return (
    <Link
      href="/cart"
      className="floating-basket"
      aria-label={`Basket, ${count} items`}
    >
      <ShoppingBagIcon size={24} />
      <span>Basket</span>
      <b>{count}</b>
    </Link>
  );
}

export function HealthPage() {
  const { data, ready, busy, mutate, notify } = useStore();
  const [health, setHealth] = useState<HealthRecord>(defaultHealth());
  const [diet, setDiet] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  useEffect(() => {
    if (ready) {
      setHealth({ ...defaultHealth(), ...data.state.profile.health });
      setDiet(data.state.profile.diet);
    }
  }, [ready, data.state.profile.health, data.state.profile.diet]);
  async function save(event: FormEvent) {
    event.preventDefault();
    setError("");
    setSaved("");
    try {
      const state = await mutate({
        action: "profile",
        profile: { ...data.state.profile, health, diet },
      });
      setSaved(state.aiUpdate?.message || "Health records saved.");
      notify("Health records saved.");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <main className="main week6-page health-page">
      <Link className="back-link" href="/you">
        ← Your account
      </Link>
      <header className="health-welcome">
        <img
          src="/images/health-morning-v1.webp"
          alt=""
          width={1500}
          height={1000}
          fetchPriority="high"
        />
        <div>
          <span className="date-label">YOUR BREAKFAST CONTEXT</span>
          <h1>
            A little care,
            <br />
            <em>your own way.</em>
          </h1>
          <p>
            Your health records, food preferences and a breakfast that feels
            like you.
          </p>
          <span className="health-welcome-note">
            Optional records · You choose what AI can use
          </span>
        </div>
      </header>
      <div className="week6-columns">
        <form className="week6-panel form-stack" onSubmit={save}>
          <fieldset className="allergen-options">
            <legend>Food exclusions · optional</legend>
            <p>
              Choose what you want to avoid. These preferences filter
              recommendations even when health-record sharing is off.
            </p>
            {[
              ["dairy", "No dairy"],
              ["nuts", "No nuts"],
              ["gluten", "No gluten"],
              ["eggs", "No eggs"],
              ["vegan", "Plant-based"],
            ].map(([id, label]) => (
              <label key={id}>
                <input
                  type="checkbox"
                  checked={diet.includes(id)}
                  onChange={(e) =>
                    setDiet((current) =>
                      e.target.checked
                        ? [...current, id]
                        : current.filter((d) => d !== id),
                    )
                  }
                />
                {label}
              </label>
            ))}
            <p className="small-note">
              Always check actual ingredient labels and cross-contact
              information.
            </p>
          </fieldset>
          <HealthFields
            value={health}
            onChange={(value) => {
              setHealth(value);
              setSaved("");
            }}
          />
          {error && (
            <p className="error-text" role="alert">
              {error}
            </p>
          )}
          {saved && <p role="status">Saved. {saved}</p>}
          <Button disabled={!ready || busy}>
            {busy ? "Saving & updating AI…" : "Save health records"}
          </Button>
        </form>
        <aside className="week6-panel health-story-panel">
          <figure className="health-still-life">
            <img
              src="/images/health-botanical-v1.webp"
              alt="A quiet still life with oat stems, a pear and linen"
              width={800}
              height={1000}
              loading="lazy"
            />
            <figcaption>Small rituals. A little more care.</figcaption>
          </figure>
          <h2>
            Your records,
            <br />
            <em>your choice.</em>
          </h2>
          <p>
            Saving updates your breakfast context. AI only receives these
            records and recent history when the checkbox is enabled.
          </p>
          <Link className="subtle-link" href="/chat">
            Ask your breakfast expert <ArrowRightIcon size={17} />
          </Link>
          <Link className="subtle-link" href="/profile">
            Edit dietary preferences <ArrowRightIcon size={17} />
          </Link>
          <h3>Record history</h3>
          {data.state.healthHistory?.length ? (
            data.state.healthHistory.map((entry, index) => (
              <div
                className="health-history"
                key={`${entry.recordedAt}-${index}`}
              >
                <time>{date(entry.recordedAt)}</time>
                <p>
                  Age {entry.record.age ?? "—"} · {entry.record.heightCm ?? "—"}{" "}
                  cm · {entry.record.weightKg ?? "—"} kg
                </p>
                <p>
                  {entry.record.notes || "No notes"} · AI use{" "}
                  {entry.record.useForAI ? "on" : "off"}
                </p>
              </div>
            ))
          ) : (
            <p>No saved changes yet.</p>
          )}
        </aside>
      </div>
    </main>
  );
}

type Feed = {
  posts: CommunityPost[];
  stats: { recipeId: string; notes: number; people: number }[];
  total: number;
  page: number;
  pages: number;
};
export function CommunityPage() {
  const { data, busy, mutate, setAuthOpen } = useStore();
  const [recipe, setRecipe] = useState("");
  const [writeRecipe, setWriteRecipe] = useState(recipes[0].id);
  const [page, setPage] = useState(1);
  const [feed, setFeed] = useState<Feed | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [text, setText] = useState("");
  const [version, setVersion] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    api(`/api/community?recipe=${encodeURIComponent(recipe)}&page=${page}`)
      .then((result) => {
        if (active) setFeed(result);
      })
      .catch((e) => {
        if (active) setError(e.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [recipe, page, version]);
  async function share(event: FormEvent) {
    event.preventDefault();
    if (data.user.guest) {
      setAuthOpen(true);
      return;
    }
    try {
      setError("");
      await mutate({ action: "share", recipeId: writeRecipe, text });
      setText("");
      setRecipe(writeRecipe);
      setPage(1);
      setVersion((v) => v + 1);
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const ranked = [...recipes].sort(
    (a, b) =>
      (feed?.stats.find((s) => s.recipeId === b.id)?.people || 0) -
      (feed?.stats.find((s) => s.recipeId === a.id)?.people || 0),
  );
  return (
    <main className="main week6-page">
      <div className="page-title">
        <span className="date-label">THE BREAKFAST TABLE</span>
        <h1>Community mornings.</h1>
        <p>
          See what people are making. Share a tip under the recipe you tried.
        </p>
      </div>
      <div className="week6-columns community-columns">
        <section className="week6-panel">
          <div className="section-header compact">
            <h2>Recipe conversations</h2>
            <ChatCircleDotsIcon size={25} />
          </div>
          <p>
            Sorted by people who have posted. Counts come from actual notes in
            this app.
          </p>
          <div className="conversation-list">
            {ranked.map((r) => {
              const stats = feed?.stats.find((s) => s.recipeId === r.id);
              return (
                <button
                  key={r.id}
                  className={recipe === r.id ? "selected" : ""}
                  aria-pressed={recipe === r.id}
                  onClick={() => {
                    setRecipe(r.id);
                    setWriteRecipe(r.id);
                    setPage(1);
                  }}
                >
                  <img src={r.image} width={64} height={64} alt="" />
                  <span>
                    <strong>{r.name}</strong>
                    <small>
                      {stats
                        ? `${stats.people} people · ${stats.notes} notes`
                        : "No notes yet"}
                    </small>
                  </span>
                  <ArrowRightIcon size={18} />
                </button>
              );
            })}
          </div>
        </section>
        <section className="week6-panel">
          <div className="section-header compact">
            <h2>
              {recipe
                ? recipes.find((r) => r.id === recipe)?.name
                : "Latest notes"}
            </h2>
            <Button
              size="small"
              variant="ghost"
              onClick={() => {
                setRecipe("");
                setPage(1);
                setVersion((v) => v + 1);
              }}
            >
              All / Refresh
            </Button>
          </div>
          {loading ? (
            <p role="status">Loading conversations…</p>
          ) : error ? (
            <p className="error-text" role="alert">
              {error}
            </p>
          ) : (
            <>
              {feed?.posts.length ? (
                feed.posts.map((post) => (
                  <article className="community-note" key={post.id}>
                    <span className="avatar">
                      {post.name.charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <strong>{post.name}</strong>
                      <p>{post.text}</p>
                      <Link
                        className="subtle-link"
                        href={`/recipes/${post.recipeId}`}
                      >
                        {recipes.find((r) => r.id === post.recipeId)?.name} ↗
                      </Link>
                      <time dateTime={post.createdAt}>
                        {date(post.createdAt)}
                      </time>
                    </div>
                  </article>
                ))
              ) : (
                <div className="empty-community">
                  <ChatCircleDotsIcon size={28} />
                  <p>No notes yet. Try a recipe and start the conversation.</p>
                </div>
              )}
              <div className="feed-pagination">
                <Button
                  size="small"
                  variant="secondary"
                  disabled={!feed || feed.page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  Previous
                </Button>
                <span>
                  {feed?.total || 0} notes · {feed?.page || 1}/
                  {feed?.pages || 1}
                </span>
                <Button
                  size="small"
                  variant="secondary"
                  disabled={!feed || feed.page >= feed.pages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </>
          )}
          <form className="form-stack community-compose" onSubmit={share}>
            <h3>Share your breakfast tip</h3>
            <label>
              Recipe
              <select
                value={writeRecipe}
                onChange={(e) => setWriteRecipe(e.target.value)}
              >
                {recipes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Your note
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={3}
                minLength={3}
                maxLength={300}
                required
                placeholder="What worked for you?"
              />
            </label>
            <Button disabled={busy}>
              {data.user.guest
                ? "Sign in to share"
                : busy
                  ? "Sharing…"
                  : "Share note"}
            </Button>
          </form>
        </section>
      </div>
    </main>
  );
}

export function OrdersPage({ id }: { id?: string }) {
  const { data, ready } = useStore();
  const orders = data.state.orders;
  const order = id ? orders.find((o) => o.id === id) : null;
  if (!ready)
    return (
      <main className="main">
        <p role="status">Loading your orders…</p>
      </main>
    );
  return (
    <main className="main week6-page">
      <Link href={id ? "/orders" : "/cart"} className="back-link">
        ← {id ? "All orders" : "Your basket"}
      </Link>
      <div className="page-title">
        <span className="date-label">YOUR DEMO PURCHASES</span>
        <h1>{id ? "Order details." : "Orders & delivery."}</h1>
        <p>
          Saved in your account. Demo checkout does not take payment or ship
          goods.
        </p>
      </div>
      {id ? (
        order ? (
          <div className="week6-columns">
            <section className="week6-panel">
              <h2>{order.id}</h2>
              <p>{date(order.createdAt)}</p>
              {order.items.map((item) => {
                const product = products.find((p) => p.id === item.productId);
                return (
                  <div className="order-product" key={item.productId}>
                    {product && (
                      <img src={product.image} alt="" width={80} height={80} />
                    )}
                    <div>
                      <strong>{product?.name || item.productId}</strong>
                      <p>Quantity: {item.quantity}</p>
                    </div>
                  </div>
                );
              })}
              <h3>Order total {money(order.total)}</h3>
            </section>
            <aside className="week6-panel delivery-status">
              <PackageIcon size={34} />
              <h2>Delivery status</h2>
              <ol>
                <li>
                  <strong>Demo order saved</strong>
                  <p>{date(order.createdAt)}</p>
                </li>
                <li>
                  <strong>Payment not collected</strong>
                  <p>This is a simulated checkout.</p>
                </li>
                <li>
                  <strong>Shipping unavailable</strong>
                  <p>
                    No carrier or tracking number is assigned. Real logistics
                    are not connected.
                  </p>
                </li>
              </ol>
              <Link className="subtle-link" href="/shop">
                Back to the pantry <ArrowRightIcon size={17} />
              </Link>
            </aside>
          </div>
        ) : (
          <div className="empty-state">
            <h2>Order unavailable.</h2>
            <p>This order is not in your current account.</p>
            <Link className="subtle-link" href="/orders">
              View your orders
            </Link>
          </div>
        )
      ) : orders.length ? (
        <div className="week6-panel orders-index">
          {orders.map((o) => (
            <Link href={`/orders/${o.id}`} key={o.id}>
              <div>
                <strong>{o.id}</strong>
                <p>
                  {date(o.createdAt)} ·{" "}
                  {o.items.reduce((n, item) => n + item.quantity, 0)} items
                </p>
                <small>Demo saved · Shipping unavailable</small>
              </div>
              <strong>{money(o.total)}</strong>
              <ArrowRightIcon size={20} />
            </Link>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <PackageIcon size={38} />
          <h2>No orders yet.</h2>
          <p>
            Complete a demo checkout to see its items and delivery information
            here.
          </p>
          <Button asChild>
            <Link href="/shop">Browse products</Link>
          </Button>
        </div>
      )}
    </main>
  );
}
