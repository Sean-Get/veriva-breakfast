"use client";
import Link from "next/link";
import { ArrowRightIcon, BookOpenIcon } from "@phosphor-icons/react";
import { Reveal } from "./motion";
const steps = [
  {
    title: "Find a video idea and make it real.",
    text: "Video ideas connects eight creative cards to real recipes. Confirm your phone setup, kitchen equipment, scene and video target. Create separate projects, edit captions and camera angles, save and return through My creations. Shoot mode keeps a self-reported checklist; it does not record video. Export TXT plans or PNG storyboards. Templates work locally; optional AI narrative suggestions require Internet and your review.",
    href: "/ideas",
    link: "Explore creative cards",
  },
  {
    title: "Make someone’s idea your own.",
    text: "Create & explore introduces six concept recipes and fictional creators. Make It Mine adapts equipment, temperature, sweetness, texture and servings. Review actual changes before saving a separate version. Guided changes work locally; AI substitutions need Internet.",
    href: "/discover",
    link: "Discover, adapt and remix",
  },
  {
    title: "Create a story people can recreate.",
    text: "Creator Studio produces a recipe-linked shot list and editable caption, with optional Chinese copy. Download a TXT kit or PNG recipe card. Publishing creates a food-only snapshot; local addresses still require public hosting for cross-device sharing.",
    href: "/studio",
    link: "Create & share",
  },
  {
    title: "Cook, learn and come back.",
    text: "Cooking mode records steps and measured rescue guidance. Temporary fixes affect the current session; Save for next time creates another version. My Breakfast keeps your history. Three Ways to Try connects recipes, pantry quantities and classroom trial orders.",
    href: "/my-breakfast",
    link: "My versions and cooking history",
  },
  {
    title: "Understand the campaign journey.",
    text: "Observed local actions and fictional campaign examples are separate. Self-reported cooking is not independent verification, buying interest is not a sale, and classroom orders do not take payment.",
    href: "/campaign",
    link: "Campaign view",
  },
  {
    title: "Find your kind of morning.",
    text: "Home is a quiet introduction to the breakfast collection. Open a breakfast to discover its story, then choose a preparation idea or visit the shop.",
    href: "/",
    link: "The breakfast collection",
  },
  {
    title: "Make it personal.",
    text: "Set your goals, dietary exclusions and preparation time. Health records are optional and only shared with AI when you give consent.",
    href: "/profile",
    link: "Your breakfast preferences",
  },
  {
    title: "Cook a little something.",
    text: "Start with a finished bowl, then follow the preparation photos and six detailed steps. Active preparation and chilling time are shown separately.",
    href: "/recipes",
    link: "Recipes & breakfast stories",
  },
  {
    title: "Pull up a chair.",
    text: "Each recipe has its own conversation. The recipe library also has a breakfast table for original ideas. Fictional sample stories are labelled separately from real community notes.",
    href: "/recipes#breakfast-table",
    link: "The breakfast table",
  },
  {
    title: "Talk it through.",
    text: "Open AI from a recipe to keep that dish in context. Ask a question, then use Save this recipe adjustment when you want a suggested change stored. Your current records and consent remain in your control.",
    href: "/chat",
    link: "Your breakfast companion",
  },
  {
    title: "A practice shop.",
    text: "The shop shows illustrative prices, lets you change basket quantities and save demo orders. No payment is taken and no real deliveries are arranged.",
    href: "/shop",
    link: "Visit the pantry",
  },
];
export function EnglishGuide() {
  return (
    <main className="main english-guide">
      <div className="page-title">
        <span className="date-label">A LITTLE GUIDE TO YOUR MORNINGS</span>
        <h1>Start with a little good.</h1>
        <p>A few simple ways to find your feet in VERIVA.</p>
      </div>
      <div className="english-guide-grid">
        {steps.map((step, i) => (
          <Reveal key={step.title}>
            <article>
              <span>0{i + 1}</span>
              <h2>{step.title}</h2>
              <p>{step.text}</p>
              <Link className="quiet-discover" href={step.href}>
                {step.link}
                <ArrowRightIcon size={16} />
              </Link>
            </article>
          </Reveal>
        ))}
      </div>
      <a className="subtle-link" href="/VERIVA-user-guide.md" download>
        <BookOpenIcon size={17} />
        Download the English guide
      </a>
    </main>
  );
}
