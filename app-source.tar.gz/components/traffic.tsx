"use client";
import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { useStore } from "./store";

let documentVisitId: string | undefined;
let visitRecorded = false;

export function VisitTracker() {
  const { ready, data } = useStore();
  const path = usePathname();
  useEffect(() => {
    if (!ready || !data.user.id || path.startsWith("/admin") || visitRecorded) return;
    // getRandomValues also works on a classroom LAN served over HTTP.
    documentVisitId ||= typeof crypto.randomUUID === "function" ? crypto.randomUUID() :
      "10000000-1000-4000-8000-100000000000".replace(/[018]/g, c =>
        (Number(c) ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> Number(c) / 4).toString(16));
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let attempts = 0;
    async function send() {
      try {
        const response = await fetch("/api/visits", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ requestId: documentVisitId }), keepalive: true,
        });
        if (response.ok) { visitRecorded = true; return; }
        if (response.status < 500 && response.status !== 401) return;
      } catch { /* Retry with the same ID when the server reconnects. */ }
      if (!cancelled && ++attempts < 4) timer = setTimeout(send, 1500 * attempts);
    }
    void send();
    return () => { cancelled = true; clearTimeout(timer); };
  }, [ready, data.user.id, path]);
  return null;
}

type Traffic = { total: number; today: number; updatedAt: string };
export function TrafficPanel() {
  const [data, setData] = useState<Traffic | null>(null);
  const [error, setError] = useState("");
  const [changed, setChanged] = useState(false);
  const previous = useRef<number | null>(null);
  useEffect(() => {
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    async function load() {
      try {
        const response = await fetch("/api/visits", { cache: "no-store" });
        if (!response.ok) throw new Error(response.status === 401 ? "后台会话已过期，请重新登录。" : "访问统计暂时无法更新。");
        const next: Traffic = await response.json();
        if (disposed) return;
        setChanged(previous.current !== null && next.total !== previous.current);
        previous.current = next.total;
        setData(next); setError("");
      } catch (e) { if (!disposed) setError((e as Error).message); }
      if (!disposed) timer = setTimeout(load, 3000);
    }
    void load();
    return () => { disposed = true; clearTimeout(timer); };
  }, []);
  return <section className="traffic-panel" aria-label="APP 访问统计">
    <div><span className="date-label">LIVE APP VISITS</span><h2>每一次打开，都看得见。</h2>
      <p>每 3 秒同步服务器 · 今日按北京时间统计</p></div>
    <div className="traffic-totals" aria-live="polite" aria-atomic="true">
      <div><span>总访问次数</span><strong key={data?.total} className={changed ? "traffic-number traffic-changed" : "traffic-number"}>{data ? data.total.toLocaleString() : "—"}</strong></div>
      <div><span>今日访问</span><strong className="traffic-number">{data ? data.today.toLocaleString() : "—"}</strong></div>
    </div>
    <small>打开、刷新或新标签进入 APP 计一次；站内切换页面与管理后台不计入。访问次数不等于独立人数。</small>
    {error ? <p role="alert">{error} 当前保留上次成功的数据。</p> : <small>{data ? `最近同步：${new Date(data.updatedAt).toLocaleTimeString("zh-CN")}` : "正在连接服务器…"}</small>}
  </section>;
}
