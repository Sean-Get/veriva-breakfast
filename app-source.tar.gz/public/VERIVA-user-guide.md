# VERIVA User Guide

Home introduces the breakfast collection through food photography and quiet stories. Open a breakfast to find its product detail, recipe inspiration and a link to the demo shop. Prices and purchasing controls appear in the shop, not on Home.

Recipes include finished bowls, ingredients, preparation photos, six detailed steps and waiting times. Each recipe has a conversation beneath it. The breakfast table in the recipe library also welcomes original breakfast ideas. Sample stories are fictional and labelled; real notes are submitted by signed-in users and stored separately.

Set breakfast goals, exclusions and available time in Profile. Health records are optional. Enable and save consent before sending them to AI. You can inspect the current context in chat.

Open AI from a recipe to keep that dish in view. Chatting alone does not change the recipe. Save an adjustment card to generate and persist actual quantity and method changes. If it fails, your feedback remains saved and you can retry. The next adjustment keeps earlier changes to dimensions you did not ask to change.

The shop, basket and orders are demonstrations. No payment is collected and no products are delivered. Photography and packaging are illustrative. Actual ingredients, allergens and certifications must be checked on real product labels.

Motion respects the system's reduced-motion setting. Dialogs close with Escape and return focus to their trigger. For normal use, a modern browser is enough once the website is running. The local runtime needs Node.js 24 and a private server-side AI configuration.
