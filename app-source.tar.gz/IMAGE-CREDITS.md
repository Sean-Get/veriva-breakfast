# Creative photography · Visual Edition

## Single-package product images

The five product catalog images now show one sealed VERIVA concept pack each: blueberry–apple porridge, Bircher porridge, rolled oats, berry muesli and chia seeds. All were generated with the built-in image_gen tool. No separate prepared breakfast, bowls, spoons or props appear in these catalog assets. Product list and detail hero images use these packs; food serving photographs remain in recipe and editorial discovery areas. These are fictional classroom packaging mockups, not verified official product photography. Prompts and provenance: output/product-pack-manifest.json. Web files: public/images/product-pack-*-v1.webp.

Eight new editorial-style images were generated with the built-in image_gen tool for the classroom prototype: quiet morning, student mango cup, berry texture, sesame soy bowl, evening preparation, two versions, apple cinnamon variation and breakfast series.

These are AI-generated creative mood references. They are not photographs of tested recipes, customer videos, verified product packages or actual merchant stock. The selected recipe's ingredients and method remain the authority. Existing food photographs in personal recipe snapshots are separate from these idea-card covers.

Image direction: soft natural window light, warm pale oak, ivory ceramics and sage textiles; clear food textures, realistic portions, uncluttered compositions; no text, logos, packaging or watermarks. The complete individual prompts and original generated-file provenance are retained in the project's output/creator-image-manifest.json.

Web assets: public/images/creator-*-v1.webp, 1200 × 800. Source generation used PNG; the web copies were resized and encoded as WebP for loading performance without changing the depicted scene.

## Oatie and supply-chain additions · 6 November 2026

Oatie is an original AI-generated classroom mascot, generated with image_gen; public/images/oatie-assistant-v1.webp preserves transparency. It is not an official Verival mascot.

Additional ingredient and hand-mixing photographs © Verival, from https://www.verival.at/en/pages/zutaten, retrieved 6 November 2026. Local assets: factory-ingredients-v2.webp and factory-mixing-v2.webp. Source provenance: output/factory-evidence-v2.json. Brand statements are linked to official pages; these are not independently verified inspections or certificates.

## Factory workshop story · 6 November 2026

Five new factory scenes were generated with the built-in image_gen tool: factory-workshop-v1.webp, factory-grain-check-v1.webp, factory-blending-v1.webp, factory-packing-v1.webp and factory-dispatch-v1.webp. They are fictional classroom illustrations, not photographs of Verival's real facility, production machinery or verified practices. Each scene is labelled in the interface. Prompt set and raw generation provenance: output/factory-image-manifest.json. Optimised web assets are in public/images.

Official brand photographs remain separately attributed. The five-image official gallery includes factory-exterior.webp, factory-production.webp, factory-fields.webp, factory-ingredients-v2.webp and factory-mixing-v2.webp. Sources: https://www.verival.at/en/pages/ueber-uns and https://www.verival.at/en/pages/zutaten. Brand information rechecked 6 November 2026.

## Pantry and Health visual refresh — 6 November 2026

Five single-pouch classroom concepts: `product-pack-cocoa-hazelnut-v1.webp`, `product-pack-apple-cinnamon-v1.webp`, `product-pack-coconut-almond-v1.webp`, `product-pack-raspberry-crunch-v1.webp`, `product-pack-pumpkin-seeds-v1.webp`. Two decorative lifestyle assets: `health-morning-v1.webp`, `health-botanical-v1.webp`. All generated with built-in image_gen, not verified retail packaging or medical evidence. Full prompts, originals, saved paths and dimensions: `output/visual-refresh-image-manifest.json` in the parent workspace.
